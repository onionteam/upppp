<?php

namespace App\Controller\Member;

/**
 * @property \Cake\ORM\Table $CampaignCountries
 */
class CampaignCountriesController extends AppMemberController
{
}

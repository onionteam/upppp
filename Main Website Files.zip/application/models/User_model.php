<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_model extends CI_Model {

 public function __construct()
 {
  parent::__construct();
 }

 ///////////////////////////////////////
 //          Begin Add User    /////////
 ///////////////////////////////////////
 public function add_user() {

  $data=array(
    'username'=>$this->input->post('user'),
    'email'=>$this->input->post('email'),
    'password'=>md5($this->input->post('pass'))
  );
  $this->db->insert('users',$data);

  if (EMAIL_ADDRESS != '') {

    #Send an email to the new user#
    $to = $this->input->post("email");
    $username = $this->input->post('user');

    $this->load->library('email');

    $config['protocol'] = 'smtp';
    $config['smtp_host'] = EMAIL_SMTP_HOST;
    $config['smtp_user'] = EMAIL_ADDRESS;
    $config['smtp_pass'] = EMAIL_PASSWORD;
    $config['smtp_port'] = EMAIL_SMTP_PORT;
    $config['wordwrap'] = TRUE;
    $config['mailtype'] = 'html';

    $this->email->initialize($config);

    $this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
    $this->email->to("$to"); 

    $this->email->subject('Welcome to ' . WEBSITE_TITLE);


    $this->email->message("Hello $username,<br/><br/>

      Welcome to ".WEBSITE_TITLE.". Sell your digital products online.  <br/><br/>

      Thank you for joining. If you have any questions please email us. <br/><br/>

      ".EMAIL_ADDRESS."

      <br/><br/>

      Kind Regards,<br/><br/>

      ".WEBSITE_TITLE." Team<br/>
      ".base_url()."

      ");

    $this->email->send();

  }



 }
 ///////////////////////////////////////


 ///////////////////////////////////////
 //          Add Public Page   /////////
 ///////////////////////////////////////
public function add_public_page($product_id) {

  $data=array(
    'product_id'=>$product_id
    );

  $this->db->insert('public_page', $data);


}


 ///////////////////////////////////////
 //          Get Price         /////////
 ///////////////////////////////////////
public function get_price($slug) {

  #Get product id using slug
    $query = "SELECT * FROM public_page WHERE id=?";
    $query = $this->db->query($query, array($slug));
    $row = $query->row(); 
    $product_id = $row->product_id;

    #Get product using product id from slug
    $query = "SELECT * FROM products WHERE id=?";
    $query = $this->db->query($query, array($product_id));
    $row = $query->row(); 
    $price = $row->product_price;

    return $price;


}

public function delete_product($product_id = null) {

  if ($product_id == null) {

    $product_id = $this->input->post('product_id');

  }

  //Delete product
  $query = "DELETE FROM products WHERE id=?";
  $this->db->query($query, array($product_id));

  //Delete public page
  $query = "DELETE FROM public_page WHERE product_id=?";
  $this->db->query($query, array($product_id));

  //Delete paypal orders
  $query = "DELETE FROM paypal_orders WHERE product_id=?";
  $this->db->query($query, array($product_id));

  //Delete crypto orders
  $query = "DELETE FROM crypto_orders WHERE product_id=?";
  $this->db->query($query, array($product_id));

  //Delete stripe orders
  $query = "DELETE FROM stripe_orders WHERE product_id=?";
  $this->db->query($query, array($product_id));

  //Delete download_links
  $query = "DELETE FROM download_links WHERE product_id=?";
  $this->db->query($query, array($product_id));

  //Delete coupons
  $query = "DELETE FROM coupons WHERE product_id=?";
  $this->db->query($query, array($product_id));

}

public function add_product() {

  $title = $this->input->post('title');
  $price = $this->input->post('price');
  $currencies = $this->input->post('currencies');
  $description = $this->input->post('description');
  $type = $this->input->post('type');
  $serials = $this->input->post('serials');
  $direct_url = $this->input->post('direct_url');
  $file_name_uploaded = $this->input->post('file_name_upload');
  $file_name = $this->input->post('file_name');

  #if download
  if ($file_name_uploaded != '') {

        $email = $this->session->userdata('user_email');

        $username = $this->session->userdata('user_name');

        $timestamp = time();

        $time = date('c',$timestamp);

        $json_decode = json_decode($currencies, TRUE);

        $count = 0;
        foreach ($json_decode AS $key=>$val) {

          //echo $val[0];

          if (!empty($val)) {

            $currency[] = $key;

          }

        }

        $currency = implode(',', $currency);

        $data=array(
            'username' => $username,
            'email' => $email,
            'product_title' => $title,
            'product_price' => $price,
            'product_description' => $description,
            'product_type' => $type,
            'product_upload' => $file_name_uploaded,
            'product_upload_name' => $file_name,
            'product_serials' => $serials,
            'product_currency' => $currency,
            'time' => $time
            
          );

          $this->db->insert('products', $data);

          return $this->db->insert_id();


      

  }
  elseif ($serials != '' || $serials != 'Undefined') {

    $email = $this->session->userdata('user_email');

    $username = $this->session->userdata('user_name');

    $timestamp = time();

    $time = date('c',$timestamp);

    $json_decode = json_decode($currencies, TRUE);

    $count = 0;
    foreach ($json_decode AS $key=>$val) {

      //echo $val[0];

      if (!empty($val)) {

        $currency[] = $key;

      }

    }

    $currency = implode(',', $currency);

    $data=array(
        'username' => $username,
        'email' => $email,
        'product_title' => $title,
        'product_price' => $price,
        'product_description' => $description,
        'product_type' => $type,
        'product_serials' => $serials,
        'product_currency' => $currency,
        'product_directurl' => $direct_url,
        'time' => $time
        
      );



      $this->db->insert('products', $data);

      return $this->db->insert_id();


  }
  else {

  }



  

  





}

public function insert_stripe_order($product_id, $to, $amount, $time) {

    //gateway fee?
    $gateway_fee = 0;
    if ( GATEWAY_FEE != 0 ) {

      $gateway_fee = (round(($amount * GATEWAY_FEE), 2)) / 100;
      $gateway_fee = round($gateway_fee, 2);

      //Add fee to current balance

      #get email using product id
      $query = "SELECT * FROM products WHERE id=?";
      $query = $this->db->query($query, array($product_id));
      $row = $query->row();
      $email = $row->email;

      $current_balance = $this->get_current_balance($email);

      #The new balance with gateway fee
      $new_balance = round($current_balance, 2) + $gateway_fee;

      #Insert or update new balance
      $this->insert_new_balance($email, $new_balance);

    }


    $data=array(
        'product_id' => $product_id,
        'amount' => $amount,
        'gateway_fee' => $gateway_fee,
        'email' => $to,
        'time' => $time
        
      );

      $this->db->insert('stripe_orders', $data);




}

public function get_stripe_keys($user_email) {

  $query = "SELECT * FROM payment_settings WHERE email=?";
  $query = $this->db->query($query, array($user_email));

  return $query->result_array();


}

public function edit_product($product_id) {

  $title = $this->input->post('title');
  $price = $this->input->post('price');
  $currencies = $this->input->post('currencies');
  $description = $this->input->post('description');
  $type = $this->input->post('type');
  $serials = $this->input->post('serials');
  $direct_url = $this->input->post('direct_url');
  $file_name_uploaded = $this->input->post('file_name_upload');
  $file_name = $this->input->post('file_name');
  

  //Get current filename so we can remove it if it exists
  //if ( $type == "Download" ) {

    //$uploaded = $this->get_product_upload();

    //if ($file_name_uploaded != '') {

      //$query = "SELECT * FROM products WHERE id=?";
      //$query = $this->db->query($query, array($product_id));
      //$row = $query->row(); 

      //$current_file_name = $row->product_upload;

      //$new_file_name = $this->do_upload($path, $current_file_name);

      

    //}

  //}

  #No errors in file upload then add to db


    $timestamp = time();

    $time = date('c',$timestamp);

    $json_decode = json_decode($currencies, TRUE);

    $count = 0;
    foreach ($json_decode AS $key=>$val) {

      //echo $val[0];

      if (!empty($val)) {

        $currency[] = $key;

      }

    }

    $currency = implode(',', $currency);

    $data=array(
        'product_title' => $title,
        'product_price' => $price,
        'product_description' => $description,
        'product_type' => $type,
        'product_serials' => $serials,
        'product_directurl' =>$direct_url,
        'product_currency' => $currency,
        'time' => $time
        
      );

    if ( !empty($file_name_uploaded) ) {

        $data['product_upload'] = $file_name_uploaded;

        $data['product_upload_name'] = $file_name;

    }

    $this->db->where('id', $product_id);
    $this->db->update('products', $data);

      //return $this->db->insert_id();

  

}

public function get_product_upload() {

  $product_id = $this->input->post('product_id');

  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  
  if ( $query->num_rows() > 0 ) {

    $row = $query->row();
    $current_file_name = $row->product_upload;

    if ($current_file_name != "Undefined" || !empty($current_file_name) ) {

      return $current_file_name;

    }
    else {

      return false;
    }


  }
  else {

    return false;

  }


}

public function do_upload($path, $current_file_name = null) {


    $config['upload_path'] = './uploads/';
    $config['allowed_types'] = 'zip';
    $config['max_size'] = MAX_UPLOAD_SIZE * 1000;

    
    $ext = pathinfo($path, PATHINFO_EXTENSION);

    $new_name = $this->random_string(10) . "." . $ext;
    $config['file_name'] = $new_name;
    $full_path = FCPATH . "/uploads/" . $new_name;

    $this->load->library('upload', $config);
      

        if ( ! $this->upload->do_upload('file'))
        {

          if ($current_file_name != null) {

            return array('error' => $this->upload->display_errors());

          }
          else {

            return $this->upload->display_errors();

          }


        }
        else
        {
          $data = array('upload_data' => $this->upload->data());

          if ($current_file_name != null) {

            unlink(FCPATH . "/uploads/" . $current_file_name);

          }
          
          return $new_name;
          
        }

}
#End Do_Upload



public function random_string($length) {
    $key = '';
    $keys = array_merge(range(0, 9), range('a', 'z'));

    for ($i = 0; $i < $length; $i++) {
        $key .= $keys[array_rand($keys)];
    }

    return $key;
}




public function get_product($slug) {

    #Get product id using slug
    $query = "SELECT * FROM public_page WHERE id=?";
    $query = $this->db->query($query, array($slug));

    if ($query->num_rows() == 0) {

      return false;

    }
    else {

      $row = $query->row(); 
      $product_id = $row->product_id;

      #Get product using product id from slug
      $query = "SELECT * FROM products WHERE id=?";
      $query = $this->db->query($query, array($product_id));
      $product = $query->result_array();

      return $product;

    }

    


}


public function get_product_edit($product_id, $user_email) {

    #Get product id using slug
    $query = "SELECT * FROM products WHERE id=? AND email=?";
    $query = $this->db->query($query, array($product_id, $user_email));

    $product = $query->result_array();

    return $product;


}

public function insert_crypto_order($product_id, $txid, $amount) {

    $timestamp = time();

    $now = date('c',$timestamp);

    //gateway fee?
    $gateway_fee = 0;
    if ( GATEWAY_FEE != 0 ) {

      $gateway_fee = round(($amount * GATEWAY_FEE), 2);
      $gateway_fee = round($gateway_fee, 2);

      //Add fee to current balance

      #get email using product id
      $query = "SELECT * FROM products WHERE id=?";
      $query = $this->db->query($query, array($product_id));
      $row = $query->row();
      $email = $row->email;

      $current_balance = $this->get_current_balance($email);

      #The new balance with gateway fee
      $new_balance = round($current_balance, 2) + $gateway_fee;

      #Insert or update new balance
      $this->insert_new_balance($email, $new_balance);

    }


    $data=array(
        'product_id' => $product_id,
        'gateway_fee' => $gateway_fee,
        'amount_needed' => $amount,
        'txn_id' => $txid,
        'time' => $now
        
      );

      $this->db->insert('crypto_orders', $data);


}

public function get_current_balance($email) {

  #get total_amount_needed
  $query = "SELECT * FROM billing WHERE email=?";
  $query = $this->db->query($query, array($email));

  if ( $query->num_rows() > 0 ) {

    $row = $query->row();

    $current_balance = $row->current_balance;

    return $current_balance;

  }
  else {

    return 0;

  }

}

public function insert_new_balance($email, $new_balance) {

  $query = "SELECT * FROM billing WHERE email=?";
  $query = $this->db->query($query, array($email));
  $num_rows = $query->num_rows();

  if ($num_rows == 0) {

    $data=array(
        'email' => $email,
        'current_balance' => $new_balance,
        
      );

      $this->db->insert('billing', $data);

  }
  else {

    $data=array(
        'current_balance' => $new_balance
      );

      $this->db->where('email', $email);
      $this->db->update('billing', $data);


  }


}


public function check_payment_settings($key) {

  $session_email = $this->session->userdata('user_email');

  if ($key == "STRIPE") {

    $stripe_array = array('stripe_published_key', 'stripe_secret_key');

    foreach ($stripe_array AS $each) {

      #get total_amount_needed
      $query = "SELECT * FROM payment_settings WHERE email=?";
      $query = $this->db->query($query, array($session_email));
      $row = $query->row();

      if (empty($row->$each)) {

        return '';

      }


    }

  }
  else {

      #get total_amount_needed
      $query = "SELECT * FROM payment_settings WHERE email=?";
      $query = $this->db->query($query, array($session_email));

      if ($query->num_rows() > 0) {

        $row = $query->row(); 

        return $row->$key;

      }
      else {

        return '';

      }

      

  }

  return 1;


}

public function update_crypto_ipn() {

    $timestamp = time();
    $now = date('c',$timestamp);

    $txn_id = $_POST['txn_id'];
    $payment_status = $_POST['status_text'];
    $currency  = $_POST['currency2'];
    $amount_usd  = $_POST['amount1'];
    $amount_crypto = $_POST['amount2'];
    $fee = $_POST['fee'];
    $net = $_POST['net'];
    $received_amount = $_POST['received_amount'];

    #get total_amount_needed
    $query = "SELECT * FROM crypto_orders WHERE txn_id=?";
    $query = $this->db->query($query, array($txn_id));
    $row = $query->row(); 
    $amount_needed = $row->amount_crypto;

    if ($payment_status == "Complete" && $amount_crypto == $received_amount) {

      $data=array(
        'payment_status' => $payment_status,
        'currency' => $currency,
        'amount_usd' => $amount_usd,
        'amount_crypto' => $amount_crypto,
        'fee' => $fee,
        'net' => $net,
        'received_amount' => $received_amount,
        'time' => $now
        
      );

      $this->db->where('txn_id', $txn_id);
      $this->db->update('crypto_orders', $data);

      return 1;

    }
    else {

      $data=array(
        'payment_status' => $payment_status,
        'currency' => $currency,
        'amount_usd' => $amount_usd,
        'amount_crypto' => $amount_crypto,
        'fee' => $fee,
        'net' => $net,
        'received_amount' => $received_amount,
        'time' => $now
        
      );

      $this->db->where('txn_id', $txn_id);
      $this->db->update('crypto_orders', $data);

      return 0;

    }

    
    




}




public function check_crypto_ipn() {

  $txn_id_post = $_POST['txn_id'];

  $query = "SELECT * FROM crypto_orders WHERE txn_id=?";
  $query = $this->db->query($query, array($txn_id_post));
  //$row = $query->row(); 

  return $query->num_rows();


}

public function get_user_email($product_id) {

  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row(); 

  return $row->email;

}

public function get_crypto_address($email, $currency) {

  $query = "SELECT * FROM payment_settings WHERE email=?";
  $query = $this->db->query($query, array($email));
  $row = $query->row(); 

  return $row->$currency;

}

public function get_crypto_net($txn_id) {

  $query = "SELECT * FROM crypto_orders WHERE txn_id=?";
  $query = $this->db->query($query, array($txn_id));
  $row = $query->row(); 

  return $row->net;

}

public function get_order_id($txn_id) {

  $query = "SELECT * FROM crypto_orders WHERE txn_id=?";
  $query = $this->db->query($query, array($txn_id));
  $row = $query->row(); 

  return $row->id;

}

public function insert_withdrawal($order_id, $withdrawal_txn_id, $crypto_net) {


  $timestamp = time();

  $time = date('c',$timestamp);

    $data=array(
        'order' => $order_id,
        'amount' => $crypto_net,
        'sent' => 1,
        'txn_id' => $withdrawal_txn_id,
        'time' => $time
      );

      $this->db->insert('crypto_withdraw', $data);


}


public function get_payment($slug, $currency) {


  $query = "SELECT * FROM public_page WHERE id=?";
  $query = $this->db->query($query, array($slug));
  $row = $query->row(); 
  $product_id = $row->product_id;

  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row();
  $email = $row->email;

  $query = "SELECT * FROM payment_settings WHERE email=?";
  $query = $this->db->query($query, array($email));
  $row = $query->row();
  
  return $row->$currency;


}

public function get_title($slug) {

    #Get product id using slug
    $query = "SELECT * FROM public_page WHERE id=?";
    $query = $this->db->query($query, array($slug));
    $row = $query->row();
    $product_id = $row->product_id;

    #Get product using product id from slug
    $query = "SELECT * FROM products WHERE id=?";
    $query = $this->db->query($query, array($product_id));
    $row = $query->row(); 
    
    return $row->product_title;


}

public function get_product_id($slug) {

  #Get product id using slug
  $query = "SELECT * FROM public_page WHERE id=?";
  $query = $this->db->query($query, array($slug));
  $row = $query->row(); 
  
  return $row->product_id;


}

public function get_product_id_txn($txn_id) {

  #Get product id using slug
  $query = "SELECT * FROM crypto_orders WHERE txn_id=?";
  $query = $this->db->query($query, array($txn_id));
  $row = $query->row(); 
  
  return $row->product_id;


}

public function insert_paypal_order($product_id, $payment_status, $payment_amount, $payment_currency, $paypal_email, $txn_id, $time) {


  $query = "SELECT * FROM paypal_orders WHERE txn_id=?";
  $query = $this->db->query($query, array($txn_id));
  $num_rows = $query->num_rows();

  if ($num_rows == 0) {

    //gateway fee?
    $gateway_fee = 0;
    if ( GATEWAY_FEE != 0 ) {

      $gateway_fee = round(($payment_amount * GATEWAY_FEE), 2);
      $gateway_fee = round($gateway_fee, 2);

      //Add fee to current balance

      #get email using product id
      $query = "SELECT * FROM products WHERE id=?";
      $query = $this->db->query($query, array($product_id));
      $row = $query->row();
      $email = $row->email;

      $current_balance = $this->get_current_balance($email);

      #The new balance with gateway fee
      $new_balance = round($current_balance, 2) + $gateway_fee;

      #Insert or update new balance
      $this->insert_new_balance($email, $new_balance);

    }

    $data=array(
        'product_id' => $product_id,
        'gateway_fee' => $gateway_fee,
        'payment_status' => $payment_status,
        'payment_amount' => $payment_amount,
        'payment_currency' => $payment_currency,
        'paypal_email' => $paypal_email,
        'txn_id' => $txn_id,
        'timestamp' => $time
        
      );

      $this->db->insert('paypal_orders', $data);

      //return $this->db->insert_id();

  }
  else {

    $data=array(
        'product_id' => $product_id,
        'payment_status' => $payment_status,
        'payment_amount' => $payment_amount,
        'payment_currency' => $payment_currency,
        'paypal_email' => $paypal_email,
        'txn_id' => $txn_id,
        'timestamp' => $time
        
      );

      $this->db->where('txn_id', $txn_id);
      $this->db->update('paypal_orders', $data);


  }

}





public function insert_random_link($product_id) {

  
  //$num_rows = $query->num_rows();

  do {

    $random_url = $this->random_string(25);

    $query = "SELECT * FROM download_links WHERE temp_url=?";
    $query = $this->db->query($query, array($random_url));

  } while($query->num_rows() > 0);

  $data=array(
        'product_id' => $product_id,
        'temp_url' => $random_url
      );

  $this->db->insert('download_links', $data);

  return $random_url;


}



public function get_download_file($temp_url) {

  #Get product id using slug
  $query = "SELECT * FROM download_links WHERE temp_url=?";
  $query = $this->db->query($query, array($temp_url));
  $row = $query->row(); 
  $product_id = $row->product_id;


  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row(); 
  $product_upload = $row->product_upload;

  return $product_upload;

}

public function get_download_title($temp_url) {

  #Get product id using slug
  $query = "SELECT * FROM download_links WHERE temp_url=?";
  $query = $this->db->query($query, array($temp_url));
  $row = $query->row(); 
  $product_id = $row->product_id;


  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row(); 
  $product_title = $row->product_title;

  return $product_title;

}

public function set_download_time($temp_url) {

  #Get product id using slug
  $query = "SELECT * FROM download_links WHERE temp_url=?";
  $query = $this->db->query($query, array($temp_url));
  $row = $query->row(); 
  $init_time = $row->init_time;

  if ($init_time == NULL) {

    $timestamp = time();

    $now = date('c',$timestamp);

    $end_time = date('c', $timestamp+(60*60));


    $data=array(

        'init_time' => $now,
        'end_time' => $end_time
        
      );

      $this->db->where('temp_url', $temp_url);
      $this->db->update('download_links', $data);


  }

}

public function get_end_time($temp_url) {

  #Get product id using slug
  $query = "SELECT * FROM download_links WHERE temp_url=?";
  $query = $this->db->query($query, array($temp_url));
  $row = $query->row(); 

  return $row->end_time;


}

public function get_products() {

  $session_email = $this->session->userdata('user_email');

  #Get product id using slug
  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($session_email));
  
  return $query->result_array();

}

public function get_total_earnings() {

  $total = 0;

  $session_email = $this->session->userdata('user_email');

  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($session_email));
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      #Paypal orders
      $query = "SELECT * FROM paypal_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_amount = $y['payment_amount'];

        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $payment_amount + $total;

        }


      }

      #crypto orders
      $query = "SELECT * FROM crypto_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_amount = $y['amount_usd'];

        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $payment_amount + $total;

        }

        

      }

      #stripe orders
      $query = "SELECT * FROM stripe_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_amount = $y['amount'] / 100;

        $total = $payment_amount + $total;

      }

    }

    return number_format($total, 2, '.', ',');

  }
  else {

    return "0.00";

  }

}


public function get_total_sales() {

  $total = 0;

  $session_email = $this->session->userdata('user_email');

  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($session_email));
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      $query = "SELECT * FROM paypal_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {


        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $total + 1;

        }

      }

      //crypto
      $query = "SELECT * FROM crypto_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {


        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $total + 1;

        }

      }

      //stripe
      $query = "SELECT * FROM stripe_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

          $total = $total + 1;


      }




    }

    return $total;

  }
  else {

    return "0";

  }

}


public function get_today_earnings() {

  $total = 0;

  $session_email = $this->session->userdata('user_email');

  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($session_email));
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  $timestamp = time();

  $now = date('c',$timestamp);

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      $timezone_offset = str_replace('GMT', '', $this->session->userdata('user_timezone'));

      $t = trim($timezone_offset . ":00");

      

      $query = $this->db->query("SELECT * FROM paypal_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`timestamp`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`timestamp`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

             
      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

      
        $payment_amount = $y['payment_amount'];

        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $payment_amount + $total;

        }
        
      }

      #crypto
      $query = $this->db->query("SELECT * FROM crypto_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

      
        $payment_amount = $y['amount_usd'];

        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $payment_amount + $total;

        }
        
      }

      #stripe
      $query = $this->db->query("SELECT * FROM stripe_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

      
        $payment_amount = $y['amount'] / 100;

        $total = $payment_amount + $total;

      }


    }


    return number_format($total, 2, '.', ',');

  }# end if
  else {

    return "0";

  }


}


public function get_today_sales() {

  $total = 0;

  $session_email = $this->session->userdata('user_email');

  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($session_email));
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      $timezone_offset = str_replace('GMT', '', $this->session->userdata('user_timezone'));

      $t = trim($timezone_offset . ":00");

      $query = $this->db->query("SELECT * FROM paypal_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`timestamp`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`timestamp`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

        
        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $total + 1;

        }
        

      }

      #get crypto

      $query = $this->db->query("SELECT * FROM crypto_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

        
        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $total + 1;

        }
        

      }

      #get stripe
      $query = $this->db->query("SELECT * FROM stripe_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

          $total = $total + 1;
        

      }


    }


    return $total;

  }# end if
  else {

    return "0";

  }


}


public function get_notifications() {


  $session_email = $this->session->userdata('user_email');

  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($session_email));
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  $notifications = array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      #PayPal orders
      $query = "SELECT * FROM paypal_orders WHERE product_id=? ORDER BY `timestamp` DESC";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_status = $y['payment_status'];

        if ($payment_status == "Completed") {

          $id = $y['id'];

          $payment_amount = $y['payment_amount'];

          $time = $y['timestamp'];

          $notifications[] = array(

            'id' => $id . "_paypal",

            'payment_amount' => $payment_amount,

            'time' => $time

          );


        }

        


      }

      #Crypto orders
      $query = "SELECT * FROM crypto_orders WHERE product_id=? ORDER BY time DESC";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_status = $y['payment_status'];

        if ($payment_status == "Complete") {

          $id = $y['id'];

          $payment_amount = $y['amount_usd'];

          $time = $y['time'];

          $notifications[] = array(

            'id' => $id . "_crypto",

            'payment_amount' => $payment_amount,

            'time' => $time

            );

        }


      }


      #Stripe orders
      $query = "SELECT * FROM stripe_orders WHERE product_id=? ORDER BY time DESC";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

          $id = $y['id'];

          $payment_amount = $y['amount'];

          $time = $y['time'];

          $notifications[] = array(

            'id' => $id . "_stripe",

            'payment_amount' => $payment_amount / 100,

            'time' => $time

            );

        


      }


    }#end foreach product id


    $notifications = $this->array_sort($notifications, 'time', SORT_DESC);

    $output = array_slice($notifications, 0, 10);

    return $output;


  }#end if not 0 rpws


}#end notifications function



public function array_sort($array, $on, $order=SORT_ASC){

    $new_array = array();
    $sortable_array = array();

    if (count($array) > 0) {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    if ($k2 == $on) {
                        $sortable_array[$k] = $v2;
                    }
                }
            } else {
                $sortable_array[$k] = $v;
            }
        }

        switch ($order) {
            case SORT_ASC:
                asort($sortable_array);
                break;
            case SORT_DESC:
                arsort($sortable_array);
                break;
        }

        foreach ($sortable_array as $k => $v) {
            $new_array[$k] = $array[$k];
        }
    }

    return $new_array;
}


public function payment_settings($user_email) {

  $query = "SELECT * FROM payment_settings WHERE email=?";
  $query = $this->db->query($query, array($user_email));
  $num_rows = $query->num_rows();

  if ( $num_rows > 0 ) {

    $data = array(
      'email' => $user_email,
       'PayPal' => $this->input->post('paypal'),
       'BTC' => $this->input->post('bitcoin'),
       'LTC' => $this->input->post('litecoin'),
       'DOGE' => $this->input->post('dogecoin'),
       'stripe_published_key' => $this->input->post('stripe_pub'),
       'stripe_secret_key' => $this->input->post('stripe_sec')
    );

    $this->db->where('email', $user_email);
    $this->db->update('payment_settings', $data); 

  }
  else {

    $data = array(
       'email' => $user_email,
       'PayPal' => $this->input->post('paypal'),
       'BTC' => $this->input->post('bitcoin'),
       'LTC' => $this->input->post('litecoin'),
       'DOGE' => $this->input->post('dogecoin'),
       'stripe_published_key' => $this->input->post('stripe_pub'),
       'stripe_secret_key' => $this->input->post('stripe_sec')
    );

    $this->db->insert('payment_settings', $data); 

  }


}

public function get_payment_settings() {

  $user_email = $this->session->userdata('user_email');

  $query = "SELECT * FROM payment_settings WHERE email=?";
  $query = $this->db->query($query, array($user_email));

  $num_rows = $query->num_rows();

  if ( $num_rows != 0 ) {

    return $query->result_array();


  }
  else {

    return false;
  }


}


public function change_password($user_email) {

  $pass = $this->input->post('pass');

  $confirm = $this->input->post('confirm');

  if ($pass == $confirm) {

    $data = array(
       'password' => md5($this->input->post('pass')),
    );

    $this->db->where('email', $user_email);
    $this->db->update('users', $data); 

    return true;


  }
  else {

    return FALSE;

  }

  


}

public function check_type($product_id) {

  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row();

  return $row->product_type;


}

public function get_direct_url($product_id) {

  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row();

  return $row->product_directurl;


}

public function get_serial($product_id) {

  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row();

  $serials = $row->product_serials;

  $serials_array = explode(',', $serials);

  $serial = $serials_array[0];

  array_shift($serials_array);

  #Update with removed serial

  $data=array(
    'product_serials'=>implode(',', $serials_array)
  );


  $this->db->where('id', $product_id);
  $this->db->update('products', $data);

  return $serial;


}


public function get_recent_order($id) {


  if (strpos($id,'paypal') !== false) {

    //paypal order

    $real_id = str_replace("_paypal", "", $id);

    $query = "SELECT * FROM paypal_orders WHERE id=?";
    $query = $this->db->query($query, array($real_id));

    return $query->result_array();

  }
  elseif(strpos($id,'stripe') !== false) {

    //Stripe order

    $real_id = str_replace("_stripe", "", $id);

    $query = "SELECT * FROM stripe_orders WHERE id=?";
    $query = $this->db->query($query, array($real_id));

    return $query->result_array();

  }
  else {

    //crypto order
    $real_id = str_replace("_crypto", "", $id);

    $query = "SELECT * FROM crypto_orders WHERE id=?";
    $query = $this->db->query($query, array($real_id));

    return $query->result_array();

  }


}


public function get_total_users() {


  $query = "SELECT * FROM users";
  $query = $this->db->query($query);


  return $query->num_rows();

}

public function get_total_earnings_by_all() {


  $total = 0;

  $query = "SELECT * FROM products";
  $query = $this->db->query($query);
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      #Paypal orders
      $query = "SELECT * FROM paypal_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_amount = $y['payment_amount'];

        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $payment_amount + $total;

        }


      }

      #crypto orders
      $query = "SELECT * FROM crypto_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_amount = $y['amount_usd'];

        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $payment_amount + $total;

        }

        

      }

      #stripe orders
      $query = "SELECT * FROM stripe_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

        $payment_amount = $y['amount'] / 100;

        $total = $payment_amount + $total;

      }

    }

    return number_format($total, 2, '.', ',');

  }
  else {

    return "0.00";

  }


}


public function get_total_sales_by_all() {

  $total = 0;

  $query = "SELECT * FROM products";
  $query = $this->db->query($query);
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      $query = "SELECT * FROM paypal_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {


        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $total + 1;

        }

      }

      //crypto
      $query = "SELECT * FROM crypto_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {


        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $total + 1;

        }

      }

      //stripe
      $query = "SELECT * FROM stripe_orders WHERE product_id=?";
      $query = $this->db->query($query, array($product_id));

      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {

          $total = $total + 1;


      }




    }

    return $total;

  }
  else {

    return "0";

  }

}



public function get_today_sales_by_all() {

  $total = 0;

  $query = "SELECT * FROM products";
  $query = $this->db->query($query);
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  if ( $num_rows != 0 ) {

    foreach($result_array AS $x) {

      $product_id = $x['id'];

      $timezone_offset = str_replace('GMT', '', $this->session->userdata('user_timezone'));

      $t = trim($timezone_offset . ":00");

      $query = $this->db->query("SELECT * FROM paypal_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`timestamp`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`timestamp`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

        
        $payment_status = $y['payment_status'];

        if ( $payment_status == "Completed" ) {

          $total = $total + 1;

        }
        

      }

      #get crypto

      $query = $this->db->query("SELECT * FROM crypto_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

        
        $payment_status = $y['payment_status'];

        if ( $payment_status == "Complete" ) {

          $total = $total + 1;

        }
        

      }

      #get stripe
      $query = $this->db->query("SELECT * FROM stripe_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  >= CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).")

                AND CONVERT_TZ(`time`,'+0:00', ".$this->db->escape($t).")  < CONVERT_TZ(CURDATE(),'+0:00', ".$this->db->escape($t).") + INTERVAL 1 DAY ");

      $result_array2 = $query->result_array();

      //print_r($result_array2);

      foreach($result_array2 AS $y) {

          $total = $total + 1;
        

      }


    }


    return $total;

  }# end if
  else {

    return "0";

  }


}





public function get_website_settings() {

  $query = "SELECT * FROM website_settings";
  $query = $this->db->query($query);

  $result = $query->row();

  return $result;




}


public function submit_website_settings() {


  $website_title = $this->input->post('website_title');
  $website_logo_url = $this->input->post('website_logo_url');
  $gateway_fee = $this->input->post('gateway_fee');
  $max_upload_size = $this->input->post('max_upload_size');
  $email_smtp_host = $this->input->post('email_smtp_host');
  $email_address = $this->input->post('email_address');
  $email_password = $this->input->post('email_password');
  $email_smtp_port = $this->input->post('email_smtp_port');
  $cp_private_key = $this->input->post('cp_private_key');
  $cp_public_key = $this->input->post('cp_public_key');
  $cp_merchant_id = $this->input->post('cp_merchant_id');
  $cp_ipn_secret = $this->input->post('cp_ipn_secret');
  $stripe_secret_key = $this->input->post('stripe_secret_key');
  $stripe_published_key = $this->input->post('stripe_published_key');

  $paypal = $this->input->post('PayPal');
  $Bitcoin = $this->input->post('Bitcoin');
  $LiteCoin = $this->input->post('LiteCoin');
  $Dogecoin = $this->input->post('Dogecoin');
  $Stripe = $this->input->post('Stripe');

  $payment_options_array = array();

  if ( isset($paypal) && $paypal == '1' ) {

    $payment_options_array[] = "PayPal";

  }
  if ( isset($Bitcoin) && $Bitcoin == '1' ) {

    $payment_options_array[] = "BTC";

  }
  if ( isset($LiteCoin) && $LiteCoin == '1' ) {

    $payment_options_array[] = "LTC";

  }
  if ( isset($Dogecoin) && $Dogecoin == '1' ) {

    $payment_options_array[] = "DOGE";

  }
  if ( isset($Stripe) && $Stripe == '1' ) {

    $payment_options_array[] = "STRIPE";

  }

  $payment_options = implode(',', $payment_options_array);


  $data=array(
          'website_title' => $website_title,
          'website_logo_url' => $website_logo_url,
          'gateway_fee' => $gateway_fee,
          'payment_options' => $payment_options,
          'max_upload_size' => $max_upload_size,
          'email_smtp_host' => $email_smtp_host,
          'email_address' => $email_address,
          'email_password' => $email_password,
          'email_smtp_port' =>$email_smtp_port,
          'cp_private_key' => $cp_private_key,
          'cp_public_key' => $cp_public_key,
          'cp_merchant_id' => $cp_merchant_id,
          'cp_ipn_secret' => $cp_ipn_secret,
          'stripe_secret_key' => $stripe_secret_key,
          'stripe_published_key' => $stripe_published_key
        );


      $this->db->where('id', 1);
      $this->db->update('website_settings', $data);



}

public function get_all_users($page_number = null) {

  if ($page_number == null) {

    $query = $this->db->get('users', 10, 0);

    $results = $query->result_array();

    return $results;

  }
  else {

    $query = $this->db->get('users', 10, $page_number);

    $results = $query->result_array();

    return $results;

  }


}


public function get_user_info() {

  $user_id = $this->input->post('user_id');

  $query = $this->db->get_where('users', array('id'=>$user_id));

  $result = $query->result_array();

  return $result;


}


public function get_user_products() {

  $user_id = $this->input->post('user_id');

  #Get user's email to do the next query
  $query = $this->db->get_where('users', array('id'=>$user_id));
  
  if ($query->num_rows() > 0) {

    $row = $query->row();

    $user_email = $row->email;

    #Get user's products info
    $query = $this->db->get_where('products', array('email'=>$user_email));
    $result = $query->result_array();

    return $result;
  }
  else {

    //No products returned
    return null;

  }

}



public function get_all_products($username) {

  #Get product id using username
  $query = "SELECT * FROM products WHERE username=?";
  $query = $this->db->query($query, array($username));

  $num_rows = $query->num_rows();

  if ($num_rows > 0) {

    return $query->result_array();

  }
  else {

    return false;

  }
  
  

}

#Check coupon code if its valid right now
public function check_coupon($coupon_name, $product_id) {

  #Get coupon code from coupons table
  $query = "SELECT * FROM coupons WHERE coupon_name=? AND product_id=?";
  $query = $this->db->query($query, array($coupon_name, $product_id));

  $num_rows = $query->num_rows();

  #If this coupon exists...
  if ($num_rows > 0) {

    $row = $query->row();

    $expiry_usage = $row->expiry_usage;

    if ($expiry_usage != '0' || $expiry_usage == '-1') {

      if ($expiry_usage >= 1) {

        $coupon_id = $row->id;

        $expiry_usage = $expiry_usage - 1;

        //Update the expiry, subtract 1
        $data=array(
          'expiry_usage' => $expiry_usage
        );

        $this->db->where('id', $coupon_id);
        $this->db->update('coupons', $data);

      }

      return "yes";

    }
    else {

      return "used";

    }


  }
  else {

    return false;


  }

}

public function get_coupon_percent($coupon_name, $product_id) {

  #Get coupon code from coupons table
  $query = "SELECT * FROM coupons WHERE coupon_name=? AND product_id=?";
  $query = $this->db->query($query, array($coupon_name, $product_id));

  $row = $query->row();

  $percentage = $row->percentage_off;

  return $percentage;


}


public function get_all_coupons() {

  $email = $this->session->userdata('user_email');

  #Get all coupons
  $query = "SELECT * FROM coupons WHERE email=?";
  $query = $this->db->query($query, array($email));

  return $query->result_array();


}

public function add_coupon($product_id, $coupon_name, $coupon_percent, $coupon_expiry) {

  $email = $this->session->userdata('user_email');

  $data=array(
    'email'=> $email,
    'product_id'=>$product_id,
    'coupon_name'=>$coupon_name,
    'percentage_off'=>$coupon_percent / 100,
    'expiry_usage'=>$coupon_expiry
    
  );

  $this->db->insert('coupons',$data);

  return $this->db->insert_id();



}


//Edit coupon
public function edit_coupon($coupon_id, $coupon_name, $coupon_percent, $coupon_expiry) {

  $data=array(
        'coupon_name' => $coupon_name,
        'percentage_off' => $coupon_percent / 100,
        'expiry_usage' => $coupon_expiry
      );

    $this->db->where('id', $coupon_id);
    $this->db->update('coupons', $data);

  $query = "SELECT * FROM coupons WHERE id=?";
  $query = $this->db->query($query, array($coupon_id));
  $row = $query->row();
  
  $product_id = $row->product_id;

  //Get product title
  $query = "SELECT * FROM products WHERE id=?";
  $query = $this->db->query($query, array($product_id));
  $row = $query->row();

  return $row->product_title;

}



public function delete_coupon($coupon_id) {

  //Delete coupons
  $query = "DELETE FROM coupons WHERE id=?";
  $this->db->query($query, array($coupon_id));


}


public function delete_user($user_id) {

  //get user email to be used to get product ids
  $query = "SELECT * FROM users WHERE id=?";
  $query = $this->db->query($query, array($user_id));
  $row = $query->row();

  $username = $row->username;

  //Don't remove admin account
  if (strcasecmp($username, "admin") != 0) {

    $email = $row->email;

    //Get all user's products, put in results array
    $query = "SELECT * FROM products WHERE email=?";
    $query = $this->db->query($query, array($email));

    //As long as there are products, lets get them and delete them
    if ($query->num_rows() > 0) {

      $products = $query->result_array();

      foreach($products as $row) {

        $product_id = $row['id'];

        $this->delete_product($product_id);

      }

    }

    //Delete payment settings
    $query = "SELECT * FROM payment_settings WHERE email=?";
    $query = $this->db->query($query, array($email));
    
    if ($query->num_rows() > 0) {

      //Delete payment settings row
      $query = "DELETE FROM payment_settings WHERE email=?";
      $this->db->query($query, array($email));

    }


    //Delete user - last operation
    $query = "DELETE FROM users WHERE id=?";
    $this->db->query($query, array($user_id));


  }#End not admin username

  
}// End delete user


public function current_monthly_orders_billing() {

  $email = $this->session->userdata('user_email');

  //Get all the products for this month only
  $query = "SELECT * FROM products WHERE email=?";
  $query = $this->db->query($query, array($email));
  $num_rows = $query->num_rows();
  $result_array = $query->result_array();

  $current_orders_array = array();

  if ( $num_rows != 0 ) {

    
    foreach($result_array AS $x) {

      $product_id = $x['id'];
      $product_title = $x['product_title'];
      $product_price = $x['product_price'];

      #Paypal orders
      $query = $this->db->query("SELECT * FROM paypal_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND MONTH(timestamp) = MONTH(CURDATE())

                AND YEAR(timestamp) = YEAR(CURDATE())

                ORDER BY timestamp DESC");

             
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {
        
        $payment_status = $y['payment_status'];
        $gateway_fee = $y['gateway_fee'];
        $time = $y['timestamp'];

        if ( $payment_status == "Completed" ) {

          $current_orders_array[] = array(

              'product_title' => $product_title,
              'product_price' => $product_price,
              'gateway_fee' => $gateway_fee,
              'time' => $time

            );

        }#end if
        
      }#end foreach


      #crypto orders
      $query = $this->db->query("SELECT * FROM crypto_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND MONTH(time) = MONTH(CURDATE())

                AND YEAR(time) = YEAR(CURDATE())

                ORDER BY time DESC");

             
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {
        
        $payment_status = $y['payment_status'];
        $gateway_fee = $y['gateway_fee'];
        $time = $y['time'];

        if ( $payment_status == "Complete" ) {

          $current_orders_array[] = array(

              'product_title' => $product_title,
              'product_price' => $product_price,
              'gateway_fee' => $gateway_fee,
              'time' => $time

            );

        }#end if
        
      }#end foreach


      #Stripe orders
      $query = $this->db->query("SELECT * FROM stripe_orders 

                WHERE product_id=".$this->db->escape($product_id)."

                AND MONTH(time) = MONTH(CURDATE())

                AND YEAR(time) = YEAR(CURDATE())

                ORDER BY time DESC");

             
      $result_array2 = $query->result_array();

      foreach($result_array2 AS $y) {
        
        $gateway_fee = $y['gateway_fee'];
        $time = $y['time'];

          $current_orders_array[] = array(

              'product_title' => $product_title,
              'product_price' => $product_price,
              'gateway_fee' => $gateway_fee,
              'time' => $time

            );

  
        
      }#end foreach


    } #end foreach product

    #return all the current orders for billing

    $current_orders_array = $this->array_sort($current_orders_array, 'time', SORT_DESC);

    return $current_orders_array;


  }# end num rows for products
  else {

    return 0;

  }



}




public function insert_billing_record($to, $amount, $time) {


  $data=array(
    'email'=> $to,
    'amount'=>$amount,
    'time'=>$time
    
  );

  $this->db->insert('billing_records',$data);

}


public function get_billing_history($user_email) {

  #Get all billing history for email
  $query = "SELECT * FROM billing_records WHERE email=?";
  $query = $this->db->query($query, array($user_email));

  return $query->result_array();


}


public function update_billing($email, $amount, $time) {


  #get current balance
  $query = "SELECT * FROM billing WHERE email=?";
  $query = $this->db->query($query, array($email));

  if ( $query->num_rows() > 0 ) {

    $row = $query->row();

    $current_balance = $row->current_balance;

    #if the balance and amount paid is zero then good..
    if ( $current_balance - ($amount / 100) == 0 ) {

      $data=array(
          'current_balance' => 0,
          'last_paid' => $time,
          'deliquent' => 0
          
        );

      $this->db->where('email', $email);
      $this->db->update('billing', $data);

      return true;


    }
    else {

      return false;

    }

  }
  else {


    return false;

  }



}

public function get_all_billing() {

  $query = "SELECT * FROM billing";
  $query = $this->db->query($query);

  return $query->result_array();

}


public function disable_account($email) {

  #get current balance
  $query = "SELECT * FROM billing WHERE email=?";
  $query = $this->db->query($query, array($email));

  if ( $query->num_rows() > 0 ) {


      $data=array(
          'deliquent' => 1
        );

      $this->db->where('email', $email);
      $this->db->update('billing', $data);

      
  }

}



}#End User model
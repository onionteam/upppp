<?php 
class MY_Controller extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        // Assuming that you have loaded all required library in autoload
        $result = $this->db->get_where('website_settings', array('id'=>1));
        $app_conf = $result->result();

        if ($result->num_rows() > 0) {

            foreach( $app_conf as $row )
            {
                #    Custom Settings for PayPro


                #####################################
                #
                #         Website Settings
                #
                #####################################

                
                define('WEBSITE_TITLE', $row->website_title);
                

                //Website Logo URL
                define('WEBSITE_LOGO_URL', $row->website_logo_url);


                // Max upload size for files in MB
                define('MAX_UPLOAD_SIZE', $row->max_upload_size);

                // Gateway fee
                define('GATEWAY_FEE', $row->gateway_fee);

                // Payment Options Enabled
                define('PAYMENT_OPTIONS', $row->payment_options);



                #####################################
                #
                #           Email Settings
                #
                #####################################

                //SMTP Host. Example:  ssl://ns506728.ip-198-99-149.net
                define('EMAIL_SMTP_HOST', $row->email_smtp_host);

                // Email Address.  Example:  paypro@paypro.io
                define('EMAIL_ADDRESS', $row->email_address);

                // Email password.
                define('EMAIL_PASSWORD', $row->email_password);

                //SMTP PORT. Example: 465
                define('EMAIL_SMTP_PORT', $row->email_smtp_port);




                #####################################
                #
                #       Coin Payment Settings
                #
                #####################################

                # If you haven't already, you must register a free account at https://coinpayments.net and setup your API and keys.

                //Coin Payments Private Key.
                define('CP_PRIVATE_KEY', $row->cp_private_key);

                //Coin Payments Public Key.
                define('CP_PUBLIC_KEY', $row->cp_public_key);

                //Coin Payments Merchant ID
                define('CP_MERCHANT_ID', $row->cp_merchant_id);

                //Coin Payments IPN Secret
                define('CP_IPN_SECRET', $row->cp_ipn_secret);


                #####################################
                #
                #       Stripe Settings
                #
                #####################################

                //Stripe secret
                define('STRIPE_SECRET_KEY', $row->stripe_secret_key);

                //Stripe public
                define('STRIPE_PUBLISHED_KEY', $row->stripe_published_key);



                # END PayPro Settings
                #####################################

            } //end foreach

        }//end num rows if
        else {


            define('WEBSITE_TITLE', 'PayPro');

            //Website Logo URL
            define('WEBSITE_LOGO_URL', base_url() . 'assets/images/logo_big.png');

            // Max upload size for files in MB
            define('MAX_UPLOAD_SIZE', 50);

            // Gateway fee
            define('GATEWAY_FEE', 0);

            // Payment Options Enabled
            define('PAYMENT_OPTIONS', 'PayPal,BTC,LTC,DOGE,STRIPE');



            #####################################
            #
            #           Email Settings
            #
            #####################################

            //SMTP Host. Example:  ssl://ns506728.ip-198-99-149.net
            define('EMAIL_SMTP_HOST', '');

            // Email Address.  Example:  paypro@paypro.io
            define('EMAIL_ADDRESS', '');

            // Email password.
            define('EMAIL_PASSWORD', '');

            //SMTP PORT. Example: 465
            define('EMAIL_SMTP_PORT', '');




            #####################################
            #
            #       Coin Payment Settings
            #
            #####################################

            # If you haven't already, you must register a free account at https://coinpayments.net and setup your API and keys.

            //Coin Payments Private Key.
            define('CP_PRIVATE_KEY', '');

            //Coin Payments Public Key.
            define('CP_PUBLIC_KEY', '');

            //Coin Payments Merchant ID
            define('CP_MERCHANT_ID', '');

            //Coin Payments IPN Secret
            define('CP_IPN_SECRET', '');


            #####################################
            #
            #       Stripe Settings
            #
            #####################################

            //Stripe secret
            define('STRIPE_SECRET_KEY', '');

            //Stripe public
            define('STRIPE_PUBLISHED_KEY', '');


        } #end else

        $email = $this->session->userdata('user_email');

        #get account status
        $query = "SELECT * FROM billing WHERE email=?";
        $query = $this->db->query($query, array($email));

        if ( $query->num_rows() > 0 ) {

            $row = $query->row();
            $account_status = $row->deliquent;

            define('ACCOUNT_STATUS', $account_status);


        }
        else {


            define('ACCOUNT_STATUS', 0);

        }


    }
}
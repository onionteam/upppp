<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';

//Login page
$route['login'] = "login/login";

$route['do_login'] = "login/do_login";
$route['do_logout'] = "login/do_logout";

$route['signup'] = "user/signup";

//Admin page
$route['admin'] = "user/admin_page";

//Billing page
$route['billing'] = "user/billing_page";

//Billing cron
$route['billing_cron'] = "user/billing_cron";

#public pages routes
$route['(:num)/(:any)'] = "user/get_public_page/$1/$2";
$route['(:num)'] = "user/get_public_page/$1";

#post api
$route['x/(:num)'] = "user/api_endpoint/$1";

#paypal ipn
$route['ipn/paypal'] = "user/paypal_ipn";

#crypto ipn
$route['ipn/cp'] = "user/crypto_ipn";

#temp download links
$route['download/(:any)'] = "user/temp_download/$1";

$route['paypal/(:any)'] = "paypal/adaptive_payments/$1";

#load more users feed route
$route['/user/user_feed/(:any)'] = "user/user_feed/$1";

#Success page
$route['success'] = "user/success_page";

#all products
$route['u/(:any)'] = "user/all_products/$1";

#all products
$route['redeem_coupon'] = "user/redeem_coupon";

#all products
$route['xt_pro'] = "user/get_free_product_from_coupon";

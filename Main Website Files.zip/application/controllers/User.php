<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends MY_Controller{

 public function __construct()
 {
  parent::__construct();
  $this->load->model('login_model');
  $this->load->model('user_model');
  //$this->clear_cache();
 }

 public function login_from_signup()
 {
  $email = $this->input->post('email');
  $password = md5($this->input->post('pass'));

  $result = $this->login_model->login($email,$password);

  if ($result) {

  	echo "true";

  }

 }

 public function submit_website_settings() {


 	$this->user_model->submit_website_settings();



 }

 public function admin_page() {

 	$data['timezone'] = $this->session->userdata('user_timezone');

 	$data['payment_settings'] = $this->user_model->get_payment_settings();

 	//get website setting variables
 	$data['website_settings'] = $this->user_model->get_website_settings();

 	//total users
	$data['total_users'] = $this->user_model->get_total_users();

	//total earnings by all
	$data['total_earnings_by_all'] = $this->user_model->get_total_earnings_by_all();

	//total sales by all
	$data['total_sales_by_all'] = $this->user_model->get_total_sales_by_all();

	//today sales by all
	$data['today_sales_by_all'] = $this->user_model->get_today_sales_by_all();

	$data['products']= $this->user_model->get_products();

	$data['coupons'] = $this->user_model->get_all_coupons();

	$data['user_model']= $this->user_model;

	//get all users info
	$data['all_users'] = $this->user_model->get_all_users();

	//The left side nav
	$data['left_side_nav'] = $this->load->view('templates/side_menu', $data, true);

	//admin page
	$data['admin_page'] = $this->load->view('templates/admin_page', $data, true);

	$this->load->view('templates/header_dashboard',$data);
	$this->load->view("pages/dashboard", $data);
	$this->load->view('templates/footer_dashboard',$data);


 }


  public function billing_page() {

  	$user_email = $this->session->userdata('user_email');

 	$data['timezone'] = $this->session->userdata('user_timezone');

 	$data['payment_settings'] = $this->user_model->get_payment_settings();

	//get current balance
	$data['current_balance'] = $this->user_model->get_current_balance($user_email);

	//get billing history records
	$data['billing_history'] = $this->user_model->get_billing_history($user_email);

	$data['products']= $this->user_model->get_products();

	$data['coupons'] = $this->user_model->get_all_coupons();

	$data['user_model']= $this->user_model;

	//The left side nav
	$data['left_side_nav'] = $this->load->view('templates/side_menu', $data, true);

	//The left side nav
	$data['current_monthly_orders_billing'] = $this->user_model->current_monthly_orders_billing();

	//billing page
	$data['billing_page'] = $this->load->view('templates/billing_page', $data, true);

	$this->load->view('templates/header_dashboard',$data);
	$this->load->view("pages/dashboard", $data);
	$this->load->view('templates/footer_dashboard',$data);


 }

public function signup() {

  $data['title'] = WEBSITE_TITLE .' - Signup';

  $this->load->view('templates/header_login',$data);
  $this->load->view("pages/signup", $data);
  $this->load->view('templates/footer',$data);

}

public function register() {

  $this->load->library('form_validation');
  // field name, error message, validation rules
  $this->form_validation->set_rules('user', 'Username', 'required|trim|is_unique[users.username]');
  $this->form_validation->set_rules('email', 'Email Address', 'required|trim|valid_email|is_unique[users.email]');
  $this->form_validation->set_rules('pass', 'Repeat Password', 'trim|required|min_length[4]|max_length[32]');
  $this->form_validation->set_rules('pass2', 'Password Confirmation', 'trim|required|matches[pass]');

  if($this->form_validation->run() == FALSE)
  {

    echo validation_errors();

  }
  else
  {
   $this->user_model->add_user();
   $this->login_from_signup();
  }


}

public function do_upload() {

  #if download
	if (isset($_FILES['file']['name'])) {

		$uploaded = $this->user_model->get_product_upload();

			if ($uploaded) {

				unlink(FCPATH . "/uploads/" . $uploaded);
				
			}
			
			$path = $_FILES['file']['name'];

		    $file_name = $this->user_model->do_upload($path);

		    $pos = strpos($file_name, ".zip");

		    if ($pos !== false) {

		    	$callback = array('error'=>'false','file_name'=>$file_name);

		    	echo json_encode($callback);

		    }
		    else {

		    	$callback = array('error'=>$file_name);

		    	echo json_encode($callback);

		    }

	}
}

public function delete_product() {


	$this->user_model->delete_product();

}


public function add_product() {


	$this->load->library('form_validation');
	// field name, error message, validation rules

	$this->form_validation->set_rules('title', 'Product Title', 'trim|required|min_length[4]|max_length[64]');
	$this->form_validation->set_rules('price', 'Product Price', 'trim|required');
	$this->form_validation->set_rules('currencies', 'Product Currencies', 'required|callback_check_currencies');
	$this->form_validation->set_rules('description', 'Product Description', 'trim|required');
	$this->form_validation->set_rules('file_name_upload', 'Product File', 'callback_check_file');
	$this->form_validation->set_rules('direct_url', 'Direct URL', 'callback_check_direct_url');
	$this->form_validation->set_rules('serials', 'Product Serials', 'callback_check_serials');



	if($this->form_validation->run() == FALSE)
	{

		echo validation_errors();

	}
	else
	{

		$product_id = $this->user_model->add_product();

		$this->user_model->add_public_page($product_id);

		echo "true";

	}


}

public function check_direct_url($direct_url) {

	if ( $this->input->post('type') == "Direct URL" ) {

		if (empty($direct_url)) {

			$this->form_validation->set_message('check_direct_url', 'You must input a direct URL.');
				
			return false;
			
		}
		else {
			return true;
		}

	}

	return true;


}


public function recent_payments_modal() {


	$html='';

	$id = $this->input->post('id');

    $data['recent_order'] = $this->user_model->get_recent_order($id);

    $data['user_model'] = $this->user_model;

    $html = $this->load->view('pages/modal_recent_payments', $data, true); // returns view as data

    echo $html;



}


public function edit_product() {


	$this->load->library('form_validation');
	// field name, error message, validation rules

	$this->form_validation->set_rules('title', 'Product Title', 'trim|required|min_length[4]|max_length[64]');
	$this->form_validation->set_rules('price', 'Product Price', 'trim|required');
	$this->form_validation->set_rules('currencies', 'Product Currencies', 'required|callback_check_currencies');
	$this->form_validation->set_rules('description', 'Product Description', 'trim|required');
	$this->form_validation->set_rules('file_name_upload', 'Product File', 'callback_check_file');
	$this->form_validation->set_rules('serials', 'Product Serials', 'callback_check_serials');
	$this->form_validation->set_rules('direct_url', 'Direct URL', 'callback_check_direct_url');

	if($this->form_validation->run() == FALSE)
	{

		echo validation_errors();

	}
	else
	{

		$product_id = $this->input->post('product_id');

		$err = $this->user_model->edit_product($product_id);

		//$this->user_model->add_public_page($product_id);

		if ($err != null) {

			echo $err;

		}
		else {

			echo "true";

		}

	}


}

public function check_file($file) {

	if ( $this->input->post('type') == "Download" ) {

		if ($this->input->post('file_name_upload') == '') {

			$uploaded = $this->user_model->get_product_upload();

			if ($uploaded) {

				return true;

			}
			else {

				$this->form_validation->set_message('check_file', 'You must upload a zip file.');
				
				return false;

			}

			
		}
		else {
			return true;
		}

	}

	return true;

}

public function check_serials($serials) {

	if ( $this->input->post('type') == "Code/Serial" ) {


		if (empty($serials)) {

			$this->form_validation->set_message('serials', 'You are missing serials or codes.');
			return false;
		}
		else {
			return true;
		}

	}

	return true;

}


public function check_currencies($currencies) {

	$json_decode = json_decode($currencies, TRUE);

	//print_r($json_decode);

	$count = 0;
	foreach ($json_decode AS $key=>$val) {

		//echo $val[0];

		if (empty($val)) {

			$count = $count +1;

		}
		else {

			$currency_set[] = $key;

		}

		

	}


	#Check that the user has payment address set if choosing currency
	if ( !empty($currency_set) ) {

		foreach ($currency_set AS $each) {

			$check_payment_settings = $this->user_model->check_payment_settings($each);

			if (empty($check_payment_settings)) {

				$this->form_validation->set_message('check_currencies', "The %s field needs a payment address set for $each.");
				
				return FALSE;

			}

		}

	}

	if ($count == 5) {

		$this->form_validation->set_message('check_currencies', 'The %s field should be checked.');
		return FALSE;

	}
	else {

		return TRUE;
	}


}



public function get_edit_product() {

	$html='';

	$user_email = $this->session->userdata('user_email');

	$product_id = $this->input->post('product_id');

    $data['product'] = $this->user_model->get_product_edit($product_id, $user_email);

    $data['user_model'] = $this->user_model;

    $html = $this->load->view('pages/modal_edit_product', $data, true); // returns view as data

    echo $html;

}



#Get post for public post/questions
 public function get_public_page($slug = null, $title = null) {

  $data['product'] = $this->user_model->get_product($slug);

  if ($data['product'] != false) {


	  foreach($data['product'] as $row) {

	    $product_title = $row['product_title'];

	    $user_email = $row['email'];

	    $serials = $row['product_serials'];
	 
	  }

	  if (empty($serials)) {

	  	$serials_count = 0;

	  }
	  else {

	  	$serials_array = explode(',', $serials);

	  	$serials_count = count($serials_array);

	  }


	  $title_url = strtolower(url_title($product_title));

	 

	  if ($title == $title_url) {

	  	$data['deleted']= false;

	  	$data['stripe_keys'] = $this->user_model->get_stripe_keys($user_email);

	  	$data['quantity'] = $serials_count;
	    
	  	$data['title']= WEBSITE_TITLE;

	  	$data['page_slug']= $slug;

	  	$data['user_model'] = $this->user_model;

	    $this->load->view('templates/header_public', $data);
	    $this->load->view("pages/public_page", $data);
	    $this->load->view('templates/footer', $data);

	  }
	  else {

	    //$title = url_title($question,'dash', true);

	    redirect(base_url() . "$slug/$title_url");

	  }


  }
  else {

  	#Someone deleted the page, so tell them

  	$data['user_model'] = $this->user_model;

  	$data['deleted']= true;

  	$data['title']= WEBSITE_TITLE;

	$this->load->view('templates/header_public', $data);
	$this->load->view("pages/public_page", $data);
	$this->load->view('templates/footer', $data);


  }

  



  //

 }


#api endpoint
public function api_endpoint($slug = null) {

	$quantity = 1;

	$action = $this->input->post('action');
	$price = $this->input->post('price');
	$currency = $this->input->post('currency');
	$email = $this->input->post('email');
	$quantity = $this->input->post('quantity');
	$couponCode = $this->input->post('couponCode');
	$success_url = $this->input->post('success_url');
	$affiliate = $this->input->post('affiliate');


	$title = $this->user_model->get_title($slug);

	$product_id = $this->user_model->get_product_id($slug);

	$amount = $price * $quantity;

	$custom = $product_id . "," . $email;

	//coupon stuff
	if ( $couponCode != null || $couponCode != 0 ) {


		$amount_subtract = $amount * $couponCode;

		$amount = $amount - $amount_subtract;


	}


	#Transaction is paypal
	if ($currency == "PayPal") {

		$action = "pp-checkout";

		$payment_address = $this->user_model->get_payment($slug, $currency);

		#create array with all info
		$data = array(

			'response'=> array(

				'action'=> $action,

				'data'=>array(

					'sub' => false,

					'business' => $payment_address,

					'itemname' => $title,

					'itemnumber' => "2413",

					'amount' => $amount,

					'custom' => $custom,

					'success_url' => base_url() . "success",

					'shipping' => '',

					'quantity' => $quantity


					)



				)



			);

		echo json_encode($data);

	}
	elseif($currency == "STRIPE") {

		$action = "stripe";

		//$payment_address = $this->user_model->get_payment($slug, $currency);

		#create array with all info
		$data = array(

			'response'=> array(

				'action'=> $action,

				'data'=>array(

					'sub' => false,

					'itemname' => $title,

					'itemnumber' => "2413",

					'amount' => $amount,

					'custom' => $custom,

					'success_url' => '',

					'shipping' => '',

					'quantity' => $quantity


					)



				)



			);

		echo json_encode($data);


	}
	else {

		#check the transaction
		if ($action == "checktx") {

			$title = $this->user_model->get_title($slug);

			$txid = $this->input->post('txid');

			$price = $this->user_model->get_price($slug);

			$result = $this->coinpayments_api_call("get_tx_info", array('txid'=>$txid));

			#create array with all info
			$data = array(

				'response'=> array(

						'txid' => $txid,
						'received' => $result['result']['receivedf'],
						'amount' => ($result['result']['amountf']),
						'expires' => $result['result']['time_expires'],
						'coin' => $result['result']['coin'],
						'address' => $result['result']['payment_address'],
						'title' => $title,
						'price' => $price
						

					)

				);

			echo json_encode($data);




		}
		else {

			//if ($currency == "BTC") {

				//$currency = "LTCT";

			//}


			#Create the payment request
			$this->load->library('coinpayments');

			//$cps = new CoinPaymentsAPI();
			$this->coinpayments->Setup(CP_PRIVATE_KEY, CP_PUBLIC_KEY);

			$req = array(
				'amount' => $amount,
				'currency1' => 'USD',
				'currency2' => $currency,
				'address' => '', // send to address in the Coin Acceptance Settings page
				'item_name' => $title,
				'ipn_url' => base_url() . 'ipn/cp',
				'custom' => $email
			);
			// See https://www.coinpayments.net/merchant-tools-api for all of the available fields
					
			$result = $this->coinpayments->CreateTransaction($req);
			if ($result['error'] == 'ok') {
				$le = php_sapi_name() == 'cli' ? "\n" : '<br />';
				//print 'Transaction created with ID: '.$result['result']['txn_id'].$le;
				//print 'Buyer should send '.sprintf('%.08f', $result['result']['amount']).' BTC'.$le;
				//print 'Status URL: '.$result['result']['status_url'].$le;

				//$amount = $result['result']['amount'] * .005;

				$send_amount = $result['result']['amount'];

				$send_address = $result['result']['address'];

				$txid = $result['result']['txn_id'];
			} else {
				echo 'Error: '.$result['error']."\n";
			}

			#Insert new crypto order into crypto_orders table
			$this->user_model->insert_crypto_order($product_id, $txid, $amount);


			#transaction is crypto
			$action = "display-crypto";

			#create array with all info
			$data = array(

				'response'=> array(

					'action'=> $action,

					'data'=>array(

						'txid' => $txid,

						'amount' =>$amount

						)

					)

				);

			echo json_encode($data);


			#Send email to user with the send info

			$to = $email;

			#Send email with product download if status complete
			$this->load->library('email');

			$config['protocol'] = 'smtp';
			$config['smtp_host'] = EMAIL_SMTP_HOST;
			$config['smtp_user'] = EMAIL_ADDRESS;
			$config['smtp_pass'] = EMAIL_PASSWORD;
			$config['smtp_port'] = EMAIL_SMTP_PORT;
			$config['wordwrap'] = TRUE;
			$config['mailtype'] = 'html';

			$this->email->initialize($config);

			$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
			$this->email->to("$to"); 

			$this->email->subject('Purchase Info');


			$this->email->message("Hello,<br/><br/>

			  Please send $send_amount $currency to $send_address

			  <br/><br/>

			  Send this amount within 60 minutes. Once received, please allow 15 minutes for your download link to arrive.

			  <br/><br/>

			  Product: $title <br/>
			  Price:  $amount USD

			  <br/><br/>

			  If you have any questions please email us at ".EMAIL_ADDRESS."

			  <br/><br/>

			  Regards,<br/><br/>

			  ".WEBSITE_TITLE." Team<br/>
			  ".base_url()."

			");

			$this->email->send();


		}#end else

	}

	

	


}

public function stripe_check() {

	require_once(FCPATH . '/assets/libraries/stripe-php-2.2.0/init.php');

	$to = $this->input->post('email');

	$amount = $this->input->post('amount');

	$token = $this->input->post('stripeToken');

	$product_id = $this->input->post('product_id');

	$user_email = $this->user_model->get_user_email($product_id);

	$stripe_keys = $this->user_model->get_stripe_keys($user_email);

	foreach($stripe_keys AS $row) {

		$stripe_secret_key = trim($row['stripe_secret_key']);

	}

	\Stripe\Stripe::setApiKey($stripe_secret_key);

	// Create the charge on Stripe's servers - this will charge the user's card
	try {
			$charge = \Stripe\Charge::create(array(
			  "amount" => $amount, // amount in cents, again
			  "currency" => "usd",
			  "source" => $token,
			  "description" => "Example charge")
			);

			# Check if product is serial or download
			$type = $this->user_model->check_type($product_id);

			if ($type == "Download") {

				#Create download link for user
				$random_url = $this->user_model->insert_random_link($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Insert the order
				$this->user_model->insert_stripe_order($product_id, $to, $amount, $time);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your download: ".base_url()."download/$random_url 

				  <br/><br/>

				  This download link will be live for 1 hour starting from the initial download.

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();





			}
			elseif ($type == "Code/Serial") {

				#Get serial

				$serial = $this->user_model->get_serial($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Insert the order
				$this->user_model->insert_stripe_order($product_id, $to, $amount, $time);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your serial: $serial

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();



			}
			elseif ($type == "Direct URL") {

				#Get direct url

				$direct_url = $this->user_model->get_direct_url($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Insert the order
				$this->user_model->insert_stripe_order($product_id, $to, $amount, $time);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your direct url: $direct_url

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();



			}

			
			#send response of true and no errors
			$data = array(

				'err'=> 'false'

				);

			echo json_encode($data);


	} catch(\Stripe\Error\Card $e) {

		$err = $e->getMessage();

		$data = array(

			'err'=> 'true',
			'message' => $err

			);

		echo json_encode($data);

	}catch(\Stripe\Error\InvalidRequest $e) {

		$err = $e->getMessage();

		$data = array(

			'err'=> 'true',
			'message' => $err

			);

		echo json_encode($data);

	}

}//end stripe check



//Start Stripe Bill Pay
public function stripe_billpay() {

	require_once(FCPATH . '/assets/libraries/stripe-php-2.2.0/init.php');

	$to = $this->input->post('email');

	$amount = $this->input->post('amount');

	$token = $this->input->post('stripeToken');

	$stripe_secret_key = STRIPE_SECRET_KEY;

	\Stripe\Stripe::setApiKey($stripe_secret_key);

	// Create the charge on Stripe's servers - this will charge the user's card
	try {
			$charge = \Stripe\Charge::create(array(
			  "amount" => $amount, // amount in cents, again
			  "currency" => "usd",
			  "source" => $token,
			  "description" => "Bill Pay")
			);

			
				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Insert the billing history record
				$this->user_model->insert_billing_record($to, $amount, $time);

				#Remove current balance and update last paid in billing table
				$billing_check = $this->user_model->update_billing($to, $amount, $time);

				#if current balance is correct at 0, no discreptency
				if ($billing_check) {

					#Send email with product download if status complete
					$this->load->library('email');

					$config['protocol'] = 'smtp';
					$config['smtp_host'] = EMAIL_SMTP_HOST;
					$config['smtp_user'] = EMAIL_ADDRESS;
					$config['smtp_pass'] = EMAIL_PASSWORD;
					$config['smtp_port'] = EMAIL_SMTP_PORT;
					$config['wordwrap'] = TRUE;
					$config['mailtype'] = 'html';

					$this->email->initialize($config);

					$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
					$this->email->to("$to"); 

					$this->email->subject('Thank You');


					$this->email->message("Hello,<br/><br/>

					  Thank you for your payment.

					  <br/><br/>

					  We have received your $". $amount / 100 ." payment.

					  <br/><br/>

					  If you have any questions please email us at ".EMAIL_ADDRESS."

					  <br/><br/>

					  Regards,<br/><br/>

					  ".WEBSITE_TITLE." Team<br/>
					  ".base_url()."

					");

					$this->email->send();

				
					#send response of true and no errors
					$data = array(

						'err'=> 'false'

						);

					echo json_encode($data);

				}//end billing check
				else {

					#send error response with discreptency
					$data = array(

						'err'=> 'true',
						'message' => "There was an issue with your payment. Please contact the administrator."

						);

					echo json_encode($data);

				}

	} catch(\Stripe\Error\Card $e) {

		$err = $e->getMessage();

		$data = array(

			'err'=> 'true',
			'message' => $err

			);

		echo json_encode($data);

	}catch(\Stripe\Error\InvalidRequest $e) {

		$err = $e->getMessage();

		$data = array(

			'err'=> 'true',
			'message' => $err

			);

		echo json_encode($data);

	}

}//end stripe bill pay








public function coinpayments_api_call($cmd, $req = array()) { 
    // Fill these in from your API Keys page 
    $public_key = CP_PUBLIC_KEY; 
    $private_key = CP_PRIVATE_KEY; 
     
    // Set the API command and required fields 
    $req['version'] = 1; 
    $req['cmd'] = $cmd; 
    $req['key'] = $public_key; 
    $req['format'] = 'json'; //supported values are json and xml 
     
    // Generate the query string 
    $post_data = http_build_query($req, '', '&'); 
     
    // Calculate the HMAC signature on the POST data 
    $hmac = hash_hmac('sha512', $post_data, $private_key); 
     
    // Create cURL handle and initialize (if needed) 
    static $ch = NULL; 
    if ($ch === NULL) { 
        $ch = curl_init('https://www.coinpayments.net/api.php'); 
        curl_setopt($ch, CURLOPT_FAILONERROR, TRUE); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
    } 
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('HMAC: '.$hmac)); 
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data); 
     
    // Execute the call and close cURL handle      
    $data = curl_exec($ch);                 
    // Parse and return data if successful. 
    if ($data !== FALSE) { 
        if (PHP_INT_SIZE < 8 && version_compare(PHP_VERSION, '5.4.0') >= 0) { 
            // We are on 32-bit PHP, so use the bigint as string option. If you are using any API calls with Satoshis it is highly NOT recommended to use 32-bit PHP 
            $dec = json_decode($data, TRUE, 512, JSON_BIGINT_AS_STRING); 
        } else { 
            $dec = json_decode($data, TRUE); 
        } 
        if ($dec !== NULL && count($dec)) { 
            return $dec; 
        } else { 
            // If you are using PHP 5.5.0 or higher you can use json_last_error_msg() for a better error message 
            return array('error' => 'Unable to parse JSON result ('.json_last_error().')'); 
        } 
    } else { 
        return array('error' => 'cURL error: '.curl_error($ch)); 
    } 
} 

public function paypal_ipn() {


	define("DEBUG", 1);

	// Set to 0 once you're ready to go live
	define("USE_SANDBOX", 0);


	define("LOG_FILE", "./ipn.log");


	// Read POST data
	// reading posted data directly from $_POST causes serialization
	// issues with array data in POST. Reading raw POST data from input stream instead.
	$raw_post_data = file_get_contents('php://input');
	$raw_post_array = explode('&', $raw_post_data);
	$myPost = array();
	foreach ($raw_post_array as $keyval) {
		$keyval = explode ('=', $keyval);
		if (count($keyval) == 2)
			$myPost[$keyval[0]] = urldecode($keyval[1]);
	}
	// read the post from PayPal system and add 'cmd'
	$req = 'cmd=_notify-validate';
	if(function_exists('get_magic_quotes_gpc')) {
		$get_magic_quotes_exists = true;
	}
	foreach ($myPost as $key => $value) {
		if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
			$value = urlencode(stripslashes($value));
		} else {
			$value = urlencode($value);
		}
		$req .= "&$key=$value";
	}

	// Post IPN data back to PayPal to validate the IPN data is genuine
	// Without this step anyone can fake IPN data

	if(USE_SANDBOX == true) {
		$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
	} else {
		$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
	}

	$ch = curl_init($paypal_url);
	if ($ch == FALSE) {
		return FALSE;
	}

	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
	curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);

	if(DEBUG == true) {
		curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
	}

	// CONFIG: Optional proxy configuration
	//curl_setopt($ch, CURLOPT_PROXY, $proxy);
	//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);

	// Set TCP timeout to 30 seconds
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));

	// CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
	// of the certificate as shown below. Ensure the file is readable by the webserver.
	// This is mandatory for some environments.

	//$cert = __DIR__ . "./cacert.pem";
	//curl_setopt($ch, CURLOPT_CAINFO, $cert);

	$res = curl_exec($ch);
	if (curl_errno($ch) != 0) // cURL error
		{
		if(DEBUG == true) {	
			error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
		}
		curl_close($ch);
		exit;

	} else {
			// Log the entire HTTP response if debug is switched on.
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
				error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);

				// Split response headers and payload
				list($headers, $res) = explode("\r\n\r\n", $res, 2);
			}
			curl_close($ch);
	}

	// Inspect IPN validation result and act accordingly

	//if (strcmp ($res, "VERIFIED") == 0) {
	if (preg_match("!(VERIFIED)\s*\Z!",$res))  { 
		// check whether the payment_status is Completed
		// check that txn_id has not been previously processed
		// check that receiver_email is your PayPal email
		// check that payment_amount/payment_currency are correct
		// process payment and mark item as paid.

		// assign posted variables to local variables
		//$item_name = $_POST['item_name'];
		//$item_number = $_POST['item_number'];
		//$first_name = $_POST['first_name'];
		//$last_name = $_POST['last_name'];
		$payment_status = $_POST['payment_status'];
		$payment_amount = $_POST['mc_gross'];
		$payment_currency = $_POST['mc_currency'];
		$txn_id = $_POST['txn_id'];
		$paypal_email = $_POST['payer_email'];

		#We need to split custom because it has product id and user email
		$custom = explode(",",$_POST['custom']);

		$product_id = $custom[0];
		$to = $custom[1];
		
		#Time stamp, BAM
		$timestamp = time();
    	$time = date('c',$timestamp);


		//If transaction ID is NOT the same as another one already in our db


    	#Insert the order into paypal_orders table
		$this->user_model->insert_paypal_order($product_id, $payment_status, $payment_amount, $payment_currency, $paypal_email, $txn_id, $time);



		if ($payment_status == "Completed") {


			# Check if product is serial or download
			$type = $this->user_model->check_type($product_id);

			if ($type == "Download") {

				#Create download link for user
				$random_url = $this->user_model->insert_random_link($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your download: ".base_url()."download/$random_url 

				  <br/><br/>

				  This download link will be live for 1 hour starting from the initial download.

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();





			}
			elseif ($type == "Code/Serial") {

				#Get serial

				$serial = $this->user_model->get_serial($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your serial: $serial

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();



			}
			elseif ($type == "Direct URL") {

				#Get direct url

				$direct_url = $this->user_model->get_direct_url($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your direct url: $direct_url

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();


		}



	}

		
	if(DEBUG == true) {
			error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
		}
	elseif (strcmp ($res, "INVALID") == 0) {
		// log for manual investigation
		// Add business logic here which deals with invalid IPN messages
		if(DEBUG == true) {
			error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
		}
	}


  }


} #End paypal IPN


public function crypto_ipn() {

	
	$merchant_id = CP_MERCHANT_ID;
	$secret = CP_IPN_SECRET;

	
	if (!isset($_SERVER['HTTP_HMAC']) || empty($_SERVER['HTTP_HMAC'])) {
	  die("No HMAC signature sent");
	}
	

	$request = file_get_contents('php://input');
	if ($request === FALSE || empty($request)) {
	  die("Error reading POST data");
	}
	
	$merchant = isset($_POST['merchant']) ? $_POST['merchant']:'';
	if (empty($merchant)) {
	  die("No Merchant ID passed");
	}
	if ($merchant != $merchant_id) {
	  die("Invalid Merchant ID");
	}

	$hmac = hash_hmac("sha512", $request, $secret);
	if ($hmac != $_SERVER['HTTP_HMAC']) {
	  die("HMAC signature does not match");
	}
	

	
	#num rows for txn id..does it already exist?
	$check_crypto = $this->user_model->check_crypto_ipn();

	if ( $check_crypto == 1 ) {

		$update_crypto = $this->user_model->update_crypto_ipn();

		#is the order complete now?

		if ( $update_crypto == 1 ) {

			$txn_id = $_POST['txn_id'];

			$to = $_POST['custom'];

			$product_id = $this->user_model->get_product_id_txn($txn_id);

			# Check if product is serial or download
			$type = $this->user_model->check_type($product_id);

			if ($type == "Download") {

				#Create download link for user
				$random_url = $this->user_model->insert_random_link($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your download: ".base_url()."download/$random_url 

				  <br/><br/>

				  This download link will be live for 1 hour starting from the initial download.

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();





			}
			elseif ($type == "Code/Serial") {

				#Get serial

				$serial = $this->user_model->get_serial($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your serial: $serial

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();



			}
			elseif ($type == "Direct URL") {

				#Get direct url

				$direct_url = $this->user_model->get_direct_url($product_id);

				#Time stamp, BAM
				$timestamp = time();
	    		$time = date('c',$timestamp);

				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$to"); 

				$this->email->subject('Your Download');


				$this->email->message("Hello,<br/><br/>

				  Here is your direct url: $direct_url

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();

			}

			####################################

			## Withdraw and send to owner
			$currency  = $_POST['currency2'];

			#Get email address
			$email = $this->user_model->get_user_email($product_id);

			#get crypto address to send to
			$crypto_address = $this->user_model->get_crypto_address($email, $currency);

			#get the net to be paid
			$crypto_net = $this->user_model->get_crypto_net($txn_id);

			#get crypto order id
			$order_id = $this->user_model->get_order_id($txn_id);

			file_put_contents('log.txt', "Variables: $currency, $email, $crypto_address, $crypto_net, $order_id\n", FILE_APPEND | LOCK_EX);

			#Create the withdraw
			$this->load->library('coinpayments');

			//$cps = new CoinPaymentsAPI();
			$this->coinpayments->Setup(CP_PRIVATE_KEY, CP_PUBLIC_KEY);
					
		 	# Create withdrawal
			$result = $this->coinpayments->CreateWithdrawal($crypto_net, $currency, $crypto_address, 1);
			if ($result['error'] == 'ok') {
				$le = php_sapi_name() == 'cli' ? "\n" : '<br />';

				$withdrawal_txn_id = $result['result']['id'];
				
			} else {
				echo 'Error: '.$result['error']."\n";

				$error = $result['error'];

				file_put_contents('log.txt', "Error: $error\n\n", FILE_APPEND | LOCK_EX);
			}

			#update withdrawal
			$this->user_model->insert_withdrawal($order_id, $withdrawal_txn_id, $crypto_net);

		}


	}



}

public function temp_download($temp_url = null) {


	$timestamp = time();
    $now = date('c',$timestamp);

    $end_time = $this->user_model->get_end_time($temp_url);

    if ($now >= $end_time && !empty($end_time)) {

    	echo "This download has expired.";

    }
    else {

		$this->load->helper('url');

		$fakeFileName = url_title($this->user_model->get_download_title($temp_url));
		$fakeFileName = $fakeFileName . ".zip";
		$realFileName = $this->user_model->get_download_file($temp_url);

		$file = FCPATH . "/uploads/".$realFileName;
		$fp = fopen($file, 'rb');

		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=$fakeFileName");
		header("Content-Length: " . filesize($file));
		fpassthru($fp);

		$this->user_model->set_download_time($temp_url);

	}
		


}


public function payment_settings() {

	$user_email = $this->session->userdata('user_email');

	$this->user_model->payment_settings($user_email);



}

public function change_password() {

	$user_email = $this->session->userdata('user_email');

	if ($user_email == 'tom') {

		echo "false";


	}
	else {


		$check = $this->user_model->change_password($user_email);

		if ($check == false) {

			echo "false";

		}

	}


}


public function user_feed($page_number = null) {

    $html='';

    //get all users info
	$data['all_users'] = $this->user_model->get_all_users($page_number);

    $data['page_number'] = $page_number;
    $data['user_model'] = $this->user_model;

    $html = $this->load->view('pages/user_feed', $data, true); // returns view as data

    echo $html;

}



public function user_management_modal() {


	$html='';

    //get specific user info
	$data['user_info'] = $this->user_model->get_user_info();

	//get user's products with info
	$data['user_products'] = $this->user_model->get_user_products();

    $data['user_model'] = $this->user_model;

    $html = $this->load->view('pages/modal_user_management', $data, true); // returns view as data

    echo $html;


}

// Upload image from description
public function upload_image_post() {

    $config['upload_path'] = './uploads_imgs/';
    $config['allowed_types'] = 'gif|jpg|png|tiff|jpeg|bmp|webp';
    $config['max_size'] = '20000';
    $config['max_width']  = '5000';
    $config['max_height']  = '5000';

    $path = $_FILES['file']['name'];
    // Get filename.
    //$temp = explode(".", $_FILES["file"]["name"]);

    $ext = pathinfo($path, PATHINFO_EXTENSION);
    //$ext = end($temp);

    $new_name = sha1(microtime()) . "." . $ext;
    //$new_name = $this->random_string(10) . "." . $ext;
    $config['file_name'] = $new_name;
    $full_path =  base_url() . "uploads_imgs/" . $new_name;

    $this->load->library('upload', $config);

    $field_name = "file";
      

        if ( ! $this->upload->do_upload($field_name))
        {
          $error = array('error' => $this->upload->display_errors());

          print_r($error);

          $this->welcome($error);
        }
        else
        {

          $data = array('upload_data' => $this->upload->data());
          
          // Generate response.
          $response = new StdClass;
          $response->link = $full_path;
          echo stripslashes(json_encode($response));
          
        }


}

//Delete image from description when uploaded
public function delete_image_post() {


  $src = $this->input->post('src');

  $full_path = FCPATH . $src;

  unlink($full_path);


}


public function send_test_email() {


	$to = $this->session->userdata('user_email');

	#Send test email to admin's email account
	$this->load->library('email');

	$config['protocol'] = 'smtp';
	$config['smtp_host'] = EMAIL_SMTP_HOST;
	$config['smtp_user'] = EMAIL_ADDRESS;
	$config['smtp_pass'] = EMAIL_PASSWORD;
	$config['smtp_port'] = EMAIL_SMTP_PORT;
	$config['wordwrap'] = TRUE;
	$config['mailtype'] = 'html';

	$this->email->initialize($config);

	$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
	$this->email->to("$to"); 

	$this->email->subject('Your Test Email');


	$this->email->message("Hello,<br/><br/>

	  Here is your test email.  It's working!

	  <br/><br/>

	  If you have any questions please email us at ".EMAIL_ADDRESS."

	  <br/><br/>

	  Regards,<br/><br/>

	  ".WEBSITE_TITLE." Team<br/>
	  ".base_url()."

	");

	$this->email->send();

}



public function success_page() {

	$data['title']= WEBSITE_TITLE;

	$this->load->view('templates/header_public',$data);
	$this->load->view("pages/success", $data);
	$this->load->view('templates/footer',$data);


}



public function all_products($username = null) {

	$data['title']= WEBSITE_TITLE;

	$data['username'] = $username;

	$data['all_products'] = $this->user_model->get_all_products($username);

	$data['user_model'] = $this->user_model;

	$this->load->view('templates/header_public',$data);
	$this->load->view("pages/all_products", $data);
	$this->load->view('templates/footer',$data);


}


//Coupon stuff
public function redeem_coupon() {


	//get the posted variables
	$redeem_coupon = $this->input->post('redeem_coupon');
	$coupon_name = $this->input->post('coupon_name');
	$product_id = $this->input->post('product_id');

	if ($redeem_coupon == true) {

		//check if the coupon is good or not
		$check_coupon = $this->user_model->check_coupon($coupon_name, $product_id);

		if($check_coupon == "used") {

			$data = array(

				'response'=> "used"

			);

			echo json_encode($data);

		}
		elseif ($check_coupon == "yes") {

			$percentage = $this->user_model->get_coupon_percent($coupon_name, $product_id);

			$data = array(

				'response'=> $percentage

			);

			echo json_encode($data);

		}
		else {

			$data = array(

				'response'=> "false"

			);

			echo json_encode($data);

		}




	}
	else {

		$data = array(

			'response'=> "false"

		);

		echo json_encode($data);

	}

}


	
public function get_free_product_from_coupon() {

	//get the posted variables
	$redeem_coupon = $this->input->post('redeem_coupon');
	$coupon_name = $this->input->post('coupon_name');
	$product_id = $this->input->post('product_id');
	$to = $this->input->post('email');

	if ($redeem_coupon == true) {

		//check if the coupon is good or not
		$check_coupon = $this->user_model->check_coupon($coupon_name, $product_id);

		if ($check_coupon == "yes") {

			$percentage = $this->user_model->get_coupon_percent($coupon_name, $product_id);

			if ($percentage >= 1 || $percentage == "1") {

				#Free product sent out

				# Check if product is serial or download
				$type = $this->user_model->check_type($product_id);

				if ($type == "Download") {

					#Create download link for user
					$random_url = $this->user_model->insert_random_link($product_id);

					#Time stamp, BAM
					$timestamp = time();
		    		$time = date('c',$timestamp);

					#Send email with product download if status complete
					$this->load->library('email');

					$config['protocol'] = 'smtp';
					$config['smtp_host'] = EMAIL_SMTP_HOST;
					$config['smtp_user'] = EMAIL_ADDRESS;
					$config['smtp_pass'] = EMAIL_PASSWORD;
					$config['smtp_port'] = EMAIL_SMTP_PORT;
					$config['wordwrap'] = TRUE;
					$config['mailtype'] = 'html';

					$this->email->initialize($config);

					$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
					$this->email->to("$to"); 

					$this->email->subject('Your Download');


					$this->email->message("Hello,<br/><br/>

					  Here is your download: ".base_url()."download/$random_url 

					  <br/><br/>

					  This download link will be live for 1 hour starting from the initial download.

					  <br/><br/>

					  If you have any questions please email us at ".EMAIL_ADDRESS."

					  <br/><br/>

					  Regards,<br/><br/>

					  ".WEBSITE_TITLE." Team<br/>
					  ".base_url()."

					");

					$this->email->send();





				}
				elseif ($type == "Code/Serial") {

					#Get serial

					$serial = $this->user_model->get_serial($product_id);

					#Time stamp, BAM
					$timestamp = time();
		    		$time = date('c',$timestamp);

					#Send email with product download if status complete
					$this->load->library('email');

					$config['protocol'] = 'smtp';
					$config['smtp_host'] = EMAIL_SMTP_HOST;
					$config['smtp_user'] = EMAIL_ADDRESS;
					$config['smtp_pass'] = EMAIL_PASSWORD;
					$config['smtp_port'] = EMAIL_SMTP_PORT;
					$config['wordwrap'] = TRUE;
					$config['mailtype'] = 'html';

					$this->email->initialize($config);

					$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
					$this->email->to("$to"); 

					$this->email->subject('Your Download');


					$this->email->message("Hello,<br/><br/>

					  Here is your serial: $serial

					  <br/><br/>

					  If you have any questions please email us at ".EMAIL_ADDRESS."

					  <br/><br/>

					  Regards,<br/><br/>

					  ".WEBSITE_TITLE." Team<br/>
					  ".base_url()."

					");

					$this->email->send();



				}
				elseif ($type == "Direct URL") {

					#Get direct url

					$direct_url = $this->user_model->get_direct_url($product_id);

					#Time stamp, BAM
					$timestamp = time();
		    		$time = date('c',$timestamp);

					#Send email with product download if status complete
					$this->load->library('email');

					$config['protocol'] = 'smtp';
					$config['smtp_host'] = EMAIL_SMTP_HOST;
					$config['smtp_user'] = EMAIL_ADDRESS;
					$config['smtp_pass'] = EMAIL_PASSWORD;
					$config['smtp_port'] = EMAIL_SMTP_PORT;
					$config['wordwrap'] = TRUE;
					$config['mailtype'] = 'html';

					$this->email->initialize($config);

					$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
					$this->email->to("$to"); 

					$this->email->subject('Your Download');


					$this->email->message("Hello,<br/><br/>

					  Here is your direct url: $direct_url

					  <br/><br/>

					  If you have any questions please email us at ".EMAIL_ADDRESS."

					  <br/><br/>

					  Regards,<br/><br/>

					  ".WEBSITE_TITLE." Team<br/>
					  ".base_url()."

					");

					$this->email->send();

				}



				#Insert free order





				$data = array(

					'response'=> "yes"

				);

				echo json_encode($data);


			}
			elseif($check_coupon == "used") {

				$data = array(

					'response'=> "used"

				);

				echo json_encode($data);

			}
			else {

				$data = array(

					'response'=> "false"

				);

				echo json_encode($data);

			}

			

		}

	}
	else {

		$data = array(

			'response'=> "false"

		);

		echo json_encode($data);

	}



}

	


public function add_coupon() {

	//get the posted variables
	$product_id = $this->input->post('product_id');
	$coupon_name = $this->input->post('coupon_name');
	$coupon_percent = $this->input->post('coupon_percent');
	$coupon_expiry = $this->input->post('coupon_expiry');

	//Add to db
	$coupon_id = $this->user_model->add_coupon($product_id, $coupon_name, $coupon_percent, $coupon_expiry);

	echo $coupon_id;
}

public function edit_coupon() {

	$coupon_id = $this->input->post('coupon_id');
	$coupon_name = $this->input->post('coupon_name');
	$coupon_percent = $this->input->post('coupon_percent');
	$coupon_expiry = $this->input->post('coupon_expiry');

	//Edit it
	$product_title = $this->user_model->edit_coupon($coupon_id, $coupon_name, $coupon_percent, $coupon_expiry);

	echo $product_title;

}


public function delete_coupon() {

	$coupon_id = $this->input->post('coupon_id');

	$this->user_model->delete_coupon($coupon_id);

}


public function delete_user() {

	$user_id = $this->input->post('user_id');

	$this->user_model->delete_user($user_id);

}



public function billing_cron() {


	//run cron every day, check if two weeks before 
	$dateInTwoWeeks = strtotime('+2 weeks');
	$date_two_weeks = date('m-d', $dateInTwoWeeks);

	$date_one_month = date('m', strtotime('+1 month'));
	$date_one_month = $date_one_month . '-01';

	//echo $date_two_weeks . ' ' . $date_one_month;

	$now = time();
	$day_now = date('d', $now);

	#test stuff
	//$date_two_weeks = '08-01';
	$day_now = '01';

	#send notify email if two weeks before the end of the month
	if ( $date_two_weeks == $date_one_month ) {

		#send out email if balance is more than 50 cents (stripe only accepts 50 cents or more)

		$all_billing = $this->user_model->get_all_billing();

		foreach( $all_billing as $row ) {

			$email = $row['email'];
			$current_balance = $row['current_balance'];
			$delinquent = $row['deliquent'];

			if ($current_balance >= '.5') {

				#notify via email
				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$email"); 

				$this->email->subject('Billing');


				$this->email->message("Hello,<br/><br/>

				  This is a reminder to pay off your balance. If you don't pay off your balance in two weeks, your account will be disabled.

				  <br/><br/>

				  Your account currently has a balance of $". $current_balance .".

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();


			}


		}


	}



	#if it is the first of the month, disable accounts if necessary
	if ( $day_now == '01') {

		$all_billing = $this->user_model->get_all_billing();

		foreach( $all_billing as $row ) {

			$email = $row['email'];
			$current_balance = $row['current_balance'];
			$delinquent = $row['deliquent'];


			if ($current_balance >= '.5') {

				#disable the account
				$this->user_model->disable_account($email);

				#notify via email
				#Send email with product download if status complete
				$this->load->library('email');

				$config['protocol'] = 'smtp';
				$config['smtp_host'] = EMAIL_SMTP_HOST;
				$config['smtp_user'] = EMAIL_ADDRESS;
				$config['smtp_pass'] = EMAIL_PASSWORD;
				$config['smtp_port'] = EMAIL_SMTP_PORT;
				$config['wordwrap'] = TRUE;
				$config['mailtype'] = 'html';

				$this->email->initialize($config);

				$this->email->from(EMAIL_ADDRESS, WEBSITE_TITLE);
				$this->email->to("$email"); 

				$this->email->subject('Billing');


				$this->email->message("Hello,<br/><br/>

				  This is a reminder to pay off your balance. Your account is currently disabled.

				  <br/><br/>

				  Your account currently has a balance of $". $current_balance .".

				  <br/><br/>

				  If you have any questions please email us at ".EMAIL_ADDRESS."

				  <br/><br/>

				  Regards,<br/><br/>

				  ".WEBSITE_TITLE." Team<br/>
				  ".base_url()."

				");

				$this->email->send();


			}



		}



	}





}



} #End controller User.php
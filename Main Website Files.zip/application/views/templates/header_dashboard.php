<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo WEBSITE_TITLE;?> Dashboard</title>

    <link rel="icon" type="image/png" href="<?php echo base_url("assets/images/Money_Bag_icon.png"); ?>" />

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="<?php echo base_url();?>assets/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo base_url();?>assets/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo base_url();?>assets/bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo base_url();?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Drop Zone -->
    <script src="<?php echo base_url();?>assets/js/dropzone.js"></script>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/dropzone.min.css"></link>

    <script>Dropzone.autoDiscover = false;
    Dropzone.options.myAwesomeDropzoneEdit = false;

    </script>

    <!-- Froala -->
    <link rel="stylesheet" href="<?php echo base_url("assets/js/froala_editor/css/froala_editor.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/js/froala_editor/css/froala_style.min.css"); ?>" />



    
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<script>
<?php if ( ACCOUNT_STATUS == 1 ) { ?>

    alert("Your account is disabled. It currently has a past due balance. Please navigate to Billing Central and pay it off.");


<?php } ?>


</script>
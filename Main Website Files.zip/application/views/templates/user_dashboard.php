        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Dashboard</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-money fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">$<?php echo $total_earnings; ?></div>
                                    <div>Total Earnings USD</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">$<?php echo $today_earnings; ?></div>
                                    <div>Earnings Today USD</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-shopping-cart fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $total_sales; ?></div>
                                    <div>Total Sales</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-support fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $today_sales; ?></div>
                                    <div>Sales Today</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-8">
                   
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Products
                            <span style="float:right;"><a href="<?php echo base_url() . 'u/' . $this->session->userdata('user_name'); ?>">Products Page</a></span>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped">

                                            <thead>
                                                <tr>
                                                    <th class="col-sm-5">Product Title</th>
                                                    <th class="col-sm-1">Price</th>
                                                    <th class="col-sm-2">Product Type</th>
                                                    <th class="col-sm-2">Edit</th>
                                                    <th class="col-sm-2">Delete</th>
                                                </tr>
                                            </thead>

                                            <tbody>

                                                <?php

                                                foreach($products AS $x) {

                                                    $product_id = $x['id'];
                                                    $product_title = $x['product_title'];
                                                    $product_price = $x['product_price'];
                                                    $product_type = $x['product_type']; 
                                                    //$product_currency = $x['product_currency']; 

                                                    $query = $user_model->db->query("SELECT * FROM public_page WHERE product_id='$product_id'");
                                                    $row = $query->row();
                                                    $product_url = $row->id;

                                                    ?>

                                                    <tr id="product_row_<?php echo $product_id; ?>">
                                                
                                                        <td><a target="_blank" href="<?php echo base_url() . $product_url; ?>"><?php echo $product_title; ?></a></td>
                                                        <td class="text-center">$<?php echo money_format('%i', $product_price); ?></td>
                                                        <td class="text-center"><?php echo $product_type; ?></td>
                                                        <td id="product_<?php echo $product_id; ?>" class="text-center">
                                                            <button class="btn btn-primary edit_product">Edit</button>
                                                        </td>
                                                        <td id="delete_<?php echo $product_id; ?>" class="text-center">
                                                            <button class="btn btn-danger delete_product_confirm">Delete</button>
                                                        </td>
                                                
                                                    </tr>

                                             <?php } ?>


                                                


                                                

                    
                                            </tbody>


                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
                                </div>
                                <!-- /.col-lg-4 (nested) -->
                            
                                


                                <!-- /.col-lg-8 (nested) -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>

                </div>
                <!-- /.col-lg-8 -->
                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bell fa-fw"></i> Recent Payments
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group">

                            <?php if (isset($notifications)) { ?>

                                <?php foreach ($notifications as $x) { ?>

                                    <div id="recent_payments_<?php echo $x['id']; ?>">
                                        <a href="#" class="list-group-item recent_payments">
                                            <i class="fa fa-money fa-fw"></i> $<?php echo money_format('%i', $x['payment_amount']); ?> Received
                                            <span class="pull-right text-muted small"><em><abbr class="timeago" title="<?php echo $x['time']; ?>"></abbr></em>
                                            </span>
                                        </a>
                                    </div>
                                    
                                <?php } ?>

                            <?php } ?>

                            </div>
                            <!-- /.list-group -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
          
                   
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
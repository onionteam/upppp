    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url();?>assets/bower_components/raphael/raphael-min.js"></script>
    <script src="<?php echo base_url();?>assets/bower_components/morrisjs/morris.min.js"></script>

    <!-- Froala Editor-->
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/froala_unmini.js"); ?>"></script>
    <script>$.fn.froala_editor = $.fn.editable.noConflict();</script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/plugins/urls.min.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/plugins/video.min.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/plugins/lists.min.js"); ?>"></script>

    <script src="<?php echo base_url();?>assets/js/jquery.timeago.js"></script>


    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/js/sb-admin-2.js"></script>


  

<div id="file_name_uploaded"></div>
<script>


//Add Coupon
$(".add_coupon").on( "click", function(e) {

  e.preventDefault();

  //Get the vars
  var product_id = $('#add_coupon_product_title').val();
  var coupon_name = $('#add_coupon_name').val();
  var coupon_percent = $('#add_coupon_percent').val();
  var coupon_expiry = $('#add_coupon_expiry').val();


  if ($.trim(product_id) == "" || $.trim(coupon_name) == "" || $.trim(coupon_percent) == "" || $.trim(coupon_expiry) == "") {

    alert("You are missing fields!");

  }
  else {


    //product title
    var product_title = $('#add_coupon_product_title :selected').text();

    //The form data
    var formData = new FormData();
    formData.append('product_id', product_id);
    formData.append('coupon_name', coupon_name);
    formData.append('coupon_percent', coupon_percent);
    formData.append('coupon_expiry', coupon_expiry);


        $.ajax({
              type: "POST",
              url: "<?php echo base_url();?>user/add_coupon",
              cache: false,
              contentType: false,
              processData: false,
              data: formData,
              success: function(data){

                //data = coupon id

                $('#table_body_coupons').append('<tr id="coupon_row_'+ data +'"><td>'+ product_title +'</td><td class="text-center"><input type="text" class="form-control" id="coupon_name_'+ data +'" value="'+ coupon_name +'"></td><td class="text-center"><input type="text" class="form-control" id="coupon_percent_'+ data +'" value="'+ coupon_percent +'"></td><td class="text-center"><input type="text" class="form-control" id="coupon_expiry_'+ data +'" value="'+ coupon_expiry +'"></td><td id="coupon_id_'+ data +'" class="text-center"><button class="btn btn-primary edit_coupon">Edit</button></td><td id="delete_coupon_'+ data +'" class="text-center"><button class="btn btn-danger delete_coupon_confirm">Delete</button></td></tr>');

                //Edit coupon
                $('.edit_coupon').on( "click", function(e) {


                  var id = $(this).parent().attr('id');

                  var coupon_id = id.replace("coupon_id_", "");

                  var coupon_name = $('#coupon_name_'+coupon_id).val();
                  var coupon_percent = $('#coupon_percent_'+coupon_id).val();
                  var coupon_expiry = $('#coupon_expiry_'+coupon_id).val();

                  //The form data
                  var formData = new FormData();
                  formData.append('coupon_id', coupon_id);
                  formData.append('coupon_name', coupon_name);
                  formData.append('coupon_percent', coupon_percent);
                  formData.append('coupon_expiry', coupon_expiry);

                    $.ajax({
                            type: "POST",
                            url: "<?php echo base_url();?>user/edit_coupon",
                            cache: false,
                            contentType: false,
                            processData: false,
                            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
                            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
                            data: formData,
                            //beforeSend: function(){$('#loading').show();},
                            success: function(data){

                              //data = product_title
                              //$('#coupon_row_'+coupon_id).html('<td>'+ data +'</td><td class="text-center"><input type="text" class="form-control" id="coupon_name_'+ coupon_id +'" value="'+ coupon_name +'"></td><td class="text-center"><input type="text" class="form-control" id="coupon_percent_'+ coupon_id +'" value="'+ coupon_percent +'"></td><td class="text-center"><input type="text" class="form-control" id="coupon_expiry_'+ coupon_id +'" value="'+ coupon_expiry +'"></td><td id="coupon_id_'+ coupon_id +'" class="text-center"><button class="btn btn-primary edit_coupon">Edit</button></td><td id="delete_coupon_'+ coupon_id +'" class="text-center"><button class="btn btn-danger delete_coupon_confirm">Delete</button></td>');

                            }

                        });

                  


                });
                //End edit coupon

                //Delete coupon
                $('.delete_coupon_confirm').on( "click", function(e) {


                  var id = $(this).parent().attr('id');

                  var coupon_id = id.replace("delete_coupon_", "");

                  if (window.confirm("Are you sure you want to delete this coupon?")) {

                    $.ajax({
                            type: "POST",
                            url: "<?php echo base_url();?>user/delete_coupon",
                            cache: false,
                            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
                            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
                            data: '&coupon_id='+coupon_id,
                            //beforeSend: function(){$('#loading').show();},
                            success: function(data){

                              $('#coupon_row_'+coupon_id).remove();

                            }

                        });

                  }


                });
                //End delete coupon




              }

          });

  }//end if

});

//Delete coupon
$('.delete_coupon_confirm').on( "click", function(e) {


  var id = $(this).parent().attr('id');

  var coupon_id = id.replace("delete_coupon_", "");

  if (window.confirm("Are you sure you want to delete this coupon?")) {

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/delete_coupon",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&coupon_id='+coupon_id,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              $('#coupon_row_'+coupon_id).remove();

            }

        });

  }


});


//Edit coupon
$('.edit_coupon').on( "click", function(e) {


  var id = $(this).parent().attr('id');

  var coupon_id = id.replace("coupon_id_", "");

  var coupon_name = $('#coupon_name_'+coupon_id).val();
  var coupon_percent = $('#coupon_percent_'+coupon_id).val();
  var coupon_expiry = $('#coupon_expiry_'+coupon_id).val();

  //The form data
  var formData = new FormData();
  formData.append('coupon_id', coupon_id);
  formData.append('coupon_name', coupon_name);
  formData.append('coupon_percent', coupon_percent);
  formData.append('coupon_expiry', coupon_expiry);

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/edit_coupon",
            cache: false,
            contentType: false,
            processData: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: formData,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              //data = product_title
              //$('#coupon_row_'+coupon_id).html('<td>'+ data +'</td><td class="text-center"><input type="text" class="form-control" id="coupon_name_'+ coupon_id +'" value="'+ coupon_name +'"></td><td class="text-center"><input type="text" class="form-control" id="coupon_percent_'+ coupon_id +'" value="'+ coupon_percent +'"></td><td class="text-center"><input type="text" class="form-control" id="coupon_expiry_'+ coupon_id +'" value="'+ coupon_expiry +'"></td><td id="coupon_id_'+ coupon_id +'" class="text-center"><button class="btn btn-primary edit_coupon">Edit</button></td><td id="delete_coupon_'+ coupon_id +'" class="text-center"><button class="btn btn-danger delete_coupon_confirm">Delete</button></td>');

            }

        });

  


});
///////////////////////////////





//DROP ZONE UPLOAD
Dropzone.options.myAwesomeDropzone = {
  //acceptedFiles: 'zip, application/x-zip, application/zip, application/x-zip-compressed, application/s-compressed, multipart/x-zip, application/x-compress, application/x-compressed',
  addRemoveLinks: true,
  maxFilesize: <?php echo MAX_UPLOAD_SIZE;?>,
  success: function(file, response){

      response = JSON.parse(response);

      if ( response.error == 'false') {

        $('#file_name_uploaded').text(response.file_name);

      }
      else {

        alert($(response.error).text());

        this.removeFile(this.files[0]);

         

      }
                

  },
  accept: function(file, done) {
    console.log("uploaded");
    done();
  },
  init: function() {
    this.on("addedfile", function() {
      if (this.files[1]!=null){
        this.removeFile(this.files[0]);
      }
    });
    this.on("complete", function (data) {
      if (this.getUploadingFiles().length === 0 && this.getQueuedFiles().length === 0) {



      }
    });
  },
  removedfile: function(file) {

    //remove the file from server


    var _ref;
    return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
  },
};


Dropzone.discover();





///////////////////////////////////////////////
//
//      Delete User - user management area
//
///////////////////////////////////////////////
$('.delete_user').on( "click", function(e) {

  e.preventDefault();

  var id = $(this).parent().attr('id');

  var user_id = id.replace("user_id_", "");

  if ("<?php echo $this->session->userdata('user_id'); ?>" == user_id) {

    alert("You can't remove the admin account!");

  }
  else {

    if (window.confirm("Are you sure you want to delete this user?")) {

      $.ajax({
              type: "POST",
              url: "<?php echo base_url();?>user/delete_user",
              cache: false,
              //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
              //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
              data: '&user_id='+user_id,
              //beforeSend: function(){$('#loading').show();},
              success: function(data){

                $('#user_row_'+user_id).remove();

              }

          });

    }

  }


});
//End delete user





///////////////////////////////////////////////
//
//           Recent Payments js modal
//
///////////////////////////////////////////////
$('.recent_payments').on( "click", function(e) {

  e.preventDefault();

  var id = $(this).parent().attr('id');

  var order_id = id.replace("recent_payments_", ""); 

  var formData = new FormData();

  formData.append('id', order_id);


      $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/recent_payments_modal",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function(data){

              $('#recent_payments_div').html(data);

              $('#recent_payments_modal').modal('show');




            }

        });



});

///////////////////////////////////////////////
//
//          User management modal
//
///////////////////////////////////////////////
$('.user_management').on( "click", function(e) {

  e.preventDefault();

  var id = $(this).parent().attr('id');

  var user_id = id.replace("user_id_", ""); 

  var formData = new FormData();

  formData.append('user_id', user_id);


      $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/user_management_modal",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function(data){

              $('#user_management_div').html(data);

              $('#user_management_modal').modal('show');




            }

        });



});



$( "#product_type" ).change(function() {

  var selected = $( "#product_type option:selected" ).text();

  if (selected == "Code/Serial") {

    $('#type_area').html('<div class="form-group"><label for="serials">Serials</label><textarea class="form-control" rows="5" id="serials" placeholder="Serials separated by commas"></textarea></div>');


  }
  if (selected == "Download") {

    $('#type_area').html('<div class="form-group"><label for="file">Upload Product (.zip)</label><form action="<?php echo base_url(); ?>user/do_upload" class="dropzone" id="my-awesome-dropzone"></form></div>');

    Dropzone.discover();

  }

  if (selected == "Direct URL") {

    $('#type_area').html('<div class="form-group"><label for="direct_url">Direct URL</label><textarea class="form-control" rows="2" id="direct_url" placeholder="URL you want the buyer to be directed to after payment."></textarea></div>');


  }


});





$('#submit_product').on( "click", function(e) {



  e.preventDefault();

  

    
    $(this).prop("disabled",true);

    var currencies = JSON.stringify({
    "PayPal": $( "#PayPal:checked" ).map(function() {

                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }


                }).get(),
    "BTC":$( "#Bitcoin:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return "0";
                    }
                }).get(),
    "LTC": $( "#LiteCoin:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }
                }).get(),
    "DOGE": $( "#Dogecoin:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }
                }).get(),
    "STRIPE": $( "#Stripe:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }
                }).get()

   });

 

    var description = $('.froala-view').html();
    if (description == "<p><br></p>") {
      description = '';

    }
    var type = $( "#product_type option:selected" ).text();
    var title = $('#product_title').val();
    var price = $('#product_price').val();

    var direct_url = $('#direct_url').val();

    var serials = $('#serials').val();

    var file_name = $('.dz-filename').text();

    var file_name_upload = $('#file_name_uploaded').text();

    //var fileSelect = document.getElementById('file');

    //

    //if ($('#file').length != 0) {

      //if (fileSelect.files.length != 0) {

        //var file = fileSelect.files[0];

        // Check the file type.
        //if (file.type.match('application/x-zip-compressed')) {

          //formData.append('file', file);
          
        //}

      //}

    //}

    var formData = new FormData();

    formData.append('title', title);

    formData.append('price', price);

    formData.append('currencies', currencies);

    formData.append('description', description);

    formData.append('type', type);

    formData.append('serials', serials);

    formData.append('direct_url', direct_url);

    formData.append('file_name', file_name);

    formData.append('file_name_upload', file_name_upload);

    //add form data for file_name and file_name_upload
  
    

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/add_product",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: formData,
            contentType: false,
            processData: false,
            beforeSend: function(){$('#loading').show();},
            success: function(result){

              if (result != 'true') {

                $('#form_errors').html(result);

                $('#loading').hide();

                $('#submit_product').prop('disabled', false);

                

              }
              else {

                $('#form_errors').html("Product Added!");
                $('#loading').hide();

                setTimeout(function () {
                  $('#form_errors').html("");
                }, 3000);

                

                $( "#product_type option:selected" ).text();
                $('#product_title').val('');
                $('#product_price').val('');
                $('.froala-view').html('');
                $('#submit_product').prop('disabled', false);

                $('#PayPal').attr('checked', false); // Unchecks it
                $('#Bitcoin').attr('checked', false); // Unchecks it
                $('#LiteCoin').attr('checked', false); // Unchecks it
                $('#Dogecoin').attr('checked', false); // Unchecks it
                $('#Stripe').attr('checked', false); // Unchecks it


              }

        
              //location.reload();
            }
                                
      });



});

//window.reset = function (e) {
    //e.wrap('<form>').closest('form').get(0).reset();
    //e.unwrap();
//}


$(function() {

    $('#add_product_description').froala_editor({
      inlineMode: false,

      imageUploadURL: '<?php echo base_url();?>user/upload_image_post',

      imageDeleteURL: '<?php echo base_url();?>user/delete_image_post',

      buttons: ['bold', 'sep', 'italic', 'sep', 'underline', 'sep', 'align', 'sep','formatBlock','sep','insertHorizontalRule', 'sep','insertOrderedList', 'sep', 'insertUnorderedList', 'sep', 'insertImage'],

      blockTags: {
        n: 'Normal',
        h4: 'Heading'

      },

      imageUploadParams: {
        id: 'my_editor'
      }


    })
    // Catch image remove
      .on('editable.afterRemoveImage', function (e, editor, $img) {
        // Set the image source to the image delete params.
        editor.options.imageDeleteParams = {src: $img.attr('src')};

        // Make the delete request.
        editor.deleteImage($img);
      });

});

function get_desc_div() {

  var insidediv = $('.froala-view').html();
  var body = document.getElementById("product_description");
  body.value = insidediv;

}




//////////////////////////////////////////////////////////////
//
//                      EDIT PRODUCT
//
//////////////////////////////////////////////////////////////




$('.edit_product').on( "click", function(e) {


  var id = $(this).parent().attr('id');

  var product_id = id.replace("product_", "");


    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/get_edit_product",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&product_id='+product_id,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              $('#edit_product_div').html(data);

              $('#edit_product_modal').modal('show');


            }

        });


});


//////////////////////////////////////////////////////////////
//
//                    DELETE PRODUCT
//
//////////////////////////////////////////////////////////////




$('.delete_product_confirm').on( "click", function(e) {


  var id = $(this).parent().attr('id');

  var product_id = id.replace("delete_", "");

  if (window.confirm("Are you sure you want to delete this product?")) {

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/delete_product",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&product_id='+product_id,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              $('#product_row_'+product_id).remove();

            }

        });

  }


});





//////////////////////////////////////////////////////////////
//
//                  Payment Settings
//
//////////////////////////////////////////////////////////////

$('#submit_payment_settings').on( "click", function(e) {


  var paypal = $('#PayPal_pay').val();

  var bitcoin = $('#Bitcoin_pay').val();

  var litecoin = $('#LiteCoin_pay').val();

  var dogecoin = $('#Dogecoin_pay').val();

  var stripe_pub = $('#Stripe_pub').val();

  var stripe_sec = $('#Stripe_sec').val();


    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/payment_settings",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&paypal='+paypal+'&bitcoin='+bitcoin+'&litecoin='+litecoin+'&dogecoin='+dogecoin+'&stripe_pub='+stripe_pub+'&stripe_sec='+stripe_sec,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              $('#submit_payment_settings').html("Updated!");


            }

        });


});


//////////////////////////////////////////////////////////////
//
//                  Change Password
//
//////////////////////////////////////////////////////////////

$('#submit_change_password').on( "click", function(e) {


  var pass = $('#new_pass').val();

  var confirm = $('#new_pass_confirm').val();

  if (pass != confirm) {

    alert("Passwords should match.");

  }


    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/change_password",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&pass='+pass+'&confirm='+confirm,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              if (data != "false") {

                $('#submit_change_password').html("Updated!");

              }


            }

        });


});



jQuery("abbr.timeago").timeago();


//$(document).ready(function() {
    if("<?php echo $timezone; ?>".length==0){
        var visitortime = new Date();
        var visitortimezone = "GMT " + -visitortime.getTimezoneOffset()/60;
        $.ajax({
            type: "GET",
            url: "<?php echo base_url();?>login/set_timezone",
            data: 'time='+ visitortimezone,
            success: function(){
                location.reload();
            }
        });
    }
//});






</script>












</body>


</html>
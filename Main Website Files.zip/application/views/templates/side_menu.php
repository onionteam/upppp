

<?php 

$admin = false;

if (strcasecmp($this->session->userdata('user_name'), "admin") == 0) {

    $admin = true;

}?>

<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            
            <li>
                <a href="<?php echo base_url() . 'login'; ?>#" class="menu_clicked"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
            </li>

            <li>
                <a href="" data-toggle="modal" data-target="#add_product_modal" class="menu_clicked"><i class="fa fa-gear fa-fw"></i> Add Product</a>
            </li>

            <li>
                <a href="" data-toggle="modal" data-target="#coupons_modal" class="menu_clicked"><i class="fa fa-book fa-fw"></i> Coupons</a>
            </li>

            <li>
                <a href="" data-toggle="modal" data-target="#payment_settings_modal" class="menu_clicked"><i class="fa fa-key fa-fw"></i> Payment Settings</a>
            </li>

            <li class="menu_clicked"><a href="<?php echo base_url();?>billing"><i class="fa fa-credit-card fa-fw"></i> Billing Central</a></li>

            <li><a href="" data-toggle="modal" data-target="#change_password_modal" class="menu_clicked"><i class="fa fa-user fa-fw"></i> Change Password</a>
            </li>
            
        <?php if ($admin == true) { ?>

                <li class="menu_clicked"><a href="<?php echo base_url();?>admin"><i class="fa fa-fighter-jet fa-fw"></i> Admin Panel</a></li>
                
        <?php } ?>
            
            <li><a href="<?php echo base_url();?>do_logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
            </li>
                    
                        
                        
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->


<script>
//Left side menu selected or not.

</script>
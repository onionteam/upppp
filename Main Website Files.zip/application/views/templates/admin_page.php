<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">



<?php

if (strcasecmp($this->session->userdata('user_name'), "admin") == 0) { 


    #Check payment options
      $currency_array = explode(",", PAYMENT_OPTIONS);

      $checked_paypal = $checked_btc = $checked_ltc = $checked_doge = $checked_stripe = "";

      if ( in_array("PayPal", $currency_array) ) {

        $checked_paypal = "checked";
        
      }
      
      if ( in_array("BTC", $currency_array) ) {

        $checked_btc = "checked";

      }
      
      if ( in_array("LTC", $currency_array) ) {

        $checked_ltc = "checked";

      }
      
      if ( in_array("DOGE", $currency_array) ) {

        $checked_doge = "checked";

      }

      if ( in_array("STRIPE", $currency_array) ) {

        $checked_stripe = "checked";

      }



?>

<!-- jQuery -->
<script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

<!-- jScroll js -->
<script src="<?php echo base_url("assets/js/jscroll-master/jquery.jscroll.js"); ?>"></script>

<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Admin Panel</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bullseye fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $total_users;?></div>
                                    <div>Total Users</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-money fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">$<?php echo $total_earnings_by_all;?></div>
                                    <div>Total Earnings by All</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-shopping-cart fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $total_sales_by_all; ?></div>
                                    <div>Total Sales by All</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-rocket fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $today_sales_by_all;?></div>
                                    <div>Sales Today by All</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-6">
                   
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Website Settings
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">

                                <form action="" method="post" id="website_settings_form">
                                    
                                    <div class="form-group">
                                        <label for="email">Website Title</label>
                                        <input type="text" class="form-control" name="website_title" placeholder="website title" value="<?php echo $website_settings->website_title; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Website Logo URL</label>
                                        <input type="text" class="form-control" name="website_logo_url" placeholder="website logo url" value="<?php echo $website_settings->website_logo_url; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Gateway Fee %</label>
                                        <input type="text" class="form-control" name="gateway_fee" placeholder="gateway percentage fee for each sale" value="<?php echo $website_settings->gateway_fee; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Max Upload Size (mb)</label>
                                        <input type="text" class="form-control" name="max_upload_size" placeholder="max upload size in MB" value="<?php echo $website_settings->max_upload_size; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email SMTP Host</label>
                                        <input type="text" class="form-control" name="email_smtp_host" placeholder="example:  ssl://ns506728.ip-198-99-149.net" value="<?php echo $website_settings->email_smtp_host; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email Address</label>
                                        <input type="text" class="form-control" name="email_address" placeholder="email address to send email from this app" value="<?php echo $website_settings->email_address; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email Password</label>
                                        <input type="password" class="form-control" name="email_password" placeholder="the password to the above email account" value="<?php echo $website_settings->email_password; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Email SMTP Port</label>
                                        <input type="text" class="form-control" name="email_smtp_port" placeholder="the smtp port, usually 465 for ssl" value="<?php echo $website_settings->email_smtp_port; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Payment Options Enabled</label><br/>
                                            <label class="checkbox-inline"><input type="checkbox" name="PayPal" value="1" <?php echo $checked_paypal; ?>>PayPal</label>
                                            <label class="checkbox-inline"><input type="checkbox" name="Bitcoin" value="1" <?php echo $checked_btc; ?>>Bitcoin</label>
                                            <label class="checkbox-inline"><input type="checkbox" name="LiteCoin" value="1" <?php echo $checked_ltc; ?>>Litecoin</label>
                                            <label class="checkbox-inline"><input type="checkbox" name="Dogecoin" value="1" <?php echo $checked_doge; ?>>Dogecoin</label>
                                            <label class="checkbox-inline"><input type="checkbox" name="Stripe" value="1" <?php echo $checked_stripe; ?>>Stripe</label>
                                    </div>

                                    <div class="form-group">
                                        <label for="email">CoinPayments Private Key</label>
                                        <input type="text" class="form-control" name="cp_private_key" placeholder="coinpayments private key" value="<?php echo $website_settings->cp_private_key; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">CoinPayments Public Key</label>
                                        <input type="text" class="form-control" name="cp_public_key" placeholder="coinpayments public key" value="<?php echo $website_settings->cp_public_key; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">CoinPayments Merchant ID</label>
                                        <input type="text" class="form-control" name="cp_merchant_id" placeholder="coinpayments merchant id" value="<?php echo $website_settings->cp_merchant_id; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">CoinPayments IPN Secret</label>
                                        <input type="text" class="form-control" name="cp_ipn_secret" placeholder="coinpayments ipn secret" value="<?php echo $website_settings->cp_ipn_secret; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Stripe Secret Key</label>
                                        <input type="text" class="form-control" name="stripe_secret_key" placeholder="stripe secret key" value="<?php echo $website_settings->stripe_secret_key; ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="email">Stripe Public Key</label>
                                        <input type="text" class="form-control" name="stripe_published_key" placeholder="stripe published key" value="<?php echo $website_settings->stripe_published_key; ?>">
                                    </div>

                                    <div class="pull-right">
                                        <button type="submit" class="btn btn-success submit_website_settings">Submit <i class="fa fa-angle-right ml5"></i></button>
                                    </div>

                                </form>

                                <div class="pull-right">
                                    <button type="submit" class="btn btn-success test_email" style="margin-right: 20px;">Send Test Email</button>
                                </div>


                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>

                </div>
                <!-- /.col-lg-6 -->
             

                <div class="col-lg-6">
                   
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> User Management
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">

                                        <div class="row" style="margin-bottom: 15px;">
                                            <div class="col-md-4 text-center"><b>Username</b></div>
                                            <div class="col-md-4 text-center"><b>Email</b></div>
                                            <div class="col-md-2 text-center"><b>More Info</b></div>
                                            <div class="col-md-2 text-center"><b>Delete</b></div>
                                        </div>
                                        

                                        <div class="feed">

                                          <?php

                                                if ( count($all_users) > 0 ) {

                                                    $feed_count = 1;

                                                    foreach($all_users AS $x) {

                                                        $user_id = $x['id'];
                                                        $username = $x['username'];
                                                        $email = $x['email'];

                                                        //$query = $user_model->db->query("SELECT * FROM public_page WHERE product_id='$product_id'");
                                                        //$row = $query->row();
                                                        //$product_url = $row->id;

                                                        ?>

                                                        <div class="row" style="margin-top:5px;margin-bottom:5px;" id="user_row_<?php echo $user_id; ?>">
                                                    
                                                            <div class="col-md-4 text-center"><?php echo $username; ?></div>
                                                            <div class="col-md-4 text-center"><?php echo $email; ?></div>
                                                            <div class="col-md-2 text-center"id="user_id_<?php echo $user_id; ?>" class="text-center">
                                                                <button class="btn btn-info btn-sm user_management">More Info</button>
                                                            </div>
                                                            <div class="col-md-2 text-center"id="user_id_<?php echo $user_id; ?>" class="text-center">
                                                                <button class="btn btn-danger btn-sm delete_user">Delete</button>
                                                            </div>


                                                           
                                                        </div>

                                                        <?php if ($feed_count % 10 == 0) {  ?>

                                                            
                                                                <div class="col-md-12" style="margin-top:20px;">
                                                                <a href="<?php echo base_url() . 'user/user_feed/10';?>" class="btn btn-primary btn-block user_next" rel="nofollow">Load More Users</a>
                                                                
                                                                </div>
                                                           

                                                      <?php } ?>

                                                    <?php $feed_count++; ?>

                                              <?php } ?>


                                          <?php } ?>    



                                        </div>

                                    </div>
                                    

                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- lg-6-->





                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->


<div id="user_management_div"></div>

<script>

/////////////////////////////////////////////////////////////////
//                     Send Test email
/////////////////////////////////////////////////////////////////
$('.test_email').on( "click", function(e) {


    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/send_test_email",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            //data: '&product_id='+product_id,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

                $('.test_email').html("Sent!");


            }

        });


});
/////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////
//          jScroll Feed Loader for Load More Users
/////////////////////////////////////////////////////////////////

$(".feed").jscroll({

  loadingHtml: '<p class="text-center">Loading...</p>',
  //autoTriggerUntil: 4,
  autoTrigger: false,
  //nextSelector: 'a.user_next:last'
  //contentSelector: '.content',
  //debug: true

});
/////////////////////////////////////////////////////////////////


$( "form#website_settings_form" ).submit(function() {

    var formElement = document.getElementById("website_settings_form");
  
    var formData = new FormData(formElement);

    $.ajax({
      type: "POST",
      url: "<?php echo base_url();?>user/submit_website_settings",
      cache: false,
      data: formData,
      processData: false,
      contentType: false,
      success: function(data){

            if (data == '') {

                
                $('.submit_website_settings').html("Updated!");
                

            }
            else {

                //$('.bg-danger').html(data);


            }

       }
                
   });

    return false;

    



});




</script>


<?php }
    else { ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">You can't access this area.</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>

        </div>

 <?php   }   ?>
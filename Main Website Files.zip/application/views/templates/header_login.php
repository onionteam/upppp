<!DOCTYPE html>
<html lang="en">
  <head profile="http://www.w3.org/2005/10/profile">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $title; ?></title>

	<link rel="icon" type="image/png" href="<?php echo base_url("assets/images/Money_Bag_icon.png"); ?>" />

	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>" />

    <script type="text/javascript" src="<?php echo base_url("assets/js/jquery-2.1.3.min.js"); ?>"></script>

    <script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>

    <link rel="stylesheet" href="<?php echo base_url("assets/css/font-awesome-4.3.0/css/font-awesome.min.css"); ?>" />

    <link rel="stylesheet" href="<?php echo base_url("assets/css/default.css"); ?>" />

    <!-- Froala Editor-->
    <link rel="stylesheet" href="<?php echo base_url("assets/js/froala_editor/css/froala_editor.css"); ?>" />
    <link rel="stylesheet" href="<?php echo base_url("assets/js/froala_editor/css/froala_style.min.css"); ?>" />
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/froala_unmini.js"); ?>"></script>
    <script>$.fn.froala_editor = $.fn.editable.noConflict();</script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/plugins/urls.min.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/plugins/video.min.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/froala_editor/js/plugins/lists.min.js"); ?>"></script>

	

	<link rel="stylesheet" href="<?php echo base_url("assets/css/welcome.css"); ?>">

	<!--Favicon -->
	<link rel="icon" type="image/jpg" href="" />
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head>
<body>
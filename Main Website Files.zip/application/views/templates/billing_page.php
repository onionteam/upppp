<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- jQuery -->
<script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>

<!-- jScroll js -->
<script src="<?php echo base_url("assets/js/jscroll-master/jquery.jscroll.js"); ?>"></script>



<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Billing Central</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-money fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div style="font-size: 25px;" class="current_balance">$<?php echo $current_balance; ?></div>
                                    <div>Current Balance</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                
                                    <div class="col-xs-3">
                                        <i class="fa fa-credit-card fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div style="font-size: 25px;">
                                            <button class="btn btn-lg btn-success" onclick="submit_stripe('<?php echo $this->session->userdata('user_email'); ?>', '<?php echo $current_balance; ?>')">
                                                Pay Now
                                            </button>
                                        </div>
                                        <div>Pay off your Balance</div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-<?php if ( ACCOUNT_STATUS == 0 ) { echo 'thumbs-up'; }else { echo 'thumbs-down'; } ?> fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div style="font-size: 25px;"><?php if ( ACCOUNT_STATUS == 0 ) { echo 'Good Standing'; }else { echo 'Delinquent'; } ?></div>
                                    <div>Account Status</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bullseye fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div style="font-size: 25px;">1st of the month</div>
                                    <div>Billing Cycle</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-5">
                   
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Products and Fees for <?php echo date('F'); ?>
                            <div style="float:right;">Gateway Fee: <?php echo GATEWAY_FEE; ?>%</div>
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">


                                <div class="row" style="margin-bottom: 15px;">
                                    <div class="col-md-6 text-center"><b>Product Title</b></div>
                                    <div class="col-md-2 text-center"><b>Price</b></div>
                                    <div class="col-md-4 text-center"><b>Gateway Fee</b></div>
                                </div>

                                
                                <?php if ($current_monthly_orders_billing != 0 || !empty($current_monthly_orders_billing) ) {

                                    //print_r($current_monthly_orders_billing);

                                        foreach($current_monthly_orders_billing AS $x) {

                                            $product_title = $x['product_title'];
                                            $product_price = $x['product_price'];
                                            $gateway_fee = $x['gateway_fee'];

                                            //$query = $user_model->db->query("SELECT * FROM public_page WHERE product_id='$product_id'");
                                            //$row = $query->row();
                                            //$product_url = $row->id;

                                            ?>

                                            <div class="row" style="margin-top:5px;margin-bottom:5px;">
                                        
                                                <div class="col-md-6 text-center"><?php echo $product_title; ?></div>
                                                <div class="col-md-2 text-center">$<?php echo money_format('%i', $product_price); ?></div>
                                                <div class="col-md-4 text-center">$<?php echo money_format('%i', $gateway_fee); ?></div>
                                                

                                               
                                            </div>


                                  <?php } ?>


                              <?php } ?>    





                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>

                </div>
                <!-- /.col-lg-6 -->


                <div class="col-lg-4">
                   
                    <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Billing History
                            
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">

                                <div class="row" style="margin-bottom: 15px;">
                                    <div class="col-md-8 text-center"><b>Amount Paid</b></div>
                                    <div class="col-md-4 text-center"><b>Date</b></div>
                                </div>


                                <?php if ($billing_history != 0 || !empty($billing_history) ) {

                                    //print_r($current_monthly_orders_billing);

                                    

                                        foreach($billing_history AS $x) {

                                            $amount_paid = $x['amount'];
                                            $time = $x['time'];

                                            $date = new DateTime($time);
                                            $date = $date->format('Y-m-d');

                                            ?>

                                            <div class="row" style="margin-top:5px;margin-bottom:5px;">
                                        
                                                <div class="col-md-8 text-center">$<?php echo $amount_paid / 100; ?></div>
                                                <div class="col-md-4 text-center"><?php echo $date; ?></div>
                                               
                                            </div>


                                  <?php } ?>


                              <?php } ?>  





                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>

                </div>
                <!-- /.col-lg-6 -->
             






                <!-- /.col-lg-4 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->



<script src="https://checkout.stripe.com/checkout.js"></script>

<script>

function submit_stripe(email, amount) {


    var handler = StripeCheckout.configure({
    key: '<?php echo STRIPE_PUBLISHED_KEY; ?>',
    token: function(token) {

        var email = token.email;
        var stripeToken = token.id;

        var data = {'email': email, 'stripeToken': stripeToken, 'amount': amount * 100};

        $.post('<?php echo base_url(); ?>user/stripe_billpay', data, function(data) {

            data = $.parseJSON(data);

            if (data.err == "true") {

                alert(data.message);

            }
            else {

                alert("Success! Thank you for your payment!");

                $(".current_balance").text("$0.00");


            }


        });




    }
  });

    // Open Checkout with further options
    handler.open({
      name: '<?php echo WEBSITE_TITLE; ?>',
      description: 'Bill Pay',
      amount: amount * 100,
      email: email
      //closed: function(){ $('.checkout').attr("disabled", false); }
    });


    



}//End stripe submit function


</script>
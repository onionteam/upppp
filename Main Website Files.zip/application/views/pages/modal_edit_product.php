

<script>Dropzone.autoDiscover = false;

Dropzone.options.myAwesomeDropzoneEdit = false;</script>

<?php

foreach ($product as $x) {

  $product_id = $x['id'];
  $title = $x['product_title'];
  $price = money_format('%i', $x['product_price']);
  $description = $x['product_description'];
  $type = $x['product_type'];
  $serials = $x['product_serials'];
  $currency = $x['product_currency'];
  $direct_url = $x['product_directurl'];

  $current_file = $x['product_upload_name'];

  if (empty($current_file)) {

    $current_file = "None";

  }
  else {



  }

  #Check currency
  $currency_array = explode(",", $currency);

  $checked_paypal = $checked_btc = $checked_ltc = $checked_doge = $checked_stripe = "";

  if ( in_array("PayPal", $currency_array) ) {

    $checked_paypal = "checked";
    
  }
  
  if ( in_array("BTC", $currency_array) ) {

    $checked_btc = "checked";

  }
  
  if ( in_array("LTC", $currency_array) ) {

    $checked_ltc = "checked";

  }
  
  if ( in_array("DOGE", $currency_array) ) {

    $checked_doge = "checked";

  }

  if ( in_array("STRIPE", $currency_array) ) {

    $checked_stripe = "checked";

  }

  //echo $type;

  #check serial
  if ( $type == "Download" ) {

    $selected_download = "selected";
    $selected_serial = "";
    $selected_directurl = "";

  }
  elseif ($type == "Direct URL") {

    $selected_download = "";
    $selected_serial = "";
    $selected_directurl = "selected";

  }
  else {

    $selected_download = "";
    $selected_serial = "selected";
    $selected_directurl = "";

  }

  

}

?>


<!-- Edit Product Modal -->
<div class="<?php echo $product_id; ?>">

<div class="modal fade" id="edit_product_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Product</h4>
      </div>
      <div class="modal-body">


          <p id="edit_form_errors" class="bg-danger"></p>

          <p id="edit_form_success" class="bg-success"></p>


          <div class="input-group" style="margin-bottom: 20px;">
            <span class="input-group-addon" id="">Title</span>
            <input type="text" class="form-control" id="edit_product_title" name="product_title" placeholder="Product Title" value="<?php echo $title; ?>"></input>
          </div>


          <div class="input-group">
            <span class="input-group-addon" id="money_sign">$</span>
            <input style=""class="form-control" id="edit_product_price" name="product_price" placeholder="Product Price" aria-describedby="money_sign" value="<?php echo $price; ?>"></input>
          </div>

          <div style="margin-top: 20px; margin-bottom: 20px;">
            Currencies: <br/>

            <?php 

            $payment_options = PAYMENT_OPTIONS;

            #Payment options from admin
            if ( !empty($payment_options) ) {

              $payment_options_array = explode(',', PAYMENT_OPTIONS);

              foreach ($payment_options_array as $option) {

                if ($option == "PayPal") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="PayPal" value="PayPal" <?php echo $checked_paypal; ?>>PayPal</label>

          <?php }

                if ($option == "BTC") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="Bitcoin" value="BTC" <?php echo $checked_btc; ?>>Bitcoin</label>

          <?php }

                if ($option == "LTC") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="LiteCoin" value="LTC" <?php echo $checked_ltc; ?>>Litecoin</label>


          <?php }

                if ($option == "DOGE") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="Dogecoin" value="DOGE" <?php echo $checked_doge; ?>>Dogecoin</label>


          <?php }


                if ($option == "STRIPE") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="Stripe" value="STRIPE" <?php echo $checked_stripe; ?>>Stripe</label>


          <?php }



              } #End foreach


            }


          ?>
            
            
          </div>

          <div style="margin-top: 10px; margin-bottom: 10px;">

            <div class="panel panel-default">
              <div class="panel-heading">Product Description</div>
              <div class="panel-body">

                <div id="edit_product_description" class="text-small"><?php echo $description; ?></div>
                <input type="hidden" id="product_description" name="product_description" />


              </div>
            </div>
          </div>



          <div class="form-group">
            <label for="product_type">Product Type</label>
            <select class="form-control" id="edit_product_type" name="product_type">
              <option <?php echo $selected_download; ?> value="Download">Download</option>
              <option <?php echo $selected_serial; ?> value="Code/Serial">Code/Serial</option>
              <option <?php echo $selected_directurl; ?> value="Direct URL">Direct URL</option>
            </select>
          </div>

          <?php if ( $type == "Download" ) { ?>

              <div id="type_area">
                <div class="form-group">
                  <label for="file">Upload Product (.zip, last file will be destroyed)</label>
                  <div class="dropzone" id="dropzone_edit">
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>" />
                  </div>
                  <p style="padding-top: 10px;">Current file:  <?php echo $current_file; ?></p>
                </div>
              </div>

              <script>
                //DROP ZONE UPLOAD
                var myDropzone_edit = new Dropzone("div#dropzone_edit", {
                  url: '<?php echo base_url(); ?>user/do_upload',
                  //acceptedFiles: 'zip, application/x-zip, application/zip, application/x-zip-compressed, application/s-compressed, multipart/x-zip, application/x-compress, application/x-compressed',
                  addRemoveLinks: true,
                  maxFilesize: <?php echo MAX_UPLOAD_SIZE;?>,
                  success: function(file, response){

                      response = JSON.parse(response);

                      if ( response.error == 'false') {

                        $('#file_name_uploaded').text(response.file_name);

                      }
                      else {

                        alert($(response.error).text());

                        this.removeFile(this.files[0]);

                         

                      }
                                

                  },
                  accept: function(file, done) {
                    console.log("uploaded");
                    done();
                  },
                  init: function() {
                    this.on("addedfile", function() {
                      if (this.files[1]!=null){
                        this.removeFile(this.files[0]);
                      }
                    });
                    this.on("complete", function (data) {
                      if (this.getUploadingFiles().length === 0 && this.getQueuedFiles().length === 0) {



                      }
                    });
                  },
                  removedfile: function(file) {

                    //remove the file from server


                    var _ref;
                    return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
                  },
                });

                </script>

          <?php }
            elseif ( $type == "Direct URL" ) { ?>

                <div id="type_area">
                  <div class="form-group">
                    <label for="direct_url">Direct URL</label>
                    <textarea class="form-control" rows="2" id="direct_url" placeholder="URL you want the buyer to be directed to after payment."><?php echo $direct_url; ?></textarea>
                  </div>
                </div>


          
          <?php } 
              else {?>

                  <div id="type_area">
                    <div class="form-group">
                      <label for="serials">Serials</label>
                      <textarea class="form-control" rows="5" id="edit_serials" placeholder="Serials separated by commas"><?php echo $serials; ?></textarea>
                    </div>
                 </div>

            <?php } ?>

        
      </div>
      <div class="modal-footer">

      <img src="<?php echo base_url();?>assets/images/LoadingBasketContents.gif" id="edit_loading" style="display:none;float:left;" width="50" height="50"/>

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" id="edit_product" class="btn btn-primary">Edit Product</button>
      </div>


    </div>
  </div>
</div>

</div>

<script>




// FROALA EDIT
$(function() {

    $('#edit_product_description').froala_editor({
      inlineMode: false,

      imageUploadURL: '<?php echo base_url();?>user/upload_image_post',

      imageDeleteURL: '<?php echo base_url();?>user/delete_image_post',

      buttons: ['bold', 'sep', 'italic', 'sep', 'underline', 'sep', 'align', 'sep','formatBlock','sep','insertHorizontalRule', 'sep','insertOrderedList', 'sep', 'insertUnorderedList', 'sep', 'insertImage'],

      blockTags: {
        n: 'Normal',
        h4: 'Heading'

      },

      imageUploadParams: {
        id: 'my_editor'
      }


    })
    // Catch image remove
      .on('editable.afterRemoveImage', function (e, editor, $img) {
        // Set the image source to the image delete params.
        editor.options.imageDeleteParams = {src: $img.attr('src')};

        // Make the delete request.
        editor.deleteImage($img);
      });

});


// ON PRODUCT TYPE CHANGE
$( "#edit_product_type" ).change(function() {

  var selected = $( "#edit_product_type option:selected" ).text();

  if (selected == "Code/Serial") {

    $('#type_area').html('<div class="form-group"><label for="serials">Serials</label><textarea class="form-control" rows="5" id="edit_serials" placeholder="Serials separated by commas"><?php echo addslashes($serials); ?></textarea></div>');

    $("#edit_product_type").find('option').removeAttr("selected");

    $("#edit_product_type").val("Code/Serial");

    

  }
  if (selected == "Download") {

    $('#type_area').html('<div class="form-group"><label for="file">Upload Product (.zip)</label><div class="dropzone" id="dropzone_select"></div></div>');


    var myDropzone = new Dropzone("div#dropzone_select", {
      url: '<?php echo base_url(); ?>user/do_upload',
      //acceptedFiles: 'zip, application/x-zip, application/zip, application/x-zip-compressed, application/s-compressed, multipart/x-zip, application/x-compress, application/x-compressed',
      addRemoveLinks: true,
      maxFilesize: <?php echo MAX_UPLOAD_SIZE;?>,
      success: function(file, response){

          response = JSON.parse(response);

          if ( response.error == 'false') {

            $('#file_name_uploaded').text(response.file_name);

          }
          else {

            alert($(response.error).text());

            this.removeFile(this.files[0]);

             

          }
                    

      },
      accept: function(file, done) {
        console.log("uploaded");
        done();
      },
      init: function() {
        this.on("addedfile", function() {
          if (this.files[1]!=null){
            this.removeFile(this.files[0]);
          }
        });
        this.on("complete", function (data) {
          if (this.getUploadingFiles().length === 0 && this.getQueuedFiles().length === 0) {



          }
        });
      },
      removedfile: function(file) {

        //remove the file from server


        var _ref;
        return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
      },
    });






    $("#edit_product_type").find('option').removeAttr("selected");

    $("#edit_product_type").val("Download");



  }

  if (selected == "Direct URL") {

    $('#type_area').html('<div class="form-group"><label for="direct_url">Direct URL</label><textarea class="form-control" rows="2" id="direct_url" placeholder="URL you want the buyer to be directed to after payment."></textarea></div>');

    $("#edit_product_type").find('option').removeAttr("selected");

    $("#edit_product_type").val("Direct URL");



  }

});


//Edit 
$('#edit_product').on( "click", function(e) {



  e.preventDefault();

  

    
    $(this).prop("disabled",true);

    var currencies = JSON.stringify({
    "PayPal": $( "#PayPal:checked" ).map(function() {

                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }


                }).get(),
    "BTC":$( "#Bitcoin:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return "0";
                    }
                }).get(),
    "LTC": $( "#LiteCoin:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }
                }).get(),
    "DOGE": $( "#Dogecoin:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }
                }).get(),
    "STRIPE": $( "#Stripe:checked" ).map(function() {
                    var value = $(this).val();

                    if (value != '') {

                      return 1;

                    }
                    else {
                      return 0;
                    }
                }).get()

   });

 

    var description = $('.froala-view').html();
    if (description == "<p><br></p>") {
      description = '';

    }
    var type = $( "#edit_product_type option:selected" ).text();
    var title = $('#edit_product_title').val();
    var price = $('#edit_product_price').val();

    var serials = $('#edit_serials').val();

    var direct_url = $('#direct_url').val();

    var file_name = $('.dz-filename').text();

    var file_name_upload = $('#file_name_uploaded').text();

    //var fileSelect = document.getElementById('file');

    var formData = new FormData();

    //if ($('#file').length != 0) {

      //if (fileSelect.files.length != 0) {

        //var file = fileSelect.files[0];

        // Check the file type.
        //if (file.type.match('application/x-zip-compressed')) {

          //formData.append('file', file);
          
        //}

      //}

    //}

    var product_id = $('#edit_product_modal').parent().attr('class');


    formData.append('title', title);

    formData.append('price', price);

    formData.append('currencies', currencies);

    formData.append('description', description);

    formData.append('type', type);

    formData.append('serials', serials);

    formData.append('product_id', product_id);

    formData.append('direct_url', direct_url);

    formData.append('file_name', file_name);

    formData.append('file_name_upload', file_name_upload);
  
    

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/edit_product",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: formData,
            contentType: false,
            processData: false,
            beforeSend: function(){$('#edit_loading').show();},
            success: function(result){

              if (result != 'true') {

                $('#edit_form_errors').html(result);

                $('#edit_loading').hide();

                $('#edit_product').prop('disabled', false);

                

              }
              else {

                $('#edit_form_success').html("Product Edited!");
                $('#edit_loading').hide();

                setTimeout(function () {
                  $('#edit_form_success').html("");
                }, 3000);
                
                $('#edit_product').prop('disabled', false);

              }

        
              //location.reload();
            }
                                
      });



});

$('#edit_product_modal').on('hidden.bs.modal', function () {
   
   $('#edit_product_div').html("");

   //Dropzone.autoDiscover = false;

   //Dropzone.options.myAwesomeDropzoneEdit.disable();


});


</script>
<?php

$page_last = $page_number + 10;

    if ( count($all_users) > 0 ) {

		$feed_count = 1;

		foreach($all_users as $x) {


			$user_id = $x['id'];
            $username = $x['username'];
            $email = $x['email'];

            //$query = $user_model->db->query("SELECT * FROM public_page WHERE product_id='$product_id'");
            //$row = $query->row();
            //$product_url = $row->id;

            ?>

            <div class="row" style="margin-top:5px;margin-bottom:5px;" id="user_row_<?php echo $user_id; ?>">
                                                    
	            <div class="col-md-4 text-center"><?php echo $username; ?></div>
	            <div class="col-md-4 text-center"><?php echo $email; ?></div>
	            <div class="col-md-2 text-center"id="user_id_<?php echo $user_id; ?>" class="text-center">
	                <button class="btn btn-info btn-sm user_management_<?php echo $page_last;?>">More Info</button>
	            </div>
              <div class="col-md-2 text-center"id="user_id_<?php echo $user_id; ?>" class="text-center">
                  <button class="btn btn-danger btn-sm delete_user_<?php echo $page_last;?>">Delete</button>
              </div>

	        </div>

            <?php if ($feed_count % 10 == 0) {  ?>

                <div class="col-md-12" style="margin-top:20px;">
                    <a href="/user/user_feed/<?php echo $page_last; ?>" class="btn btn-primary btn-block user_next" rel="nofollow">Load More Users</a>
                    
                </div>

          <?php } ?>

        <?php $feed_count++; 


		} #End foreach

	}#End if count

?>

<script>
///////////////////////////////////////////////
//
//          User management modal
//
///////////////////////////////////////////////
$('.user_management_<?php echo $page_last;?>').on( "click", function(e) {

  e.preventDefault();

  var id = $(this).parent().attr('id');

  var user_id = id.replace("user_id_", ""); 

  var formData = new FormData();

  formData.append('user_id', user_id);


      $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/user_management_modal",
            cache: false,
            contentType: false,
            processData: false,
            data: formData,
            success: function(data){

              $('#user_management_div').html(data);

              $('#user_management_modal').modal('show');




            }

        });



});



///////////////////////////////////////////////
//
//       Delete User user management area
//
///////////////////////////////////////////////
$('.delete_user_<?php echo $page_last;?>').on( "click", function(e) {

  e.preventDefault();

  var id = $(this).parent().attr('id');

  var user_id = id.replace("user_id_", "");

  if (window.confirm("Are you sure you want to delete this user?")) {

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/delete_user",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&user_id='+user_id,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              $('#user_row_'+user_id).remove();

            }

        });

  }


});
//End delete user

</script>


<div class="container">

	<!--Success-->
	<div class="step-2">

	<div class="col-md-8 col-md-offset-2">

	<div class="panel panel-default">
	<div class="panel-heading" style="background-color: #91a7c0;">
	<h4 class="panel-title text-center">
	<a style="color: white; font-weight: bold;">
	Success!
	</a>
	</h4>
	</div>
	<div class="panel-body">
	<p class="text-center">You should receive your email shortly!</p>

	</div>
	</div>

	</div>
	</div>
	</div>
	<!--End Success-->


	
</div><!--end container-->
<section class="hbox stretch">
	<section id="content">
		<div style=' margin: 70px auto 0 50px;'>

		<?php if ($all_products != false) { ?>

		<h1><?php echo $username;?>'s products</h1>
			<div class="row">

			

				<?php foreach ($all_products as $row) { 

					$product_id = $row['id'];
					$title = $row['product_title'];
					$price = $row['product_price'];

					$query = "SELECT * FROM public_page WHERE product_id=?";
   					$query = $user_model->db->query($query, array($product_id));

   					$public_link = $query->row()->id;

				?>
					<div class="col-lg-3 col-md-3 col-sm-3">
						<a href="<?php echo base_url() . $public_link; ?>">
						<section class="panel">
						<header class="panel-heading bg-white">
						<div class="text-center h5"><i class="fa fa-3x fa-cloud-download text-success"></i></div>
						</header>
						<div class="panel-body pull-in text-center">
						<strong><?php echo $title;?></strong>
						<br/> $ <?php echo money_format('%i', $price); ?> USD
						</div>
						</section>
						</a>
					</div>


			<?php  }  ?>

	

			</div>

	<?php  }
			else {

				echo "This page does not exist!";


			}  ?>

		</div>
	</section>
</section>

<?php

foreach ($recent_order as $x) {

  if (isset($x['paypal_email'])) { ?>

<!--PayPal Order-->
  <div class="modal fade" id="recent_payments_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Order Details</h4>
      </div>
      <div class="modal-body">

        PayPal Email: <?php echo $x['paypal_email'];?> <br/><br/>

        Txn ID: <?php echo $x['txn_id'];?> <br/><br/>
          

        
      </div>
      <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>


    </div>
  </div>
</div>


<?php } 
  elseif(isset($x['amount_crypto'])) {?>


  <!--Crypto Order-->
<div class="modal fade" id="recent_payments_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Order Details</h4>
      </div>
      <div class="modal-body">

          Currency: <?php echo $x['currency'];?> <br/><br/>

          Net Received: <?php echo money_format('%i', $x['net']); ?> <br/><br/>

          TXN ID: <?php echo $x['txn_id'];?> <br/><br/>

        
      </div>
      <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>


    </div>
  </div>
</div>



<?php
  }
  else { ?>


  <!--Stripe Order-->
<div class="modal fade" id="recent_payments_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Order Details</h4>
      </div>
      <div class="modal-body">

      <?php 

        $product_amount = $x['amount'] / 100;

      ?>

          Currency: USD <br/><br/>

          Net Received: $<?php echo money_format('%i', $product_amount); ?> <br/><br/>

          Buyer Email: <?php echo $x['email'];?> <br/><br/>

        
      </div>
      <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>


    </div>
  </div>
</div>

  
<?php } 
  

}?>
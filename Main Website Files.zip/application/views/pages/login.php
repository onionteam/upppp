<style>
body {
  background: #e9e9e9 url('<?php echo base_url();?>assets/images/texture_background.png');
}
</style>

<section>
<div class="panel panel-signin">
<div class="panel-body">
<div class="logo text-center">
<img src="<?php echo WEBSITE_LOGO_URL; ?>">
</div>
<br/>
<h4 class="text-center mb5">Already a Member?</h4>
<p class="text-center">Sign in to your account</p>
<p class="text-center">Demo <br/>Email: tom <br/>Password: cool</p>
<div class="mb30"></div>
<div class="bg-danger"></div>
<div class="bg-success" style="margin-bottom: 10px;"></div>
<form action="" method="post" id="form">
<div class="input-group mb15">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input type="text" class="form-control" name="email" placeholder="Email Address" required>
</div> 
<div class="input-group mb15">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input type="password" class="form-control" name="pass" placeholder="Password" required>
</div> 

<div class="clearfix">
<div class="pull-right">
<button type="submit" name="login" class="btn btn-success">Sign In <i class="fa fa-angle-right ml5"></i></button>
</div>
</div>
</form>
</div> 
<div class="panel-footer">
<a href="signup" class="btn btn-primary btn-block">Not yet a Member? Create Account Now</a>
</div> 
</div> 
</section>



<script>
$( "form" ).submit(function() {

	var formElement = document.getElementById("form");
  
	var formData = new FormData(formElement);

	$.ajax({
      type: "POST",
      url: "<?php echo base_url();?>do_login",
      cache: false,
      data: formData,
      processData: false,
	  contentType: false,
      success: function(data){

	      	if (data == 'true') {

	      		$('.bg-danger').html("");

	      		$('.bg-success').html("Logging you in...");

	      		setTimeout(function(){

  					window.location.replace("<?php echo base_url() . 'login'; ?>");

				}, 2000);

				

			}
			else {

				$('.bg-danger').html(data);


			}

       }
                
   });

	return false;

	



});


</script>


<?php

  foreach($user_info as $row) {

    $username = $row['username'];
    $user_email = $row['email'];


  }



?>


<!--PayPal Order-->
  <div class="modal fade" id="user_management_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Details about <?php echo $username; ?></h4>
      </div>
      <div class="modal-body">

      <?php if (!empty($user_products)) { ?>

      <table class="table table-bordered table-hover table-striped">

          <thead>
              <tr>
                  <th class="col-sm-4 text-center">Title</th>
                  <th class="col-sm-1 text-center">Price</th>
                  <th class="col-sm-2 text-center">Type</th>
                  <th class="col-sm-1 text-center">Upload Name</th>
                  <th class="col-sm-2 text-center">Currency</th>
                  <th class="col-sm-2 text-center">Delete</th>
              </tr>
          </thead>

          <tbody>
          
            <?php foreach($user_products as $row) { 

                $product_id = $row['id'];

                $product_title = $row['product_title'];
                $product_price = $row['product_price'];
                $product_type = $row['product_type'];
                $product_upload_name = $row['product_upload'];
                $product_currency = $row['product_currency'];

                $query = $user_model->db->query("SELECT * FROM public_page WHERE product_id='$product_id'");
                $row = $query->row();
                $product_url = $row->id;

              ?>


          <tr id="product_row_<?php echo $product_id; ?>">
                                                
              <td><a target="_blank" href="<?php echo base_url() . $product_url; ?>"><?php echo $product_title; ?></a></td>
              <td class="text-center">$<?php echo money_format('%i', $product_price); ?></td>
              <td class="text-center"><?php echo $product_type ?></td>
              <td class="text-center"><?php echo $product_upload_name ?></td>
              <td class="text-center"><?php echo $product_currency ?></td>
              
              <td id="delete_<?php echo $product_id; ?>" class="text-center">
                  <button class="btn btn-danger delete_product_confirm">Delete</button>
              </td>
      
          </tr>





    <?php } ?>


<?php }
    else {

      echo "This user doesn't have any products!";


      } ?>

        
      </div>


    </div>
  </div>
</div>


<script>
//////////////////////////////////////////////////////////////
//
//                    DELETE PRODUCT
//
//////////////////////////////////////////////////////////////


$('.delete_product_confirm').on( "click", function(e) {


  var id = $(this).parent().attr('id');

  var product_id = id.replace("delete_", "");

  if (window.confirm("Are you sure you want to delete this product?")) {

    $.ajax({
            type: "POST",
            url: "<?php echo base_url();?>user/delete_product",
            cache: false,
            //data: 'title='+title+'&price='+price+'&PayPal='+PayPal+'&Bitcoin='+Bitcoin+'&LiteCoin='+LiteCoin+'&OmniCoin='+OmniCoin+'&description='+description+'&type='+type,
            //data: 'title='+title+'&price='+price+'&currencies='+currencies+'&description='+description+'&type='+type+'&serials='+serials+'&file='+formData,
            data: '&product_id='+product_id,
            //beforeSend: function(){$('#loading').show();},
            success: function(data){

              $('#product_row_'+product_id).remove();

            }

        });

  }


});
</script>
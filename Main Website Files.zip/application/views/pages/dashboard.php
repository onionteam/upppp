<?php

if ($payment_settings != FALSE) {

    foreach ($payment_settings as $ea) {

        $paypal_address = $ea['PayPal'];

        $btc_address = $ea['BTC'];

        $ltc_address = $ea['LTC'];

        $doge_address = $ea['DOGE'];

        $stripe_published_key = $ea['stripe_published_key'];

        $stripe_secret_key = $ea['stripe_secret_key'];


    }

}
else {

        $paypal_address = '';

        $btc_address = '';

        $ltc_address = '';

        $doge_address = '';

        $stripe_published_key = '';

        $stripe_secret_key = '';


}
?>


    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url() . 'login'; ?>"><?php echo WEBSITE_TITLE; ?> Payment System</a>
            </div>
            <!-- /.navbar-header -->

            
            <?php echo $left_side_nav; ?>

            
        </nav>

        <?php if (isset($admin_page)) {

            echo $admin_page;

        }
        elseif (isset($user_dashboard)) {

            echo $user_dashboard;

        }
        elseif (isset($billing_page)) {

            echo $billing_page;

        }

        ?>







    <div id="edit_product_div"></div>

    <div id="recent_payments_div"></div>

<!-- Add Product Modal -->
<div class="modal fade" id="add_product_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Product</h4>
      </div>
      <div class="modal-body">


          <p id="form_errors" class="error"></p>


          <div class="input-group" style="margin-bottom: 20px;">
            <span class="input-group-addon" id="">Title</span>
            <input type="text" class="form-control" id="product_title" name="product_title" placeholder="Product Title"></input>
          </div>


          <div class="input-group">
            <span class="input-group-addon" id="money_sign">$</span>
            <input style=""class="form-control" id="product_price" name="product_price" placeholder="Product Price" aria-describedby="money_sign"></input>
          </div>

          <div style="margin-top: 20px; margin-bottom: 20px;">
            Currencies: <br/>

            <?php 

            $payment_options = PAYMENT_OPTIONS;

            #Payment options from admin
            if ( !empty($payment_options) ) {

              $payment_options_array = explode(',', PAYMENT_OPTIONS);

              foreach ($payment_options_array as $option) {

                if ($option == "PayPal") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="PayPal" value="PayPal">PayPal</label>

          <?php }

                if ($option == "BTC") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="Bitcoin" value="BTC">Bitcoin</label>

          <?php }

                if ($option == "LTC") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="LiteCoin" value="LTC">Litecoin</label>


          <?php }

                if ($option == "DOGE") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="Dogecoin" value="DOGE">Dogecoin</label>


          <?php }


                if ($option == "STRIPE") { ?>

                  <label class="checkbox-inline"><input type="checkbox" id="Stripe" value="STRIPE">Stripe</label>


          <?php }



              } #End foreach


            }


          ?>



          </div>

          <div style="margin-top: 10px; margin-bottom: 10px;">

            <div class="panel panel-default">
              <div class="panel-heading">Product Description</div>
              <div class="panel-body">

                <div id="add_product_description" class="text-small"></div>
                <input type="hidden" id="product_description" name="product_description" />


              </div>
            </div>
          </div>



          <div class="form-group">
            <label for="product_type">Product Type</label>
            <select class="form-control" id="product_type" name="product_type">
              <option>Download</option>
              <option>Code/Serial</option>
              <option>Direct URL</option>
            </select>
          </div>



          <div id="type_area">
            <div class="form-group">

              <label for="file">Upload Product (.zip)</label>

                <form action="<?php echo base_url(); ?>user/do_upload" class="dropzone" id="my-awesome-dropzone"></form>


            </div>
          </div>


          

          
          

        
      </div>
      <div class="modal-footer">

      <img src="<?php echo base_url(); ?>assets/images/LoadingBasketContents.gif" id="loading" style="display:none;float:left;" width="50" height="50"/>

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" id="submit_product" class="btn btn-primary">Add Product</button>
      </div>


    </div>
  </div>
</div>


<!-- Add Payment Settings Modal -->
<div class="modal fade" id="payment_settings_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Payment Settings</h4>
      </div>
      <div class="modal-body">


          <p id="form_errors" class="error"></p>

          <?php 

            $payment_options = PAYMENT_OPTIONS;

            #Payment options from admin
            if ( !empty($payment_options) ) {

              $payment_options_array = explode(',', PAYMENT_OPTIONS);

              foreach ($payment_options_array as $option) {

                if ($option == "PayPal") { ?>

                  <div class="input-group" style="margin-bottom: 20px;">
                    <span class="input-group-addon" id="">PayPal</span>
                    <input type="text" class="form-control" id="PayPal_pay" name="PayPal" placeholder="PayPal Email Address" value="<?php echo $paypal_address; ?>"></input>
                  </div>

          <?php }

                if ($option == "BTC") { ?>

                  <div class="input-group" style="margin-bottom: 20px;">
                    <span class="input-group-addon" id="">Bitcoin</span>
                    <input type="text" class="form-control" id="Bitcoin_pay" name="Bitcoin" placeholder="Bitcoin Address" value="<?php echo $btc_address; ?>"></input>
                  </div>

          <?php }

                if ($option == "LTC") { ?>

                  <div class="input-group" style="margin-bottom: 20px;">
                    <span class="input-group-addon" id="">LiteCoin</span>
                    <input type="text" class="form-control" id="LiteCoin_pay" name="LiteCoin" placeholder="Litecoin Address" value="<?php echo $ltc_address; ?>"></input>
                  </div>


          <?php }

                if ($option == "DOGE") { ?>

                  <div class="input-group" style="margin-bottom: 20px;">
                    <span class="input-group-addon" id="">Dogecoin</span>
                    <input type="text" class="form-control" id="Dogecoin_pay" name="Dogecoin" placeholder="Dogecoin Address" value="<?php echo $doge_address; ?>"></input>
                  </div>


          <?php }


                if ($option == "STRIPE") { ?>

                  <div class="input-group" style="margin-bottom: 20px;">
                    <span class="input-group-addon" id="">Stripe Published Key</span>
                    <input type="text" class="form-control" id="Stripe_pub" name="Stripe_pub" placeholder="Stripe Published Key" value="<?php echo $stripe_published_key; ?>"></input>
                  </div>

                  <div class="input-group" style="margin-bottom: 20px;">
                    <span class="input-group-addon" id="">Stripe Secret Key</span>
                    <input type="text" class="form-control" id="Stripe_sec" name="Stripe_sec" placeholder="Stripe Secret Key" value="<?php echo $stripe_secret_key; ?>"></input>
                  </div>


          <?php }



              } #End foreach


            }


          ?>


          

          

          

          

          


          
        
      </div>
      <div class="modal-footer">

      <img src="<?php echo base_url(); ?>assets/images/LoadingBasketContents.gif" id="loading" style="display:none;float:left;" width="50" height="50"/>

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" id="submit_payment_settings" class="btn btn-primary">Change Payment Settings</button>
      </div>


    </div>
  </div>
</div>


<!-- Change Password -->
<div class="modal fade" id="change_password_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Payment Settings</h4>
      </div>
      <div class="modal-body">


          <p id="form_errors" class="error"></p>


          <div style="margin-bottom: 20px;">

            <input type="password" class="form-control" id="new_pass" placeholder="New Password" ></input>
          </div>

          <div style="margin-bottom: 20px;">

            <input type="password" class="form-control" id="new_pass_confirm" placeholder="Confirm Password" ></input>
          </div>



          
        
      </div>
      <div class="modal-footer">

      <img src="<?php echo base_url(); ?>assets/images/LoadingBasketContents.gif" id="loading" style="display:none;float:left;" width="50" height="50"/>

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" id="submit_change_password" class="btn btn-primary">Change Password</button>
      </div>


    </div>
  </div>
</div>



<!-- Coupons -->
<div class="modal fade" id="coupons_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Coupons</h4>
      </div>
      <div class="modal-body">


          <p id="form_errors" class="error"></p>

          <div class="row">

            <div class="col-sm-4">
              <select class="form-control" id="add_coupon_product_title">

              <?php foreach($products as $row) { ?>

                <?php 

                  $product_id = $row['id'];
                  $product_title = $row['product_title'];


                ?>

                  <option value="<?php echo $product_id; ?>"><?php echo $product_title; ?></option>

             <?php } ?>

              </select>
            </div>

            <div class="col-sm-2">
              <input type="text" class="form-control" id="add_coupon_name" placeholder="Coupon Name">
            </div>

            <div class="col-sm-2">
              <input type="text" class="form-control" id="add_coupon_percent" placeholder="Percent Off">
            </div>

            <div class="col-sm-2">
              <input type="text" class="form-control" id="add_coupon_expiry" placeholder="Expiry Usage">
            </div>

            <div class="col-sm-2">
              <button class="btn btn-success add_coupon">Add</button>
            </div>


          </div>




          <div class="table-responsive" style="margin-top: 25px;">
            <table class="table table-bordered table-hover table-striped">

                <thead>
                    <tr>
                        <th class="col-sm-5">Product Title</th>
                        <th class="col-sm-3">Coupon Name</th>
                        <th class="col-sm-1">Percent Off</th>
                        <th class="col-sm-1">Expiry Usage</th>
                        <th class="col-sm-1">Edit</th>
                        <th class="col-sm-1">Delete</th>
                    </tr>
                </thead>

                <tbody id="table_body_coupons">

                    <?php

                    foreach($coupons AS $x) {

                        $id = $x['id'];
                        $product_id = $x['product_id'];
                        $coupon_name = $x['coupon_name'];
                        $percentage_off = $x['percentage_off'] * 100;
                        $expiry_usage = $x['expiry_usage']; 
                        //$product_currency = $x['product_currency']; 

                        $query = $user_model->db->query("SELECT * FROM products WHERE id='$product_id'");
                        $row = $query->row();
                        $product_title = $row->product_title;

                        ?>

                        <tr id="coupon_row_<?php echo $id; ?>">
                    
                            <td><?php echo $product_title; ?></td>
                            <td class="text-center"><input type="text" class="form-control" id="coupon_name_<?php echo $id; ?>" value="<?php echo $coupon_name; ?>"></td>
                            <td class="text-center"><input type="text" class="form-control" id="coupon_percent_<?php echo $id; ?>" value="<?php echo $percentage_off; ?>"></td>
                            <td class="text-center"><input type="text" class="form-control" id="coupon_expiry_<?php echo $id; ?>" value="<?php echo $expiry_usage; ?>"></td>


                            <td id="coupon_id_<?php echo $id; ?>" class="text-center">
                                <button class="btn btn-primary edit_coupon">Edit</button>
                            </td>
                            <td id="delete_coupon_<?php echo $id; ?>" class="text-center">
                                <button class="btn btn-danger delete_coupon_confirm">Delete</button>
                            </td>
                    
                        </tr>

                 <?php } ?>


                    


                    


                </tbody>


            </table>
        </div>


          
        
      </div>
      <div class="modal-footer">

      <img src="<?php echo base_url(); ?>assets/images/LoadingBasketContents.gif" id="loading" style="display:none;float:left;" width="50" height="50"/>

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         
      </div>


    </div>
  </div>
</div>
<?php 

if ($deleted == false) {  ?>



<style>
.img_container {
  width: 200px;
  height: 55px;
  overflow: hidden;
  position: relative;
  margin: 0;
  float: left;
  margin-right: 5px;
  
}
.img_container img {
  width:100%;
  float: left;
  cursor: pointer;

}

.stripe {
  display: block;
  position: relative;
  padding: 0 12px;
  height: 50px;
  line-height: 30px;
  background: #1275ff;
  background-image: -webkit-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -moz-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -ms-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -o-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -webkit-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -moz-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -ms-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: -o-linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  background-image: linear-gradient(#7dc5ee,#008cdd 85%,#30a2e4);
  font-size: 14px;
  color: #fff;
  font-weight: bold;
  font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
  text-shadow: 0 -1px 0 rgba(0,0,0,0.25);
  -webkit-box-shadow: inset 0 1px 0 rgba(255,255,255,0.25);
  -moz-box-shadow: inset 0 1px 0 rgba(255,255,255,0.25);
  -ms-box-shadow: inset 0 1px 0 rgba(255,255,255,0.25);
  -o-box-shadow: inset 0 1px 0 rgba(255,255,255,0.25);
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.25);
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  -ms-border-radius: 4px;
  -o-border-radius: 4px;
  border-radius: 4px;
}
</style>


<?php


foreach($product as $e) {

	$username = $e['username'];

    $product_email = $e['email'];

	$title = $e['product_title'];

	$price = $e['product_price'];

	$description = $e['product_description'];

	$currency = $e['product_currency'];

	$product_id = $e['id'];

	$currency = explode(',', $currency);

	$stripe_price = $price * 100;

	$type = $e['product_type'];

}

# Check if code/serial and quantity remaining
if ($type == "Code/Serial" && $quantity == 0) {

	$disabled = true;

}
else {

	$disabled = false;

}

#Check if account status is good
$query = "SELECT * FROM billing WHERE email=?";
$query = $user_model->db->query($query, array($product_email));

if ( $query->num_rows() > 0 ) {

    $row = $query->row();

    $account_status = $row->deliquent;

    if ($account_status == 0) {

        $account_disabled = false;


    }
    else {

        $account_disabled = true;

    }


}
else {

    $account_disabled = false;

}


?>


<div class="container">



<div class="step-1">

	<div class="col-md-8 col-md-offset-2">


			<div class="panel panel-default text-center" style="margin-top: 20px;">
		        <div class="panel-heading"><?php echo $title; ?></div>
		           	<div class="panel-body">

		                <?php echo $description; ?>


		        	</div>
		    </div>



	</div>


	<div class="col-md-8 col-md-offset-2">


			<section class="panel">
			
			
				<div class="row" style="margin: 20px 0px;">
				<div class="col-lg-12">

				<span class="thumb-small avatar pull-right" style="margin: 0 7px; width: 43px;">
				<img class="img-circle" src="<?php echo base_url();?>assets/images/avatar.png" style="width: 43px;">
				</span>
				<div class="pull-right text-right" style="font-size: 15px;">
				<b><?php echo $username; ?></b>
				<br>
				<span style="color:#AAAAAA;">Super Seller</span>
				</div>
				<b>Quantity Remaining</b>

					<?php if ($type == "Download") { ?>
							<div class="btn btn-default btn-sm quantity_remaining">∞</div></div>
					<?php }
						elseif($type == "Code/Serial") { ?>
							<div class="btn btn-default btn-sm quantity_remaining"><?php echo $quantity; ?></div></div>

					<?php } ?>

				</div>
			</section>



	</div>

	<div class="col-md-8 col-md-offset-2">

	<section class="panel table-responsive">
	<table class="table">
	<thead style="font-size: 15px;">
	<tr>
	<th style="padding: 15px 15px;">Description</th>
	<th class="text-center" style="padding: 15px 15px;">Quantity</th>
	<th class="text-center" style="padding: 15px 15px;">Price</th>
	<th class="text-center" style="padding: 15px 15px;">Total</th>
	</tr>
	</thead>
	<tbody>
	<tr>
	<td>
	<h5 class="semibold mt0 mb5"><?php echo $title; ?></h5>
	</td>
	<td class="valign-top text-center"><input min="1" max="100" style="width: 60px;" value="1" id="quantity" type="number"></td>
	<td class="valign-top text-center"><span class="bold">$<?php echo money_format('%i', $price); ?></span></td>
	<td class="valign-top text-center btn-success" rowspan="2" style="font-weight: bold; font-size: 25px; vertical-align: middle;"><span class="bold total">$<?php echo money_format('%i', $price); ?></span></td>
	</tr>
	<tr>
	<td>
	<h5 class="semibold mt0 mb5"><?php echo WEBSITE_TITLE; ?> Gateway</h5>
	<span class="text-muted">Instant delivery after payment!</span>
	</td>
	<td class="valign-top text-center"><span class="bold"></span></td>
	<td class="valign-top text-center"><span class="bold">$0.00</span></td>
	</tr>
	</tbody>
	</table>
	</section>


	</div>

	<div class="col-md-8 col-md-offset-2">

	<section class="panel">
	<div class="row" style="margin: 20px 0px;">
	<div class="col-lg-3" style="font-size: 15px; margin-top: 3px;">
	<b>Pay Now</b>
	<br>
	<span style="color:#AAAAAA;">Choose payment option</span>
	</div>
	<div class="col-lg-9">

    <?php if ($account_disabled != true) { ?>

	<?php if (!$disabled) { ?>


		<?php foreach ($currency AS $x) { 

			if($x == "STRIPE") { ?>

						<div class="img_container text-center" style="margin-top: 5px;">

							<button onclick='pay("<?php echo $x; ?>");' class="btn btn-primary btn-lg stripe" style="width: 100%">Pay with Card</button>
						
						</div>
					
			<?php }

			elseif ($x == "BTC") { ?>

				<div class="img_container">
					<a onclick='pay("<?php echo $x; ?>");'>
						<img src="<?php echo base_url();?>assets/images/btc.png" />
					</a>
				</div>

			<?php }
			elseif($x == "PayPal") { ?>

					<div class="img_container">
						<a onclick='pay("<?php echo $x; ?>");'>
							<img src="<?php echo base_url(); ?>assets/images/paypal.png" />
						</a> 
					</div>
			<?php }
			elseif($x == "LTC") { ?>

					<div class="img_container">
						<a onclick='pay("<?php echo $x; ?>");'>
							<img src="<?php echo base_url(); ?>assets/images/ltc.jpg" />
						</a> 
					</div>
			<?php } 
			elseif($x == "DOGE") { ?>

					<div class="img_container">
						<a onclick='pay("<?php echo $x; ?>");'>
							<img src="<?php echo base_url(); ?>assets/images/doge.png" />
						</a> 
					</div>
			<?php } ?>
			


			
			
		<?php } ?>

	<?php }
		else { 

		echo "<center style='color: red;'>This product has no quantity left.</center>";

	   } ?>


<?php }
    else {


        echo "<center style='color: red;'>This account is currently disabled.</center>";

        } ?>

	</div>
	</div>
	</section>

	</div>
	
</div>
<!--End step 1-->

<!--Step 2-->
<div class="step-2" style="display:none;">

<div class="col-md-8 col-md-offset-2">

<div class="panel panel-default">
<div class="panel-heading" style="background-color: #91a7c0;">
<h4 class="panel-title text-center">
<a style="color: white; font-weight: bold;">
Checkout
</a>
</h4>
</div>
<div class="panel-body">
<p>Your Email:</p>
<input type="text" id="email" class="form-control" required="">
<br>
<p>Coupon:</p>
<div class="input-group">
<input type="text" id="couponCode" class="form-control">
<span class="input-group-btn">
<button class="btn btn-default" onclick="redeemCoupon();" type="button">Apply</button>
</span>
</div>
<div class="form-goup">
<label>Applied coupon: </label><span id="coupon"> None</span>
</div>
<input type="hidden" value="" id="couponCodeResult" name="couponCode">
<br>
<input type="button" onclick="checkout()" class="btn btn-success checkout" value="Continue to Payment">
<img src="<?php echo base_url(); ?>assets/images/LoadingBasketContents.gif" id="loading" style="display:none;" width="50" height="50"/>
</div>
</div>

</div>
</div>
</div>
<!--End step 2-->


<!--Step 3-->
<div class="step-3" style="display:none;">
<div class="col-md-8 col-md-offset-2">
<div class="panel panel-default">
<div class="panel-heading" style="background-color: #91a7c0;">
<h4 class="panel-title text-center">
<a style="color: white; font-weight: bold;">
Payment
</a>
</h4>
</div>
<div class="panel-body"></div>
</div>
</div>
</div>

</div><!--end container-->




<script src="https://checkout.stripe.com/checkout.js"></script>

<script>

<?php 

if (isset($stripe_keys)) {

	foreach($stripe_keys AS $row) {

		$stripe_published_key = trim($row['stripe_published_key']);


	}


}

?>





function submit_stripe(email, amount) {

  	//var stripe_price = $('#quantity').val() * <?php echo $price; ?> * 100;
    var handler = StripeCheckout.configure({
    key: '<?php if (isset($stripe_published_key)) { echo $stripe_published_key; } ?>',
    token: function(token) {

        var email = token.email;
        var stripeToken = token.id;
        //var amount = $('#quantity').val() * <?php echo $price; ?> * 100;
        var product_id = <?php echo $product_id; ?>;

        var data = {'email': email, 'stripeToken': stripeToken, 'amount': amount * 100, 'product_id': product_id};

        $.post('<?php echo base_url(); ?>user/stripe_check', data, function(data) {

            data = $.parseJSON(data);

            if (data.err == "true") {

                alert(data.message);

            }
            else {

                $('.checkout').attr("disabled", true);

                alert("Success! Your item will arrive shortly!");
                window.location.replace("<?php echo base_url() . 'success'; ?>");

            }


        });




    }
  });

    // Open Checkout with further options
    handler.open({
      name: '<?php echo WEBSITE_TITLE; ?>',
      description: '<?php echo $title; ?>',
      amount: amount * 100,
      email: email,
      closed: function(){ $('.checkout').attr("disabled", false); }
    });


    



}//End stripe submit function

  // Close Checkout on page navigation
  $(window).on('popstate', function() {
    handler.close();
    
  });






    var apiEndpoint = '<?php echo base_url(); ?>x/<?php echo $page_slug; ?>';
    var currency = 0;




    $('#quantity').change(function() {

    	var quantity_remaining = $('.quantity_remaining').html();

    	if ($(this).val() > quantity_remaining) {

    		$(this).val(quantity_remaining);

    	}

        if ($(this).val() < 1) {
            $(this).val('1');
        }


        $('.total').html('$' + ((($(this).val() * <?php echo $price; ?>) * 100) / 100).toFixed(2));


    });

    function redeemCoupon()
    {

        var data = {'redeem_coupon': true, 'coupon_name': $('#couponCode').val(), 'product_id': <?php echo $product_id; ?>};

        $.post( "<?php echo base_url() . 'redeem_coupon'; ?>", data, function( data ) {

            data = $.parseJSON(data);

            switch (data.response){
                case "false":
                        alert('The coupon you entered is not valid.');
                    break;
                case "used":
                        alert('The maximum usage limit of this coupon has been reached.');
                    break;
                default:
                    $('#coupon').text(" "+$('#couponCode').val() + " " + data.response * 100 + "% off");
                    $('#couponCodeResult').val(data.response)
                    break;
            }
        });
    }

    function pay(type) {
        currency = type;
        $('.step-1').slideUp(1000, function() {
            setTimeout(function() { $('.step-2').slideDown(1000); }, 1000);
        });

        
    }


    function checkout() {

    	$('#loading').show();

    	//disable the button
    	$('.checkout').attr("disabled", true);

        //the percentage
        var coupon_result = $('#couponCodeResult').val();

        if ( coupon_result >= 1 || coupon_result == "1" ) {

            var data = {'redeem_coupon': true, 'coupon_name': $('#couponCode').val(), 'product_id': <?php echo $product_id; ?>, 'email': $('#email').val()};

            $.post("<?php echo base_url() . 'xt_pro'; ?>", data, function(data) {

                data = $.parseJSON(data);

                switch (data.response){
                    case "false":
                            alert('The coupon you entered is not valid.');
                        break;
                    case "used":
                            alert('The maximum usage limit of this coupon has been reached.');
                        break;
                    default:
                            alert("Success! Your item will arrive shortly!");
                            window.location.replace("<?php echo base_url() . 'success'; ?>");
                        break;
                }



                

            });

        }
        else {
                
            var data = {'action': 'purchase', 'price': <?php echo $price; ?>, 'currency': currency, 'email': $('#email').val(), 'quantity': $('#quantity').val(), 'couponCode': $('#couponCodeResult').val(), 'success_url': '', 'affiliate': ''};

            $.post(apiEndpoint, data, function(data) {

            	//alert(data);

                data = $.parseJSON(data);

                var actual_price = data.response.data.amount;

                actual_price = actual_price.toFixed(2);

                

                

                //alert(actual_price);

                if (data.error) {
                    location.reload();
                }
                 else {
                    switch (data.response.action) {
                        case 'pp-checkout':

                                $('body').append('<form action=\'https://www.paypal.com/cgi-bin/webscr\' method=\'post\' id=\'ppform\'>\
                                	<input type=\'hidden\' name=\'cmd\' id=\'paycmd\' value=\'' + (data.response.data.sub ? '_xclick-subscriptions' : '_xclick') + '\'>\
                                    <input type=\'hidden\' name=\'currency_code\' value=\'USD\'>\
                                    <input type=\'hidden\' name=\'business\' value=\'' + data.response.data.business + '\'>\
                                    <input type=\'hidden\' name=\'item_name\' value=\'' + data.response.data.itemname + '\'>\
                                    <input type=\'hidden\' name=\'item_number\' value=\'' + data.response.data.itemnumber + '\'>\
                                    <input type=\'hidden\' name=\'amount\' value=\'' + actual_price + '\'>\
                                    <input type=\'hidden\' name=\'custom\' value=\'' + data.response.data.custom + '\'>\
                                    <input type=\'hidden\' name=\'notify_url\' value=\'<?php echo base_url(); ?>ipn/paypal\'>\
                                    <input type=\'hidden\' name=\'return\' value=\'' + data.response.data.success_url +'\'>\
                                    <input type=\'hidden\' name=\'cancel_return\' value=\'\'>\
                                    <input type=\'hidden\' name=\'invoice\' value=\'\'>\
                                    <input type=\'hidden\' name=\'allow_amount\' value=\'0\'>\
                                    <input type=\'hidden\' name=\'want_shipping\' value=\'' + data.response.data.shipping + '\'>\
                                    <input type=\'hidden\' name=\'quantity\' value=\'' + data.response.data.quantity + '\'>\
                                    <input type=\'hidden\' name=\'no_shipping\' value=\'' + (data.response.data.shipping ? '0' : '1') + '\'>\
                                    ' + (data.response.data.sub ? '<input name=\'a3\' type=\'hidden\' value=\'' + data.response.data.amount + '\'><input name=\'t3\' type=\'hidden\' value=\'' + data.response.data.sublength + '\'><input name=\'p3\' type=\'hidden\' value=\'' + data.response.data.subunit + '\'><input name=\'src\' type=\'hidden\' value=\'1\'>' : '') + '\
                                </form>');

                                document.getElementById('ppform').submit();

                            break;
                        case 'display-crypto':
                            $('.step-2').slideUp(1000, function() {
                                setTimeout(function() { $('.step-3').slideDown(1000); }, 1000);
                            });

                            function update() {
                                var data2 = {'action': 'checktx', 'txid': data.response.data.txid};

                                $.post(apiEndpoint, data2, function(data) {
                                    data = $.parseJSON(data);

                                    if (data.response.received >= data.response.amount) {
                                        $('.step-3 .panel-body').html("<p>Transaction Complete. Please check your email for your product. It may take 2-15 minutes for your product to be delivered.</p><p style='text-align: center; font-size: 12px;'>Powered by <a href='https://coinpayments.net'>CoinPayments</a></p>");
                                    } else if (((data.response.expires - ((new Date).getTime() / 1000)) / 60) <= 0) {
                                        $('.step-3 .panel-body').html("<p>Transaction has expired.</p><p style='text-align: center; font-size: 12px;'>Powered by <a href='https://coinpayments.net'>CoinPayments</a></p>");
                                    } else {
                                        $('.step-3 .panel-body').html("<p>Please send <code>" + data.response.amount + " " + data.response.coin + "</code> to <code>" + data.response.address + "</code> in the next <b>" + Math.floor((data.response.expires - ((new Date).getTime() / 1000)) / 60) + "</b> minutes.</p><p><b>Transaction ID:</b> " + data.response.txid + "<br /><b>Product:</b> " + data.response.title + "<br /><b>Actual Price:</b> " + data.response.price + " USD<br /><b>Total Received:</b> " + data.response.received + " " + data.response.coin + "<br /><b>Total Left:</b> " + (data.response.amount - data.response.received) + " " + data.response.coin + "</p><p style='text-align: center; font-size: 30px;'><i class='fa fa-spinner fa-spin'></i> Awaiting Payment</p><p><i>After payment is sent, please wait 2-15 minutes for your product to be delivered through email. If you have any issues, please contact us with your transaction ID at <?php echo EMAIL_ADDRESS; ?></p><p style='text-align: center; font-size: 12px;'>Powered by <a href='https://coinpayments.net'>CoinPayments</a></p>");
                                    }
                                });
                            }

                            setInterval(update, 15000);

                            update();

                            break;

                        case 'stripe':
                            
                            //$('.step-3 .panel-body').html("<p><form id=\"stripe_form\" action=\"<?php echo base_url();?>user/stripe_check\" method=\"POST\"><script src=\"https://checkout.stripe.com/checkout.js\" class=\"stripe-button\" data-key=\"pk_test_N4XPdBReZvblir6bTB7qBdRi\" data-amount=\"2000\" data-name=\"Demo Site\" data-description=\"2 widgets ($20.00)\" data-image=\"/128x128.png\"/></form></p>");
                                    
                            //$( "#stripe_form" ).submit();

                            $('#loading').hide();

                            var email = $('#email').val();

                            submit_stripe(email, actual_price);

                        

                            break;
                    }
                }
            });

        }
    }
</script>



<?php }
	else {

		echo "<center>This page does not exist!</center>";

}
?>
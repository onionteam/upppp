<?php
 echo generate_indeed_feed();
?>
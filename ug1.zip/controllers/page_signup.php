<?php

	$template = 'auth/sign-up.tpl';
?>
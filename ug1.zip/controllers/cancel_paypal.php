<?php 
	redirect_to(BASE_URL . URL_DASHBOARD . '/' . URL_DASHBOARD_POST);	
	return;
?>

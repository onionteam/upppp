<?php
$b = protect($_GET['b']);
$id = protect($_GET['id']);
?>
<ol class="breadcrumb">
	<li><a href="./">WebAdmin</a></li>
	<li class="active">Web Settings</li>
</ol>

<div class="row">
	<div class="col-lg-12">
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						<i class="fa fa-cogs"></i> Web Settings 
				  </div>
                  <div class="panel-body">
					<?php
					if(isset($_POST['btn_save'])) {
						$title = protect($_POST['title']);
						$description = protect($_POST['description']);
						$keywords = protect($_POST['keywords']);
						$sitename = protect($_POST['sitename']);
						$url = protect($_POST['url']);
						$email = protect($_POST['email']);
						$phone = protect($_POST['phone']);
						$fb_prof = protect($_POST['fb_prof']);
						$tw_prof = protect($_POST['tw_prof']);
						$in_prof = protect($_POST['in_prof']);
						$changer_refid = protect($_POST['changer_refid']);
						if(empty($title) or empty($description) or empty($keywords) or empty($sitename) or empty($url) or empty($email) or empty($phone) or empty($fb_prof) or empty($tw_prof) or empty($in_prof) or empty($changer_refid)) { echo error("All fields are required."); }
						elseif(!isValidURL($url)) { echo error("Please enter valid site url address. Eg: http://pandachanger.com/"); }
						elseif(!isValidEmail($email)) { echo error("Please enter valid site email address. Eg: support@pandachanger.com"); }
						elseif(!isValidURL($fb_prof)) { echo error("Please enter valid Facebook profile link."); }
						elseif(!isValidURL($tw_prof)) { echo error("Please enter valid Twitter profile link."); }
						elseif(!isValidURL($in_prof)) { echo error("Please enter valid Linkedin profile link."); }
						elseif(!is_numeric($changer_refid)) { echo error("Please enter valid Changer Referral ID."); }
						else {
							$update = $db->query("UPDATE settings SET title='$title',description='$description',keywords='$keywords',sitename='$sitename',url='$url',email='$email',phone='$phone',fb_prof='$fb_prof',tw_prof='$tw_prof',in_prof='$in_prof',changer_refid='$changer_refid'");
							echo success("Your changes was saved successfully.");
							$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
							$settings = $settingsQuery->fetch_assoc();
						}
					}
					?>
					<form action="" method="POST">
						<div class="form-group">
							<label>Title</label>
							<input type="text" class="form-control" name="title" value="<?php echo $settings['title']; ?>">
						</div>
						<div class="form-group">
							<label>Description</label>
							<textarea class="form-control" name="description" rows="3"><?php echo $settings['description']; ?></textarea>
						</div>
						<div class="form-group">
							<label>Keywords</label>
							<textarea class="form-control" name="keywords" rows="3"><?php echo $settings['keywords']; ?></textarea>
						</div>
						<div class="form-group">
							<label>Site name</label>
							<input type="text" class="form-control" name="sitename" value="<?php echo $settings['sitename']; ?>">
						</div>
						<div class="form-group">
							<label>Site url address</label>
							<input type="text" class="form-control" name="url" value="<?php echo $settings['url']; ?>">
						</div>
						<div class="form-group">
							<label>Site email address</label>
							<input type="text" class="form-control" name="email" value="<?php echo $settings['email']; ?>">
						</div>
						<div class="form-group">
							<label>Site phone</label>
							<input type="text" class="form-control" name="phone" value="<?php echo $settings['phone']; ?>">
						</div>
						<div class="form-group">
							<label>Facebook profile link</label>
							<input type="text" class="form-control" name="fb_prof" value="<?php echo $settings['fb_prof']; ?>">
						</div>
						<div class="form-group">
							<label>Twitter profile link</label>
							<input type="text" class="form-control" name="tw_prof" value="<?php echo $settings['tw_prof']; ?>">
						</div>
						<div class="form-group">
							<label>Linkedin profile link</label>
							<input type="text" class="form-control" name="in_prof" value="<?php echo $settings['in_prof']; ?>">
						</div>
						<div class="form-group">
							<label>Changer.com Referral ID</label>
							<input type="text" class="form-control" name="changer_refid" value="<?php echo $settings['changer_refid']; ?>">
						</div>
						<button type="submit" class="btn btn-primary" name="btn_save"><i class="fa fa-check"></i> Save changes</button>
					</form>
			      </div>
				</div>
	</div>
</div>
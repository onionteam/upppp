<ol class="breadcrumb">
	<li><a href="./">WebAdmin</a></li>
	<li class="active">Dashboard</li>
</ol>

<div class="row">
	<div class="col-lg-3">
		 <div class="panel panel-default twitter">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Users</small>
                        <h3 class="count">
                            <?php $get_stats = $db->query("SELECT * FROM users"); echo $get_stats->num_rows; ?></h3>
                        <i class="fa fa-users"></i>
                    </div>
                </div>
	</div>
	<div class="col-lg-3">
		<div class="panel panel-default google-plus">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Exchanges</small>
                        <h3 class="count">
                            <?php $get_stats = $db->query("SELECT * FROM exchanges"); echo $get_stats->num_rows; ?></h3>
                        <i class="fa fa-refresh"></i>
                    </div>
                </div>
	</div>
	<div class="col-lg-3">
		<div class="panel panel-default facebook-like">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Testimonials</small>
                        <h3 class="count">
                            <?php $get_stats = $db->query("SELECT * FROM testimonials"); echo $get_stats->num_rows; ?></h3>
                        <i class="fa fa-comments"></i>
                    </div>
                </div>
	</div>
	<div class="col-lg-3">
		<div class="panel panel-default visitor">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Profit Today</small>
                        <h3 class="count">
                            $<?php $date = date("d/m/Y"); $get_stats = $db->query("SELECT * FROM earnings WHERE date='$date'"); if($get_stats->num_rows>0) { $get = $get_stats->fetch_assoc(); echo $get[earnings]; } else { echo '0'; } ?></h3>
                        <i class="fa fa-dollar"></i>
                    </div>
                </div>
	</div>
	<div class="col-lg-8">
		<div class="panel panel-primary">
			<div class="panel-heading">Pending withdrawals</div>
			<div class="panel-body">
				<table class="table">
		      <thead>
		        <tr>
		          <th>#</th>
		          <th>User</th>
		          <th>Amount</th>
		          <th>Account</th>
				  <th>Action</th>
		        </tr>
		      </thead>
		      <tbody>
		      <?php
			  $i=1;
			  $query = $db->query("SELECT * FROM withdrawals WHERE status='1' ORDER BY id");
			  if($query->num_rows>0) {
			    while($row = $query->fetch_assoc()) {
					$rows[] = $row;
				}
				foreach($rows as $row) {
				?>
				<tr>
		          <th scope="row"><?php echo $i; ?></th>
		          <td><a href="./?a=users&b=edit&id=<?php echo $row['id']; ?>"><?php echo idinfo($row['uid'],"username"); ?></a></td>
		          <td>$<?php echo $row['amount']; ?></td>
		          <td><?php echo $row['account']; ?> (<?php echo decodeCompany($row['to_company']); ?>)</td>
				  <td>
					<a href="./?a=withdrawals&b=mark_completed&id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Mark as completed"><i class="fa fa-check"></i></a> 
											<a href="./?a=withdrawals&b=mark_denied&id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Mark as denied"><i class="fa fa-times"></i></a>
				  </td>
		        </tr>
				<?php 
				$i++;
				}
			  } else {
				echo '<tr><td colspan="5">No have requests for withdrawal.</td></tr>';
			  }
			  ?>
		      </tbody>
		    </table>
			</div>	
		</div>
	</div>
	<div class="col-lg-4">
		<div class="row">
			<div class="col-lg-6">
				<div class="panel panel-default google-plus">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Referrals</small>
                        <h3 class="count">
                           <?php $get_stats = $db->query("SELECT * FROM exchanges WHERE refid > 0"); echo $get_stats->num_rows; ?>
						</h3>
                    </div>
                </div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-default google-plus">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Withdrawals</small>
                        <h3 class="count">
                           <?php $get_stats = $db->query("SELECT * FROM withdrawals"); echo $get_stats->num_rows; ?>
						</h3>
                    </div>
                </div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-default google-plus">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Total payed</small>
                        <h3 class="count">
                           $<?php echo getTotalPayed(); ?>
						</h3>
                    </div>
                </div>
			</div>
			<div class="col-lg-6">
				<div class="panel panel-default google-plus">
                    <div class="panel-body fa-icons">
                        <small class="social-title">Total earned</small>
                        <h3 class="count">
                           $<?php echo $settings['earnings']; ?>
						</h3>
                    </div>
                </div>
			</div>
		</div>
	</div>
</div>
<?php
$b = protect($_GET['b']);
$id = protect($_GET['id']);
?>
<ol class="breadcrumb">
	<li><a href="./">WebAdmin</a></li>
	<?php if($b == "preview") { ?>
	<li><a href="./?a=exchanges">Exchanges</a></li>
	<li class="active">Preview</li>
	<?php } else { ?>
	<li class="active">Exchanges</li>
	<?php } ?>
</ol>

<div class="row">
	<div class="col-lg-12">
			<?php
			if($b == "preview") {
			$query = $db->query("SELECT * FROM exchanges WHERE id='$id'");
			if($query->num_rows==0) { header("Location: ./?a=exchanges"); }
			$row = $query->fetch_assoc();
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						<i class="fa fa-search"></i> Preview exchange 
				  </div>
                  <div class="panel-body">
					<h3>Exchange id: <?php echo $row['exchange_id']; ?></h3>
					<table class="table">
						<thead>
							<tr>
								<td>User</td>
								<td>Send</td>
								<td>Receive</td>
								<td>Amount</td>
								<td>Status</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo idinfo($row['uid'],"username"); ?></td>
								<td><img src="../<?php echo getIcon($row['c_send']); ?>" width="16px"> <?php echo getFullName($row['c_send']); ?></td>
								<td><img src="../<?php echo getIcon($row['c_receive']); ?>" width="16px"> <?php echo getFullName($row['c_receive']); ?></td>
								<td>$<?php echo $row['a_send']; ?></td>
								<td><?php echo getStatus($row['status']); ?></td>
							</tr>
							<tr>
								<td colspan="5">&nbsp;</td>
							</tr>
						</tbody>
						<thead>
							<tr>
								<td>Payee</td>
								<td>Referral id</td>
								<td>Exchange rate</td>
								<td>Amount receive</td>
								<td>Requested on</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo $row['c_payee']; ?></td>
								<td><?php if($row['refid'] == "0") { echo 'None'; } else { echo idinfo($row['refid'],"username"); } ?></td>
								<td><?php echo $row['a_rate']; ?></td>
								<td>$<?php echo $row['a_receive']; ?></td>
								<td><?php echo date("d/m/Y H:i",$row['time']); ?></td>
							</tr>
							<tr>
								<td colspan="5">&nbsp;</td>
							</tr>
						</tbody>
						<thead>
							<tr>
								<td>Receiver account</td>
								<td>Receiver email</td>
								<td>Expiration</td>
								<td>Comission</td>
								<td>Action</td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php echo $row['account']; ?></td>
								<td><?php echo $row['email']; ?></td>
								<td><?php echo date("d/m/Y H:i",$row['expiration']); ?></td>
								<td>$<?php $comission1 = $row['a_send'] - $row['a_receive']; $comission2 = ($comission1 / 100) * 10; echo $comission2; ?></td>
								<td></td>
							</tr>
						</tbody>
					</table>
				  </div>
				</div>
				<?php
			} else {
				?>
				<div class="panel panel-primary">
                  <div class="panel-heading"> 
						<i class="fa fa-refresh"></i> Exchanges 
				  </div>
                  <div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
								<td width="25%">User</td>
								<td width="20%">Send</td>
								<td width="20%">Receive</td>
								<td width="15%">Amount</td>
								<td width="15%">Status</td>
								<td width="5%">Action</td>
							</tr>
						</thead>
						<tbody>
							<?php
							$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
							$limit = 20;
							$startpoint = ($page * $limit) - $limit;
							if($page == 1) {
								$i = 1;
							} else {
								$i = $page * $limit;
							}
							$statement = "exchanges";
							$query = $db->query("SELECT * FROM {$statement} ORDER BY id LIMIT {$startpoint} , {$limit}");
							if($query->num_rows>0) {
								while($row = $query->fetch_assoc()) {
									$rows[] = $row;
								}
								foreach($rows as $row) {
									?>
									<tr>
										<td><?php if($row['uid'] == "0") { echo 'Anonymous'; } else { echo idinfo($row['uid'],"username"); } ?></td>
										<td><img src="../<?php echo getIcon($row['c_send']); ?>" width="16px"> <?php echo getFullName($row['c_send']); ?></td>
										<td><img src="../<?php echo getIcon($row['c_receive']); ?>" width="16px"> <?php echo getFullName($row['c_receive']); ?></td>
										<td>$<?php echo $row['a_send']; ?></td>
										<td><?php echo getStatus($row['status']); ?></td>
										<td>
											<a href="./?a=exchanges&b=preview&id=<?php echo $row['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="Preview"><i class="fa fa-search"></i></a> 
										</td>
									</tr>
									<?php
								}
							} else {
								echo '<tr><td colspan="6">No have recorded exchanges.</td></tr>';
							}
							?>
						</tbody>
					</table>
					<?php
					$ver = "./?a=exchanges";
					if(pagination($statement,$ver,$limit,$page)) {
						echo pagination($statement,$ver,$limit,$page);
					}
					?>
			      </div>
				</div>
				<?php
			}
			?>
	</div>
</div>
<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include("../includes/ChangerAPI.php");
/*** Public Mode ***/
$Changer_API = new ChangerAPI();

$amount = protect($_GET['amount']);
$f_send = protect($_GET['f_send']);
$f_receive = protect($_GET['f_receive']);
$r_account = protect($_GET['r_account']);
$r_email = protect($_GET['r_email']);
$time = time();
if(checkSession()) {
	$uid = $_SESSION['ex_uid'];
} else {
	$uid = 0;
}
$order = array(
    'email' => "$r_email", // public mode
	'refid' => "$settings[changer_refid]",
    'send' => "$f_send",
    'receive' => "$f_receive",
    'amount' => "$amount",
	'receiver_id' => "$r_account",
);

try {
    $makeExchange = $Changer_API->makeExchange($order);
    foreach($makeExchange as $v=>$k) {
		$row[$v] = $k;
	}
	$json['status'] = 'ok';
	$json['msg'] = 'ok';
	$json['exchange_id'] = $row['exchange_id'];
	$json['payee'] = $row['payee'];
	$json['expiration'] = $row['expiration'];
	$a_receive = $amount * $row['rate'];
	$query = $db->query("INSERT exchanges (c_send,c_receive,c_payee,a_send,a_receive,a_rate,uid,account,email,exchange_id,status,expiration,time,refid) VALUES ('$f_send','$f_receive','$row[payee]','$amount','$a_receive','$row[rate]','$uid','$r_account','$r_email','$row[exchange_id]','new','$row[expiration]','$time','$_SESSION[refid]')");
} catch (Exception $e) {
    $json['status'] = 'error';
	$json['msg'] = 'ERROR: '. $e->getMessage();
}
echo json_encode($json);
?>
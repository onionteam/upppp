<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2);
include("../includes/ChangerAPI.php");
/*** Public Mode ***/
$Changer_API = new ChangerAPI();

$trans_id = protect($_GET['trans_id']);
$exchange_id = protect($_GET['exchange_id']);
$confirm = array(
	'batch' => "$trans_id" // OKPay: ID of your payment's TxnInfo -  Perfect Money: PAYMENT_BATCH_NUM of your payment - BTC-e: USD redeemable code
);
try {
	$confirmExchange = $Changer_API->confirmExchange($exchange_id, $confirm);
	foreach($confirmExchange as $v=>$k) {
		$row[$v] = $k;
	}
	if($row['success'] == "true") {
		$json['status'] = "ok";
		$json['msg'] = "ok";
	} else {
		$json['status'] = "error";
		$json['msg'] = error($lang['error_26']);
	}
} catch (Exception $e) {
    $json['status'] = "error";
	$json['msg'] = error("ERROR: ". $e->getMessage());
}
echo json_encode($json);
?>
<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
include("../includes/ChangerAPI.php");
/*** Public Mode ***/
$Changer_API = new ChangerAPI();
$amount = protect($_GET['amount']);
$payee = protect($_GET['payee']);
$exchange_id = protect($_GET['exchange_id']);
$expiration = protect($_GET['expiration']);
$f_send = protect($_GET['f_send']);
$f_receive = protect($_GET['f_receive']);

if($f_send == "pm_USD") {
	$message = '<h3>'.$lang[now_send].' '.$amount.' USD '.$lang[to].' Perfect Money '.$lang[account].':</h3><h2><small>'.$payee.'</small></h2>';
	$form = '<p>'.$lang[info_payment_1].'</p>
				<div class="form-group">
					<label>'.$lang[transaction_id].':</label>
					<input type="text" class="form-control" name="trans_id" id="trans_id">
				</div>
				<div id="verify_status"></div>
				<button type="button" class="btn btn-primary btn-block" onclick="verifyPayment();">'.$lang[btn_10].'</button>';
} elseif($f_send == "okpay_USD") {
	$message = '<h3>'.$lang[now_send].' '.$amount.' USD '.$lang[to].' OKPay '.$lang[account].':</h3><h2><small>'.$payee.'</small></h2>';
	$form = '<p>'.$lang[info_payment_2].'</p>
				<div class="form-group">
					<label>'.$lang[transaction_id].':</label>
					<input type="text" class="form-control" name="trans_id" id="trans_id">
				</div>
				<div id="verify_status"></div>
				<button type="button" class="btn btn-primary btn-block" onclick="verifyPayment();">'.$lang[btn_10].'</button>';
} elseif($f_send == "payeer_USD") {
	$message = '<h3>'.$lang[now_send].' '.$amount.' USD '.$lang[to].' Payeer '.$lang[account].':</h3><h2><small>'.$payee.'</small></h2>';
	$form = '<p>'.$lang[info_payment_3].'</p>
				<div class="form-group">
					<label>'.$lang[transaction_id].':</label>
					<input type="text" class="form-control" name="trans_id" id="trans_id">
				</div>
				<div id="verify_status"></div>
				<button type="button" class="btn btn-primary btn-block" onclick="verifyPayment();">'.$lang[btn_10].'</button>';
} elseif($f_send == "advcash_USD") {
	$message = '<h3>'.$lang[now_send].' '.$amount.' USD '.$lang[to].' AdvCash '.$lang[account].':</h3><h2><small>'.$payee.'</small></h2>';
	$form = '<p>'.$lang[info_payment_4].'</p>
				<div class="form-group">
					<label>'.$lang[transaction_id].':</label>
					<input type="text" class="form-control" name="trans_id" id="trans_id">
				</div>
				<div id="verify_status"></div>
				<button type="button" class="btn btn-primary btn-block" onclick="verifyPayment();">'.$lang[btn_10].'</button>';
} elseif($f_send == "btce_USD") {
	$message = '';
	$form = '<p>'.$lang[info_payment_5].'</p>
				<div class="form-group">
					<label>'.$lang[redm_code].':</label>
					<input type="text" class="form-control" name="trans_id" id="trans_id">
				</div>
				<div id="verify_status"></div>
				<button type="button" class="btn btn-primary btn-block" onclick="verifyPayment();">'.$lang[btn_10].'</button>';
} elseif($f_send == "bitcoin_BTC") {
	$message = '<h3>'.$lang[now_send].' '.$amount.' BTC '.$lang[to].' Bitcoin '.$lang[address].':</h3><h4><small>'.$payee.'</small></h4><small>'.$lang[info_payment_6].'</small>';
	$form = '<script type="text/javascript">startRefresh();</script>';
} else {
	$message = '';
	$form = '';
}
?>
<div class="panel panel-default">
	<div class="panel-body">
		<center>
			<?php echo $message; ?>
		</center>
		<?php echo $form; ?>
	</div>
</div>
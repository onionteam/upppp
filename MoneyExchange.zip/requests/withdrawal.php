<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
if(checkSession()) {
	$amount = protect($_POST['amount']);
	$company = protect($_POST['company']);
	$account = protect($_POST['account']);
	$time = time();
	if(empty($amount) or empty($company) or empty($account)) { echo error("All fields are required."); }
	elseif(!is_numeric($amount)) { echo error("Please enter valid amount. Eg: 9.99"); }
	elseif($amount > idinfo($_SESSION['ex_uid'],"earnings")) { echo error("Amount exceeds your availability."); }
	else {
		$verified=0;
		if($company == "paypal") {
			if(isValidEmail($account)) {
				$verified=1;
			} else {
				$verified=0;
				$error = error("Please enter valid PayPal account. Eg: john@gmail.com");
			}
		} elseif($company == "perfectmoney") {
			if(strlen($account)==7) {
				$verified=1;
			} else {
				$verified=0;
				$error = error("Please enter valid PerfectMoney account. Eg: Uxxxxxx)");
			}
		} elseif($company == "okpay") {
			if(strlen($account)==8 or isValidEmail($account)) {
				$verified=1;;
			} else {
				$verified=0;
				$error = error("Please enter valid OKPay account. Eg: OKxxxxxx or email example@gmail.com");
			}
		} elseif($company == "payeer") {
			if(strlen($r_account)==8) {
				$verified=1;
			} else {
				$verified=0;
				$error = error("Please enter valid Payeer account. Eg: P1000000");
			}
		} elseif($company == "advcash") {
			if(isValidEmail($account)) {
				$verified=1;
			} else {
				$verified=0;
				$error = error("Please enter valid AdvCash account. Eg: john@gmail.com");
			}
		} else {
			$verified=0;
			$error = error("Unknown error.");
		}
		if($verified==1) {
			$insert = $db->query("INSERT withdrawals (uid,amount,account,to_company,status,time) VALUES ('$_SESSION[ex_uid]','$amount','$account','$company','1','$time')");
			$update = $db->query("UPDATE users SET earnings=earnings-$amount WHERE id='$_SESSION[ex_uid]'");
			echo success("Your withdrawal was in progress. You will receive email when is completed.");
		} else {
			echo $error;
		}
	}
} else {
	echo error("Hacking attempt!");
}
?>
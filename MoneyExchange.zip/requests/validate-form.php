<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
include("../includes/ChangerAPI.php");
$amount_send = protect($_GET['amount_send']);
$amount_receive = protect($_GET['amount_receive']);
$f_receive = protect($_GET['f_receive']);
$r_account = protect($_GET['r_account']);
$r_email = protect($_GET['r_email']);
$account_verify = false;
$verified = false;
if($f_receive == "pm_USD") {
	$account_verify = true;
	if(strlen($r_account)==7) {
		$verified = true;
	} else {
		$verified = false;
		$msg = error($lang['error_27']);
	}
} elseif($f_receive == "okpay_USD") {
	$account_verify = true;
	if(strlen($r_account)==8 or isValidEmail($r_account)) {
		$verified = true;
	} else {
		$verified = false;
		$msg = error($lang['error_28']);
	}
} elseif($f_receive == "payeer_USD") {
	$account_verify = true;
	if(strlen($r_account)==8) {
		$verified = true;
	} else {
		$verified = false;
		$msg = error($lang['error_29']);
	}
} elseif($f_receive == "advcash_USD") {
	$account_verify = true;
	if(isValidEmail($r_account)) {
		$verified = true;
	} else {
		$verified = false;
		$msg = error($lang['error_30']);
	}
} elseif($f_receive == "btce_USD") {
	$account_verify = false;
} elseif($f_receive == "bitcoin_BTC") {
	$account_verify = true;
	if(strlen($r_account)==27) {
		$verified = true;
	} else {
		$verified = false;
		$msg = error($lang['error_31']);
	}
} else {
	die("Hacking attempt!");
}

if($account_verify == true && $verified) {
	if(!isValidEmail($r_email)) { echo error($lang['error_32']); }
	elseif(!is_numeric($amount_send) && !is_numeric($amount_receive)) { echo error($lang['error_33']); }
	else {
		echo 'ok';
	}
} elseif($account_verify == false) {
	if(!isValidEmail($r_email)) { echo error($lang['error_32']); }
	elseif(!is_numeric($amount_send) && !is_numeric($amount_receive)) { echo error($lang['error_33']); }
	else {
		echo 'ok';
	}
} else {
	echo $msg;
}
?>
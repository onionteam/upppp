<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
include("../includes/ChangerAPI.php");
/*** Public Mode ***/
$Changer_API = new ChangerAPI();
$send = protect($_GET['send']);
$receive = protect($_GET['receive']);
if($send == "pm_USD" && $receive == "okpay_USD") {
	$message = $lang['error_19'];
} elseif($send == "okpay_USD" && $receive == "pm_USD") {
	$message = $lang['error_20'];
} else {
	$rate = $Changer_API->getRate($send,$receive);
	foreach($rate as $v=>$k) {
		$row[$v] = $k;
	}
	$rp = $row['rate'];
	if($send == "bitcoin_BTC" && $receive == "pm_USD" or $send == "bitcoin_BTC" && $receive == "okpay_USD" or $send == "bitcoin_BTC" && $receive == "payeer_USD" or $send == "bitcoin_BTC" && $receive == "advcash_USD" or $send == "bitcoin_BTC" && $receive == "btce_USD") {
		$amount_send = 1;
		$amount_receive = number_format($rp,2);
		$exchRate = $rp;
	} elseif($receive == "bitcoin_BTC" && $send == "pm_USD" or $receive == "bitcoin_BTC" && $send == "okpay_USD" or $receive == "bitcoin_BTC" && $send == "payeer_USD" or $receive == "bitcoin_BTC" && $send == "advcash_USD" or $receive == "bitcoin_BTC" && $send == "btce_USD") {
		$amount_send = 100;
		$amount_receive = 100 * $rp;
		$exchRate = $rp;
	} elseif($send == "bitcoin_BTC" && $receive == "bitcoin_BTC") {
		$amount_send = 1;
		$amount_receive = 1*$rp;
		$exchRate = $rp;
	} else {
		$amount_send = number_format(100,2);
		$amount_receive = number_format(100 * $rp,2);
		$exchRate = number_format($rp,2);
	}
	if($receive == "pm_USD") {
		$account_input = '<div class="form-group">
							<label>Perfect Money Account</label>
							<input type="text" class="form-control" name="r_account" id="r_account" placeholder="Enter your Perfect Money account.">
						</div>';
	} elseif($receive == "okpay_USD") {
		$account_input = '<div class="form-group">
							<label>OKPAY Account</label>
							<input type="text" class="form-control" name="r_account" id="r_account" placeholder="Enter your OKPAY account.">
						</div>';
	} elseif($receive == "payeer_USD") {
		$account_input = '<div class="form-group">
							<label>Payeer Account</label>
							<input type="text" class="form-control" name="r_account" id="r_account" placeholder="Enter your Payeer account.">
						</div>';
	} elseif($receive == "advcash_USD") {
		$account_input = '<div class="form-group">
							<label>AdvCash Account</label>
							<input type="text" class="form-control" name="r_account" id="r_account" placeholder="Enter your AdvCash account.">
						</div>';
	} elseif($receive == "btce_USD") {
		$account_input = '';
	} elseif($receive == "bitcoin_BTC") {
		$account_input = '<div class="form-group">
							<label>Bitcoin Address</label>
							<input type="text" class="form-control" name="r_account" id="r_account" placeholder="Enter your Bitcoin address.">
						</div>';
	} else {
		$account_input = '';
	}
	if(checkSession()) {
		$email_input = '<div class="form-group">
							<label>Email address</label>
							<input type="text" class="form-control" name="r_email" id="r_email" placeholder="Enter your email address." value="'.idinfo($_SESSION[ex_uid],"email").'">
						</div>';
	} else {	
		$email_input = '<div class="form-group">
							<label>Email address</label>
							<input type="text" class="form-control" name="r_email" id="r_email" placeholder="Enter your email address.">
						</div>';
	}
	$message = '<div class="row">
					<div class="col-sm-12 col-md-12 col-lg-12">
						<div class="input-group">
						  <span class="input-group-addon" id="basic-addon1"><img src="'.$settings[url].getIcon($send).'" width="20px"></span>
						  <input type="text" class="form-control" id="amount_send" name="amount_send" value="'.$amount_send.'" onkeyup="updateAmount(1);" onkeydown="updateAmount(1);">
						</div>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-12">
						<center>
							<i class="fa fa-angle-up fa-2x"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-angle-down fa-2x"></i>
						</center>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-12">
						<div class="input-group">
						  <span class="input-group-addon" id="basic-addon1"><img src="'.$settings[url].getIcon($receive).'" width="20px"></span>
						  <input type="text" class="form-control" id="amount_receive" name="amount_receive" value="'.$amount_receive.'" onkeyup="updateAmount(2);" onkeydown="updateAmount(2);">
						</div>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-12">
						<center>
							<span style="font-size:10px;">
								'.$lang[exchange_rate].': <img src="'.$settings[url].getIcon($send).'" width="16px"> '.exchRate($send).' to <img src="'.$settings[url].getIcon($receive).'" width="16px">  '.exchRate($receive).' = <span id="eRate">'.$exchRate.'</span>
							</span>
						</center>
					</div>
					<div class="col-sm-12 col-md-12 col-lg-12">
						<br>
						'.$account_input.'
						'.$email_input.'
						<div id="validate_results"></div>
						<br>
						<button type="button" class="btn btn-primary btn-block" onclick="validateForm();"><i class="fa fa-refresh"></i> '.$lang[btn_6].'</button>
					</div>
				</div>';
}
?>
<div class="panel panel-default">
  <div class="panel-body">
    <?php echo $message; ?>
  </div>
</div>
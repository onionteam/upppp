<?php
ob_start();
session_start();
include("../includes/config.php"); 
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("../includes/functions.php");
include(getLanguage($settings['url'],null,2));
include("../includes/ChangerAPI.php");
/*** Public Mode ***/
$Changer_API = new ChangerAPI();

$exchange_id = protect($_GET['exchange_id']);
try {
    $checkOrder = $Changer_API->checkExchange($exchange_id);
    foreach($checkOrder as $v=>$k) {
		$row[$v] = $k;
	}
	if($row['status'] == "new") {
		$message = info($lang['error_16']); 
		$message .= '<center><small>'.$lang[status_refresh].'</small></center>';
		$update = $db->query("UPDATE exchanges SET status='new' WHERE exchange_id='$exchange_id'");
	} elseif($row['status'] == "processing") {
		$message = info($lang['info_1']);
		$message .= '<center><small>'.$lang[status_refresh].'</small></center>';
		$update = $db->query("UPDATE exchanges SET status='processing' WHERE exchange_id='$exchange_id'");
	} elseif($row['status'] == "processed") {
		$message = success($lang['success_4']);
		$update = $db->query("UPDATE exchanges SET status='processed' WHERE exchange_id='$exchange_id'");
		$query = $db->query("SELECT * FROM exchanges WHERE exchange_id='$exchange_id'");
		$row = $query->fetch_assoc();
		$comission = $row['a_send'] - $row['a_receive'];
		$comission = ($comission / 100) * 10;
		$total = $comission / 2;
		$update = $db->query("UPDATE settings SET earnings=earnings+$comission");
		$date = date("d/m/Y");
		$check_exists = $db->query("SELECT * FROM earnings WHERE date='$date'");
		if($check_exists->num_rows>0) {
			$update = $db->query("UPDATE earnings SET earnings=earnings+$comission WHERE date='$date'");
		} else {
			$insert = $db->query("INSERT earnings (date,earnings) VALUES ('$data','$comission')");
		}
		if($_SESSION['refid']) {
			$update = $db->query("UPDATE users SET earnings=earnings+$total WHERE id='$_SESSION[refid]'");
		}
	} elseif($row['status'] == "deniad") {
		$message = error($lang['error_17']);
		$update = $db->query("UPDATE exchanges SET status='deniad' WHERE exchange_id='$exchange_id'");
	} else {
		$message = error("$lang[error_18] $exchange_id");
	}
} catch (Exception $e) {
    $message = error("ERROR: ". $e->getMessage());
}
?>
<div class="panel panel-default">
	<div class="panel-body">
		<?php echo $message; ?>
	</div>
</div>
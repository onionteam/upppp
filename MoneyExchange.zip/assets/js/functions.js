var interval;

$(document).ready(function() {
	$("#list-group1 a").click(function() {
		$("#list-group1 .list-group-item").removeClass("active");
		$(this).addClass("active");
		$("#f_send").val($(this).attr("id"));
		generateForm();
	});
	$("#list-group2 a").click(function() {
		$("#list-group2 .list-group-item").removeClass("active");
		$(this).addClass("active");
		$("#f_receive").val($(this).attr("id"));
		generateForm();
	});
	
	$('#quote-carousel').carousel({
		pause: true,
		interval: 4000,
	  });
});

function generateForm() {
	var url = $("#url").val();
	var f_send = $("#f_send").val();
	var f_receive = $("#f_receive").val();
	if(f_send != "" && f_receive !== "") {
		var data_url = url + "requests/generate-form.php?send="+f_send+"&receive="+f_receive;
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "html",
           success: function (data) {
			   stopRefresh();
               $("#exchange_results").html(data);
			   $("#f_amount").val($("#amount_send").val());
           }
		});
	}
}

function round2Fixed(value) {
  value = +value;

  if (isNaN(value))
    return NaN;

  // Shift
  value = value.toString().split('e');
  value = Math.round(+(value[0] + 'e' + (value[1] ? (+value[1] + 2) : 2)));

  // Shift back
  value = value.toString().split('e');
  return (+(value[0] + 'e' + (value[1] ? (+value[1] - 2) : -2))).toFixed(2);
}

function updateAmount(type) {
	var url = $("#url").val();
	var amount_send = $("#amount_send");
	var amount_receive = $("#amount_receive");
	var f_send = $("#f_send").val();
	var f_receive = $("#f_receive").val();
	var exchRate = $("#eRate").text();
	if (type == "1") {
		amount_receive.val("Loading...");
		var new_amount = amount_send.val() * exchRate;
		var sum = round2Fixed(new_amount);
		amount_receive.val(sum);
		$("#f_amount").val(amount_send.val());
	}
	
	if (type == "2") {
		amount_send.val("Loading...");
		var sum1 = amount_receive.val() / exchRate;
		var sum2 = sum1 + amount_receive.val();
		var sum3 = round2Fixed(sum2);
		amount_send.val(sum3);
	}
}

function validateForm() {
	var url = $("#url").val();
	var amount_send = $("#amount_send").val();
	var amount_receive = $("#amount_receive").val();
	var f_receive = $("#f_receive").val();
	var r_account = $("#r_account").val();
	var r_email = $("#r_email").val();
	var data_url = url + "requests/validate-form.php?amount_send="+amount_send+"&amount_receive="+amount_receive+"&f_receive="+f_receive+"&r_account="+r_account+"&r_email="+r_email;
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "html",
           success: function (data) {
               if(data == "ok") {
					$("#exchange_results").html('<div class="panel panel-default"><div class="panel-body"><center><i class="fa fa-spinner fa-spin fa-3x"></i><h3>Processing...</h3></center></div></div>');
					makeExchange(r_account,r_email);
			   } else {
					$("#validate_results").html(data);
			   }
           }
		});
}

function makeExchange(r_account,r_email) {
	var url = $("#url").val();
	var amount = $("#f_amount").val();
	var f_send = $("#f_send").val();
	var f_receive = $("#f_receive").val();
	var data_url = url + "requests/make-exchange.php?amount="+amount+"&f_send="+f_send+"&f_receive="+f_receive+"&r_account="+r_account+"&r_email="+r_email;
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "json",
           success: function (data) {
               if (data['status'] == "error") {
					var msg = data['msg'];
					$("#exchange_results").html('<div class="panel panel-default"><div class="panel-body">'+msg+'</div></div>');
			   } else {
					$("#f_exchange_id").val(data['exchange_id']);
					$("#f_payee").val(data['payee']);
					$("#f_expiration").val(data['expiration']);
					makeVerifyForm();
			   }
           }
		});
}

function makeVerifyForm() {
	var url = $("#url").val();
	var amount = $("#f_amount").val();
	var payee = $("#f_payee").val();
	var exchange_id = $("#f_exchange_id").val();
	var expiration = $("#f_expiration").val();
	var f_send = $("#f_send").val();
	var f_receive = $("#f_receive").val();
	var data_url = url + "requests/make-verify-form.php?amount="+amount+"&f_send="+f_send+"&f_receive="+f_receive+"&payee="+payee+"&exchange_id="+exchange_id+"&expiration="+expiration;
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "html",
           success: function (data) {
               $("#exchange_results").html(data);
           }
		});
}

function verifyPayment() {
	var url = $("#url").val();
	var exchange_id = $("#f_exchange_id").val();
	var trans_id = $("#trans_id").val();
	var data_url = url + "requests/verify-payment.php?exchange_id="+exchange_id+"&trans_id="+trans_id;
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "json",
           success: function (data) {
               if (data['status'] == "error") {
					var msg = data['msg'];
					$("#verify_status").html(msg);
			   } else {
					checkStatus();
			   }
           }
		});
}

function checkStatus() {
	var url = $("#url").val();
	var exchange_id = $("#f_exchange_id").val();
	var data_url = url + "requests/check-status.php?exchange_id="+exchange_id;
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "html",
           success: function (data) {
               $("#exchange_results").html(data);
			   stopRefresh();
           }
		});
}

function startRefresh() { 
	interval = setInterval(checkStatus,5000);
}

function stopRefresh() {
	clearInterval(interval);
}

function doWithdrawal() {
	var url = $("#url").val();
	var data_url = url + "requests/withdrawal.php";
		$.ajax({
           type: "POST",
           url: data_url,
           dataType: "html",
		   data: $("#form_withdrawal").serialize(),
           success: function (data) {
               $("#w_r").html(data);
			   updateEarnings();
			   $("#form_withdrawal")[0].reset();
           }
		});
}

function updateEarnings() {
	var url = $("#url").val();
	var data_url = url + "requests/update-earnings.php";
		$.ajax({
           type: "GET",
           url: data_url,
           dataType: "html",
           success: function (data) {
               $("#ref_amount").html(data);
           }
		});
}
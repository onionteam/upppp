<?php if(!checkSession()) { header("Location: ./login"); } 
$id = protect($_GET['id']);
$query = $db->query("SELECT * FROM exchanges WHERE uid='$_SESSION[ex_uid]' and exchange_id='$id'");
if($query->num_rows==0) { header("Location: ./my-account"); }
$row = $query->fetch_assoc();
?>
<!--contact start here-->
<div class="contact">
	<h3>Details for exchange #<?php echo $row['exchange_id']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<table class="table table-hover">
				<thead>
					<tr>
						<td><i class="fa fa-angle-up"></i> <?php echo $lang['table_send']; ?></td>
						<td><i class="fa fa-angle-down"></i> <?php echo $lang['table_receive']; ?></td>
						<td><i class="fa fa-dollar"></i> <?php echo $lang['table_amount']; ?></td>
						<td><i class="fa fa-info-circle"></i> <?php echo $lang['table_status']; ?></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><img src="<?php echo getIcon($row['c_send']); ?>" width="16px"> <?php echo getFullName($row['c_send']); ?></td>
						<td><img src="<?php echo getIcon($row['c_receive']); ?>" width="16px"> <?php echo getFullName($row['c_receive']); ?></td>
						<td><?php echo $row['a_send']; ?></td>
						<td><?php echo getStatus($row['status']); ?></td>
					</tr>
					<tr>
						<td colspan="4"><br></td>
					</tr>
				</tbody>
				<thead>
					<tr>
						<td><i class="fa fa-user"></i> <?php echo $lang['payee']; ?></td>
						<td><i class="fa fa-refresh"></i> <?php echo $lang['exchange_rate']; ?></td>
						<td><i class="fa fa-dollar"></i> <?php echo $lang['r_amount']; ?></td>
						<td><i class="fa fa-clock-o"></i> <?php echo $lang['expiration']; ?></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php echo $row['c_payee']; ?></td>
						<td><?php echo $row['a_rate']; ?></td>
						<td><?php echo $row['a_receive']; ?></td>
						<td><?php echo date("d/m/Y H:i",$row['expiration']); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

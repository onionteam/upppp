<?php if(!checkSession()) { header("Location: ./login"); } ?>
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['withdrawals']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
				<br><br>
				<table class="table table-hover">
					<thead>
						<tr>
							<td><?php echo $lang['table_amount']; ?></td></td>
							<td width="45%"><?php echo $lang['account']; ?></td></td>
							<td><?php echo $lang['status']; ?></td></td>
							<td><?php echo $lang['requested_on']; ?></td></td>
							<td><?php echo $lang['processed_on']; ?></td></td>
						</tr>
					</thead>
					<tbody>
						<?php
						$query = $db->query("SELECT * FROM withdrawals WHERE uid='$_SESSION[ex_uid]' ORDER BY id");
						if($query->num_rows>0) {
							while($row = $query->fetch_assoc()) {
								$rows[] = $row;
							}
							foreach($rows as $row) {
								?>
								<tr>
									<td>$<?php echo $row['amount']; ?></td>
									<td><?php echo $row['account']; ?> (<?php echo decodeCompany($row['to_company']); ?>)</td>
									<td><?php if($row['status'] == "1") { echo $lang['in_process']; } elseif($row['status'] == "2") { echo $lang['completed']; } else { echo $lang['denied']; } ?></td>
									<td><?php echo date("d/m/Y H:i",$row['time']); ?></td>
									<td><?php if($row['processed'] > 0) { echo date("d/m/Y H:i",$row['processed']); } else { echo '-'; } ?></td>
								</tr>
								<?php
							}
						} else {
							echo '<tr><td colspan="5">No have requested withdrawals.</td></tr>';
						}
						?>
					</tbody>
				</table>	
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->
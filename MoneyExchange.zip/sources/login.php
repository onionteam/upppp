<?php if(checkSession()) { header("Location: ./my-account"); } ?>
<!--contact start here-->
<div class="contact">
	<h3>Login</h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
			if(isset($_POST['btn_login'])) {
				$username = protect($_POST['username']);
				$password = protect($_POST['password']);
				$password = md5($password);
				$query = $db->query("SELECT * FROM users WHERE username='$username' and password='$password'");
				if(empty($username)) { echo error($lang['error_6']); }
				elseif(empty($_POST['password'])) { echo error($lang['error_7']); }
				elseif($query->num_rows==0) { echo error($lang['error_8']); }
				else {
					$row = $query->fetch_assoc();
					if($row['status'] == 2) {
						echo error($lang['error_9']);
					} else {
						$_SESSION['ex_uid'] = $row['id'];
						$_SESSION['ex_username'] = $row['username'];
						header("Location: ./my-account");
					}
				}
			}
			?>
		</div>
		<div class="col-sm-8 col-md-8 col-lg-8">
			<form action="" method="POST">
				<div class="form-group">
					<label><?php echo $lang['username']; ?></label>
					<input type="text" class="form-control" name="username">
				</div>
				<div class="form-group">
					<label><?php echo $lang['password']; ?></label>
					<input type="password" class="form-control" name="password">
				</div>
				<button type="submit" class="btn btn-primary btn-lg" style="padding:5px;" name="btn_login"><i class="fa fa-sign-in"></i> <?php echo $lang['btn_2']; ?></button>
			</form>
			<br><br>
			<p><?php echo $lang['no_have_account']; ?> <a href="./register"><?php echo $lang['create_account']; ?></a>.</p>
			<p><?php echo $lang['forgot_password']; ?> <a href="./reset-password"><?php echo $lang['password_reset']; ?></a>.</p>
		</div>
		<div class="col-sm-4 col-md-4 col-lg-4">
		
		</div>
		
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

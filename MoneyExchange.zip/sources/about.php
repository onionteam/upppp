
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['menu_about']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<?php echo $settings['p_about']; ?>
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

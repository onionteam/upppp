<!--contact start here-->
<div class="contact">
	<div class="contact-top">
		<h3><?php echo $lang['menu_contact']; ?></h3>
	</div>
	<div class="contact-bottom">
	 <?php
	 if(isset($_POST['btn_send'])) {
		$name = protect($_POST['name']);
		$email = protect($_POST['email']);
		$message = $_POST['message'];
		$subject = '['.$settings[sitename].'] New message from client '.$name;
		if(empty($name)) { echo error($lang['error_1']); }
		elseif(empty($email)) { echo error($lang['error_2']); }
		elseif(!isValidEmail($email)) { echo error($lang['error_3']); }
		elseif(empty($message)) { echo error($lang['error_4']); }
		else {
			$headers = 'From: '.$settings[email].'' . "\r\n" .
						'Reply-To: '.$settings[email].'' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();
			$send_status = mail($email, $subject, $message, $headers);
			if($send_status) {
				echo success($lang['success_1']);
			} else {
				echo error($lang['error_5']);
			}
		}
	 }
	 ?>
	 <form action="" method="POST">
		<input type="text" name="name" value="<?php echo $lang['name']; ?>" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '<?php echo $lang['name']; ?>';}"/>
		<input type="text" name="email" class="no-mar" value="<?php echo $lang['email']; ?>" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = '<?php echo $lang['email']; ?>';}"/>
		<textarea onfocus="this.value = '';" name="message" onblur="if (this.value == '') {this.value = '<?php echo $lang['message']; ?>';}"/><?php echo $lang['message']; ?></textarea>
		<input type="submit" name="btn_send" value="<?php echo $lang['btn_1']; ?>" />
	 </form>	
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->
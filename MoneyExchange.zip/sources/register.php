<?php if(checkSession()) { header("Location: ./my-account"); } ?>
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['menu_register']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
			if(isset($_POST['btn_register'])) {
				$name = protect($_POST['name']);
				$username = protect($_POST['username']);
				$password = protect($_POST['password']);
				$cpassword = protect($_POST['cpassword']);
				$email = protect($_POST['email']);
				$check_username = $db->query("SELECT * FROM users WHERE username='$username'");
				$check_email = $db->query("SELECT * FROM users WHERE email='$email'");
				if(empty($name) or empty($username) or empty($password) or empty($cpassword) or empty($email)) { echo error($lang['error_10']); }
				elseif(!isValidUsername($username)) { echo error($lang['error_11']); }
				elseif($check_username->num_rows > 0) { echo error($lang['error_12']); }
				elseif(!isValidEmail($email)) { echo error($lang['error_3']); }
				elseif($check_email->num_rows > 0) { echo error($lang['error_13']); }
				elseif($password !== $cpassword) { echo error($lang['error_14']); }
				else {
					$password = md5($password);
					$ip = $_SERVER['REMOTE_ADDR'];
					$insert = $db->query("INSERT users (name,username,password,email,ip,status,earnings) VALUES ('$name','$username','$password','$email','$ip','1','0')");
					echo success("$lang[success_2] <a href='./login'>$lang[success_2_1]</a> $lang[success_2_2].");
				}
			}
			?>
		</div>
		<div class="col-sm-8 col-md-8 col-lg-8">
			<form action="" method="POST">
				<div class="form-group">
					<label><?php echo $lang['your_name']; ?></label>
					<input type="text" class="form-control" name="name">
				</div>
				<div class="form-group">
					<label><?php echo $lang['username']; ?></label>
					<input type="text" class="form-control" name="username">
				</div>
				<div class="form-group">
					<label><?php echo $lang['password']; ?></label>
					<input type="password" class="form-control" name="password">
				</div>
				<div class="form-group">
					<label><?php echo $lang['confirm_password']; ?></label>
					<input type="password" class="form-control" name="cpassword">
				</div>
				<div class="form-group">
					<label><?php echo $lang['email']; ?></label>
					<input type="text" class="form-control" name="email">
				</div>
				<button type="submit" class="btn btn-primary btn-lg" style="padding:5px;" name="btn_register"><i class="fa fa-plus"></i> <?php echo $lang['btn_3']; ?></button>
			</form>
			<br><br>
			<p><?php echo $lang['have_account']; ?> <a href="./login"><?php echo $lang['login_from']; ?></a>.</p>
			<p><?php echo $lang['forgot_password']; ?> <a href="./reset-password"><?php echo $lang['password_reset']; ?></a>.</p>
		</div>
		<div class="col-sm-4 col-md-4 col-lg-4">
		
		</div>
		
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

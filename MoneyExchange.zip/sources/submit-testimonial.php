<?php
if(!checkSession()) { header("Location: ./login"); }
$show_page=0;
$check_query = $db->query("SELECT * FROM exchanges WHERE uid='$_SESSION[ex_uid]'");
if($check_query->num_rows>0) {
	$check_test = $db->query("SELECT * FROM testimonials WHERE uid='$_SESSION[ex_uid]'");
	if($check_test->num_rows>0) {
		header("Location: ./testimonials");
	}
$show_page=1;
} else {
$show_page=0;
}

if($show_page==0) {
	header("Location: ./testimonials");
}
?>
<!--contact start here-->
<div class="contact">
	<h3><i class="fa fa-plus"></i> <?php echo $lang['submit_testimonial']; ?></h3>
	<div class="contact-bottom">
	 <?php
	 if(isset($_POST['btn_submit'])) {
		$message = protect($_POST['message']);
		if(empty($message)) { echo error($lang['error_15']); }
		else {
			$time = time();
			$insert = $db->query("INSERT testimonials (uid,content,status,time) VALUES ('$_SESSION[ex_uid]','$message','0','$time')");
			echo success($lang['success_3']);
		}
	 }
	 ?>
	 <form action="" method="POST">
		<textarea placeholder="<?php echo $lang['your_feedback']; ?>" name="message"/></textarea>
		<input type="submit" name="btn_submit" value="<?php echo $lang['btn_4']; ?>" />
	 </form>	
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->
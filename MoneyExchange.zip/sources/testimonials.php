<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['menu_testimonials']; ?>
	<?php
	if(checkSession()) {
		$check_query = $db->query("SELECT * FROM exchanges WHERE uid='$_SESSION[ex_uid]'");
		if($check_query->num_rows>0) {
			$check_test = $db->query("SELECT * FROM testimonials WHERE uid='$_SESSION[ex_uid]'");
			if($check_test->num_rows==0) {
				echo '<small>- <a href="./submit-testimonial"><i class="fa fa-plus"></i> '.$lang[submit_testimonial].'</a></small></li>';
			}
		}
	}
	?>
	</h3>
	<div class="row">
		<?php
		$query = $db->query("SELECT * FROM testimonials WHERE status='1' ORDER BY id");
		if($query->num_rows>0) {
			while($row = $query->fetch_assoc()) {
				$rows[] = $row;
			}
			foreach($rows as $row) {
				?>
				<div class="col-sm-6 col-md-6 col-lg-6">
					<blockquote>
					  <p><?php echo $row['content']; ?></p>
					  <footer><cite><?php echo idinfo($row['uid'],"name"); ?> (<?php echo idinfo($row['uid'],"username"); ?>)</cite></footer>
					</blockquote>
				</div>
				<?php
			}
		}
		?>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

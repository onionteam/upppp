<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['faq']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				<?php
				$query = $db->query("SELECT * FROM faq ORDER BY id"); 
				if($query->num_rows>0) {
				  while($row = $query->fetch_assoc()) {
					$rows[] = $row;
				  }
				  foreach($rows as $row) {
				  ?>
				  <div class="panel panel-default">
					<div class="panel-heading" role="tab" id="heading_<?php echo $row['id']; ?>">
					  <h4 class="panel-title">
						<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo $row['id']; ?>" aria-expanded="true" aria-controls="collapseOne">
						  <?php echo $row['title']; ?>
						</a>
					  </h4>
					</div>
					<div id="collapse_<?php echo $row['id']; ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo $row['id']; ?>">
					  <div class="panel-body">
						<?php echo nl2br($row['content']); ?>
					  </div>
					</div>
				  </div>
				<?php 
				}
			   }
			   ?>
			</div>
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

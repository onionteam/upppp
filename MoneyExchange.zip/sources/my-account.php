<?php if(!checkSession()) { header("Location: ./login"); } ?>
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['menu_my_account']; ?></h3>
	<div class="row">
		<div class="col-sm-9 col-md-9 col-lg-9">
			<h4><?php echo $lang['welcome']; ?>, <?php echo idinfo($_SESSION['ex_uid'],"name"); ?>! <small><a href="./change-password"><?php echo $lang['change_password']; ?>, <a href="./withdrawals"><?php echo $lang['withdrawals']; ?></a>, <a href="./logout"><?php echo $lang['logout']; ?></a></small></h4>
			<div class="input-group">
			  <span class="input-group-addon" id="basic-addon1"><?php echo $lang['referral_link']; ?></span>
			  <input type="text" class="form-control" value="<?php echo $settings['url']; ?>refid=<?php echo $_SESSION['ex_uid']; ?>">
			</div>
			<br><br>
			<table class="table table-hover">
				<thead>
					<tr>
						<td width="3px">#</td>
						<td><i class="fa fa-angle-up"></i> <?php echo $lang['table_send']; ?></td>
						<td><i class="fa fa-angle-down"></i> <?php echo $lang['table_receive']; ?></td>
						<td><i class="fa fa-dollar"></i> <?php echo $lang['table_amount']; ?></td>
						<td><i class="fa fa-info-circle"></i> <?php echo $lang['table_status']; ?></td>
						<td><?php echo $lang['table_details']; ?></td>
					</tr>
				</thead>
				<tbody>
					<?php
					$query = $db->query("SELECT * FROM exchanges WHERE uid='$_SESSION[ex_uid]' ORDER BY id");
					if($query->num_rows>0) {
						while($row = $query->fetch_assoc()) {
							$rows[] = $row;
						}
						$i=1;
						foreach($rows as $row) {
							?>
							<tr>
								<td><?php echo $i++; ?></td>
								<td><img src="<?php echo getIcon($row['c_send']); ?>" width="16px"> <?php echo getFullName($row['c_send']); ?></td>
								<td><img src="<?php echo getIcon($row['c_receive']); ?>" width="16px"> <?php echo getFullName($row['c_receive']); ?></td>
								<td><?php echo $row['a_send']; ?></td>
								<td><?php echo getStatus($row['status']); ?></td>
								<td><a href="./details-<?php echo $row['exchange_id']; ?>"><?php echo $lang['view']; ?></a></td>
							</tr>
							<?php
						}
					}
					?>
				</tbody>
			</table>
		</div>
		<div class="col-sm-3 col-md-3 col-lg-3">
			<h4><?php echo $lang['overall_statistics']; ?></h4>
			<h5 class="text-warning"><?php echo getStats($_SESSION['ex_uid'],'new'); ?> <?php echo $lang['pending_requests']; ?></h5>
			<h5 class="text-info"><?php echo getStats($_SESSION['ex_uid'],'processing'); ?> <?php echo $lang['requests_in_process']; ?></h5>
			<h5 class="text-success"><?php echo getStats($_SESSION['ex_uid'],'processed'); ?> <?php echo $lang['processed_requests']; ?></h5>
			<h5 class="text-error"><?php echo getStats($_SESSION['ex_uid'],'denied'); ?> <?php echo $lang['denied_requests']; ?></h5>
			
			<br>
			<h4><?php echo $lang['referral_earnings']; ?></h4>
			<h5><?php echo $lang['total_earned']; ?>: $<span id="ref_amount"><?php echo idinfo($_SESSION['ex_uid'],"earnings"); ?></span></h5>
			<a href="javascript:void(0);" data-toggle="modal" data-target="#modal_withdrawal" class="btn btn-primary btn-block"><?php echo $lang['withdrawal']; ?></a><br/>
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

<div class="modal fade" id="modal_withdrawal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $lang['withdrawal']; ?></h4>
      </div>
      <div class="modal-body">
		<div id="w_r"></div>
        <form id="form_withdrawal" method="POST" action="">
			<div class="form-group">
				<label><?php echo $lang['table_amount']; ?></label>
				<input type="text" class="form-control" name="amount">
			</div>
			<div class="form-group">
				<label><?php echo $lang['company']; ?></label>
				<select name="company" class="form-control">
					<option value="paypal">PayPal</option>
					<option value="perfectmoney">Perfect Money</option>
					<option value="okpay">OKPay</option>
					<option value="payeer">Payeer</option>
					<option value="advcash">AdvCash</option>
				</select>
			</div>	
			<div class="form-group">
				<label><?php echo $lang['account']; ?></label>
				<input type="text" class="form-control" name="account">
			</div>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="doWithdrawal();"><?php echo $lang['submit']; ?></button>
      </div>
    </div>
  </div>
</div>
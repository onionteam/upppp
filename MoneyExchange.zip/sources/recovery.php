<?php 
if(checkSession()) { header("Location: ./my-account"); } 
$hash = protect($_GET['hash']);
$query = $db->query("SELECT * FROM users WHERE password_recovery='$hash'");
if($query->num_rows==0) { header("Location: ./reset-password"); }
$row = $query->fetch_assoc();
?>
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['recovery_password']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
			if(isset($_POST['btn_save'])) {
				$npassword = protect($_POST['npassword']);
				$cnpassword = protect($_POST['cnpassword']);
				
				if(empty($npassword)) { echo error($lang['error_22']); }
				elseif($npassword !== $cnpassword) { echo error($lang['error_23']); }
				else {
					$pass = md5($npassword);
					$update = $db->query("UPDATE users SET password='$pass',password_recovery='' WHERE id='$row[id]'");
					$_SESSION['ex_uid'] = $row['id'];
					$_SESSION['ex_username'] = $row['username'];
					header("Location: ./my-account");
				}
			}
			?>
		</div>
		<div class="col-sm-8 col-md-8 col-lg-8">
			<form action="" method="POST">
				<div class="form-group">
					<label><?php echo $lang['username']; ?></label>
					<input type="text" class="form-control" name="username" disabled value="<?php echo $row['username']; ?>">
				</div>
				<div class="form-group">
					<label><?php echo $lang['new_password']; ?></label>
					<input type="password" class="form-control" name="npassword">
				</div>
				<div class="form-group">
					<label><?php echo $lang['confirm_password']; ?></label>
					<input type="password" class="form-control" name="cnpassword">
				</div>
				<button type="submit" class="btn btn-primary btn-lg" style="padding:5px;" name="btn_save"><i class="fa fa-check"></i> <?php echo $lang['btn_9']; ?></button>
			</form>
			
		</div>
		<div class="col-sm-4 col-md-4 col-lg-4">
		
		</div>
		
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

<!--footer start here-->
 <div class="footer">
		<div class="footer-main">
			<div class="footer-top">
				<div class="col-md-4 footer-grid">
					<h3><?php echo $lang['language']; ?>:</h3>
					<?php echo getLanguage($settings['url'],null,1); ?>
				</div>
				<div class="col-md-8 footer-grid">
					<!-- testimonials start -->
					<div class="carousel slide" data-ride="carousel" id="quote-carousel">
        <!-- Bottom Carousel Indicators -->
        <ol class="carousel-indicators">
		  <?php
		  $get_tests = $db->query("SELECT * FROM testimonials WHERE status='1' ORDER BY RAND() LIMIT 3");
		  if($get_tests->num_rows>0) {
			while($get = $get_tests->fetch_assoc()) {
				$gets[] = $get;
			}
			$i=0;
			foreach($gets as $get) {
				if($i == 0) {
				?><li data-target="#quote-carousel" data-slide-to="<?php echo $i; ?>" class="active"></li><?php
				} else {
				?> <li data-target="#quote-carousel" data-slide-to="<?php echo $i; ?>"></li><?php
				}
				$i++;
			}
		  }
		  ?>
        </ol>
        
        <!-- Carousel Slides / Quotes -->
        <div class="carousel-inner">
		  <?php
		  if($get_tests->num_rows>0) {
			$e=0;
			foreach($gets as $get) {
				?>
				<div class="item <?php if($e==0) { echo 'active'; } ?>">
					<blockquote>
					  <div class="row">
						<div class="col-sm-2"></div>
						<div class="col-sm-8">
						  <br>
						  <p><?php echo $get['content']; ?></p>
						  <small style="color:#c1c1c1;"><?php echo idinfo($get['uid'],"name"); ?> (<?php echo idinfo($get['uid'],"username"); ?>)</small>
						</div>
						<div class="col-sm-2"></div>
					  </div>
					</blockquote>
				  </div>
				<?php
				$e++;
			}
		  }
		  ?>
        <?php if($get_tests->num_rows>0) { ?>
        <!-- Carousel Buttons Next/Prev -->
        <a data-slide="prev" href="#quote-carousel" class="left carousel-control"><i class="fa fa-chevron-left"></i></a>
        <a data-slide="next" href="#quote-carousel" class="right carousel-control"><i class="fa fa-chevron-right"></i></a>
		<?php } ?>
      </div>          </div>                
					<!-- testimonials end -->
				</div>
			  <div class="clearfix"> </div>
			</div>
			<div class="footer-bottom">
				<p>Created by <a href="http://me4onkof.info" target="_blank">me4onkof.info</a></p>
			</div>
		</div>
	   </div>
	</div>
  </div>
<!--footer end here-->
<input type="hidden" id="url" value="<?php echo $settings['url']; ?>">
</body>
</html>


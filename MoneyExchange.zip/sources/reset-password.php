<?php if(checkSession()) { header("Location: ./my-account"); } ?>
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['reset_password']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
			if(isset($_POST['btn_reset'])) {
				$email = protect($_POST['email']);
				$check_email = $db->query("SELECT * FROM users WHERE email='$email'");
				if(empty($email)) { echo error($lang['error_24']); }
				elseif(!isValidEmail($email)) { echo error($lang['error_3']); }
				elseif($check_email->num_rows==0) { echo error($lang['error_25']); } 
				else {
					$random_password=md5(uniqid(rand()));
					$emailpassword = substr($random_password, 0, 25);
					$newpassword = md5($emailpassword);
					$link=$settings['url']."recovery-$emailpassword";
					$update = $db->query("UPDATE users SET password_recovery='$emailpassword' WHERE email='$email'");
					$subject = '['.$settings[sitename].'] Password Recovery';
					$message = 'Click on this link to change password:
'.$link.'
This email was automatically generated.';
					echo success($lang['success_6']);
				}
			}
			?>
		</div>
		<div class="col-sm-8 col-md-8 col-lg-8">
			<form action="" method="POST">
				<div class="form-group">
					<label><?php echo $lang['email']; ?></label>
					<input type="text" class="form-control" name="email" placeholder="<?php echo $lang['enter_your_email']; ?>">
				</div>
				<button type="submit" class="btn btn-primary btn-lg" style="padding:5px;" name="btn_reset"><i class="fa fa-check"></i> <?php echo $lang['btn_8']; ?></button>
			</form>
			<br><br>
			<p><?php echo $lang['have_account']; ?> <a href="./login"><?php echo $lang['login_from']; ?></a>.</p>
			<p><?php echo $lang['no_have_account']; ?> <a href="./register"><?php echo $lang['create_account']; ?></a>.</p>
		</div>
		<div class="col-sm-4 col-md-4 col-lg-4">
		
		</div>
		
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

<!DOCTYPE HTML>
<html>
<head>
<title><?php echo $settings['title']; ?></title>
<link href="<?php echo $settings['url']; ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo $settings['url']; ?>assets/js/jquery.min.js"></script>
<script src="<?php echo $settings['url']; ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo $settings['url']; ?>assets/js/functions.js"></script>
<!-- Custom Theme files -->
<link href="<?php echo $settings['url']; ?>assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="<?php echo $settings['url']; ?>assets/css/font-awesome.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
</script>
<meta name="keywords" content="<?php echo $settings['keywords']; ?>" />
<meta name="description" content="<?php echo $settings['description']; ?>" />
<!--Google Fonts-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo $settings['url']; ?>assets/js/move-top.js"></script>
<script type="text/javascript" src="<?php echo $settings['url']; ?>assets/js/easing.js"></script>
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
<!-- //end-smoth-scrolling -->
</head>
<body>
<!--top nav start here-->
<div class="mother-grid">
	<div class="container">
	  <div class="temp-padd">
		<div class="top-strip">
			<div class="address">
				<ul>
					<li><a href="<?php echo $settings['url']; ?>"><span class="link"> </span><?php echo $_SERVER['SERVER_NAME']; ?></a></li>
					<li><a href="mailto:<?php echo $settings['email']; ?>"><span class="mes"> </span><?php echo $settings['email']; ?></a></li>
					<li><span class="ph"> </span><?php echo $settings['phone']; ?></li>
				</ul>
			</div>
			<div class="social-icons">
				<ul>
					<li><a href="<?php echo $settings['fb_prof']; ?>" target="_blank"> <span class="w-f"> </span></a></li>
                   <li><a href="<?php echo $settings['tw_prof']; ?>" target="_blank"> <span class="w-tw"> </span></a></li>
                   <li><a href="<?php echo $settings['in_prof']; ?>" target="_blank"> <span class="w-in"> </span></a></li>
				</ul>
			</div>
		  <div class="clearfix"> </div>
   </div>
<!--top nav end here-->	
<!--title start here-->
<div class="title-main">
			<a href="<?php echo $settings['url']; ?>"><img src="<?php echo $settings['url']; ?>assets/images/logo.png"></a>
		
</div>
<!--title end here-->
<!--header start here-->
<div class="header">
			<div class="navg">
				<span class="menu"><i class="fa fa-bars"></i></span>
				<ul class="res">
					<li><a href="<?php echo $settings['url']; ?>"><?php echo $lang['menu_home']; ?></a></li>
					<?php if(checkSession()) { ?>
					<li><a href="<?php echo $settings['url']; ?>my-account"><?php echo $lang['menu_my_account']; ?></a></li>
					<?php } else { ?>
					<li><a href="<?php echo $settings['url']; ?>login"><?php echo $lang['menu_login']; ?></a></li>
					<li><a href="<?php echo $settings['url']; ?>register"><?php echo $lang['menu_register']; ?></a></li>
					<?php } ?>
					<li><a href="<?php echo $settings['url']; ?>testimonials"><?php echo $lang['menu_testimonials']; ?></a></li>
					<li><a href="<?php echo $settings['url']; ?>about"><?php echo $lang['menu_about']; ?></a></li>
					<li><a href="<?php echo $settings['url']; ?>faq"><?php echo $lang['menu_faq']; ?></a></li>
					<li><a href="<?php echo $settings['url']; ?>contact"><?php echo $lang['menu_contact']; ?></a></li>
				</ul>
				<script>
                  $( "span.menu").click(function() {
                    $(  "ul.res" ).slideToggle("slow", function() {
                     // Animation complete.
                     });
                     });
		       </script>
			</div>
			<div class="clearfix"> </div>
  </div>
<!--header end here-->
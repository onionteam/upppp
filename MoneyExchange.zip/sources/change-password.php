<?php if(!checkSession()) { header("Location: ./login"); } ?>
<!--contact start here-->
<div class="contact">
	<h3><?php echo $lang['change_password']; ?></h3>
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
			if(isset($_POST['do_save'])) {
				$cpassword = protect($_POST['cpassword']);
				$npassword = protect($_POST['npassword']);
				$cnpassword = protect($_POST['cnpassword']);
				
				if(md5($cpassword) !== idinfo($_SESSION['ex_uid'],"password")) { echo error($lang['error_21']); }
				elseif(empty($npassword)) { echo error($lang['error_22']); }
				elseif($npassword !== $cnpassword) { echo error($lang['error_23']); }
				else {
					$pass = md5($npassword);
					$update = $db->query("UPDATE users SET password='$pass' WHERE id='$_SESSION[ex_uid]'");
					echo success($lang['success_5']);
				}
			}
			?>
			<form action="" method="POST">
				<div class="form-group">
					<label><?php echo $lang['current_password']; ?></label>
					<input type="password" class="form-control" name="cpassword">
				</div>
				<div class="form-group">
					<label><?php echo $lang['new_password']; ?></label>
					<input type="password" class="form-control" name="npassword">
				</div>
				<div class="form-group">
					<label><?php echo $lang['confirm_password']; ?></label>
					<input type="password" class="form-control" name="cnpassword">
				</div>
				<button type="submit" class="btn btn-primary btn-lg" name="do_save"><i class="fa fa-check"></i> <?php echo $lang['btn_7']; ?></button>
			</form>
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
</div>
<!--contact end here-->

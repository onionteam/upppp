<!--banner start here-->
 <div class="banner">
		<i style="color:#ffffff;" class="fa fa-exchange fa-3x"></i>
		<h3><?php echo $lang['welcome_text_1']; ?></h3>
		<h2><?php echo $lang['welcome_text_2']; ?></h2>
		<div class="banner-button">
			<a href="#exchange"><?php echo $lang['btn_5']; ?></a>
		</div>
</div>
<!--banner end here-->
<!--nunc dig start here-->
  <div class="nuncdig" id="exchange">
		<div class="nuncdig-main">
			<div class="nunc-top">
				<h3><?php echo $lang['select']; ?></h3>
				<p><?php echo $lang['send']; ?> - <?php echo $lang['receive']; ?></p>
			</div>
			<div class="nunc-bott">
				<div class="col-md-4 nunc-bott-grid">
					<div id="list-group1" class="list-group" style="text-align:right;">
					  <a href="javascript:void(0);" class="list-group-item" id="pm_USD">Perfect Money <img src="assets/icons/xpm.png" width="25px"></a>
					  <a href="javascript:void(0);" class="list-group-item" id="okpay_USD">OKPAY <img src="assets/icons/xokpay.png" width="25px"></a>
					  <a href="javascript:void(0);" class="list-group-item" id="payeer_USD">Payeer <img src="assets/icons/xpayeer.png" width="25px"></a>
					  <a href="javascript:void(0);" class="list-group-item" id="advcash_USD">AdvCash <img src="assets/icons/xadvcash.png" width="25px"></a>
					  <a href="javascript:void(0);" class="list-group-item" id="btce_USD">BTC-e USD <img src="assets/icons/xbtc-usd.png" width="25px"></a>
					  <a href="javascript:void(0);" class="list-group-item" id="bitcoin_BTC">Bitcoin <img src="assets/icons/xbitcoin.png" width="25px"></a>
					</div>
				</div>
				<div class="col-md-4 nunc-bott-grid">
					<div id="exchange_results">
					<center><br><br><br>
						<i class="fa fa-exchange fa-3x"></i>
					</center>
					</div>
					<form action="" method="POST" id="exchange_form">
						<input type="hidden" name="send" id="f_send">
						<input type="hidden" name="receive" id="f_receive">
						<input type="hidden" name="email" id="f_email">
						<input type="hidden" name="uid" id="f_uid" <?php if(checkSession()) { ?>value="<?php echo $_SESSION['ex_uid']; ?>"<?php } ?>>
						<input type="hidden" name="exchange_id" id="f_exchange_id">
						<input type="hidden" name="batch_id" id="f_batch_id">
						<input type="hidden" name="receive_id" id="f_receive_id">
						<input type="hidden" name="payee" id="f_payee">
						<input type="hidden" name="expiration" id="f_expiration">
						<input type="hidden" name="amount" id="f_amount" value="100">
					</form>
				</div>
				<div class="col-md-4 nunc-bott-grid">
					<div id="list-group2" class="list-group">
					  <a href="javascript:void(0);" class="list-group-item" id="pm_USD"><img src="assets/icons/xpm.png" width="25px"> Perfect Money</a>
					  <a href="javascript:void(0);" class="list-group-item" id="okpay_USD"><img src="assets/icons/xokpay.png" width="25px"> OKPAY</a>
					  <a href="javascript:void(0);" class="list-group-item" id="payeer_USD"><img src="assets/icons/xpayeer.png" width="25px"> Payeer</a>
					  <a href="javascript:void(0);" class="list-group-item" id="advcash_USD"><img src="assets/icons/xadvcash.png" width="25px">AdvCash</a>
					  <a href="javascript:void(0);" class="list-group-item" id="btce_USD"><img src="assets/icons/xbtc-usd.png" width="25px"> BTC-e USD</a>
					  <a href="javascript:void(0);" class="list-group-item" id="bitcoin_BTC"><img src="assets/icons/xbitcoin.png" width="25px"> Bitcoin</a>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		
		</div>
</div><br>
</div>
<!--nunc dig end here-->
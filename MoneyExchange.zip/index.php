<?php
error_reporting(0);
ob_start();
session_start(); 
if(file_exists("./install.php")) {
	header("Location: ./install.php");
} 
include("includes/config.php");
$db = new mysqli($CONF['host'], $CONF['user'], $CONF['pass'], $CONF['name']);
if ($db->connect_errno) {
    echo "Failed to connect to MySQL: (" . $db->connect_errno . ") " . $db->connect_error;
}
$db->set_charset("utf8");
$settingsQuery = $db->query("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
$settings = $settingsQuery->fetch_assoc();
include("includes/functions.php");
include(getLanguage($settings['url'],null,null));
if(isset($_GET['refid'])) {
	$_SESSION['refid'] = protect($_GET['refid']);
	header("Location: ./");
}
$a = protect($_GET['a']);
include("sources/page-header.php");
switch($a) {
	case "login": include("sources/login.php"); break;
	case "register": include("sources/register.php"); break;
	case "reset-password": include("sources/reset-password.php"); break;
	case "change-password": include("sources/change-password.php"); break;
	case "withdrawals": include("sources/withdrawals.php"); break;
	case "recovery": include("sources/recovery.php"); break;
	case "details": include("sources/details.php"); break;
	case "my-account": include("sources/my-account.php"); break;
	case "testimonials": include("sources/testimonials.php"); break;
	case "submit-testimonial": include("sources/submit-testimonial.php"); break;
	case "about": include("sources/about.php"); break;
	case "faq": include("sources/faq.php"); break;
	case "contact": include("sources/contact.php"); break;
	case "logout": 
		unset($_SESSION['ex_uid']);
		unset($_SESSION['ex_username']);
		session_unset();
		session_destroy();
		header("Location: ./");
	break;
	default: include("sources/welcome.php"); 
}
include("sources/page-footer.php");
mysqli_close($db);
?>
<?php
error_reporting(0);
include("includes/functions.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Install Money Exchange</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/install.css" rel="stylesheet">
  </head>

  <body>

     <!-- Static navbar -->


	<div class="container" style="max-width:600px;">
		<div class="row">
			<div class="col-lg-12 box-white rounded">
				    <div class="navbar navbar-default rounded-top" role="navigation">
					  <div class="container">
						<div class="navbar-header">
						  <a class="navbar-brand" href=""><i class="fa fa-dollar"></i> Money Exchange Installation</a>
					    </div>
					  </div>
					</div>	
					<div class="row" style="padding-bottom:10px;">
						<div class="col-lg-12">
						<?php
						if(isset($_POST['fc_install'])) {
							$mysql_host = protect($_POST['mysql_host']);
							$mysql_user = protect($_POST['mysql_user']);
							$mysql_pass = protect($_POST['mysql_pass']);
							$mysql_base = protect($_POST['mysql_base']);
							$title = protect($_POST['title']);
							$description = protect($_POST['description']);
							$keywords = protect($_POST['keywords']);
							$sitename = protect($_POST['sitename']);
							$semail = protect($_POST['semail']);
							$url = protect($_POST['url']);
							$username = protect($_POST['username']);
							$password = protect($_POST['password']);
							$email = protect($_POST['email']);
							$changer_refid = protect($_POST['changer_refid']);
							
							if(empty($mysql_host) or empty($mysql_user) or empty($mysql_pass) or empty($mysql_base) or empty($title) or empty($description) or empty($keywords) or empty($sitename) or empty($url) or empty($semail) or empty($password) or empty($username) or empty($email)) { echo error("All fields are required."); }
							elseif(!isValidURL($url)) { echo error("Please enter valid site url address."); }
							elseif(!isValidUsername($username)) { echo error("Please enter valid admin username."); }
							elseif(!isValidEmail($semail)) { echo error("Please enter valid site email address."); }
							elseif(!isValidEmail($email)) { echo error("Please enter valid admin email address."); }
							else {
								$db = mysql_connect($mysql_host,$mysql_user,$mysql_pass);

								if($db) {
								$select_db = mysql_select_db($mysql_base,$db);
									if($select_db) {
										mysql_query("SET NAMES 'utf8'");
										$sql_filename = 'sql.sql';
										$sql_contents = file_get_contents($sql_filename);
										$sql_contents = explode(";", $sql_contents);

										foreach($sql_contents as $k=>$v) {
											mysql_query($v);
										}
										
										$current .= '<?php
';
										$current .= '$CONF = array();';
										$current .= '$CONF["host"] = "'.$mysql_host.'";
';
										$current .= '$CONF["user"] = "'.$mysql_user.'";
';
										$current .= '$CONF["pass"] = "'.$mysql_pass.'";
';
										$current .= '$CONF["name"] = "'.$mysql_base.'";
';
										$current .= '?>
										';
										
										file_put_contents("includes/config.php", $current);
										
										@unlink("sql.sql");
										@unlink("install.php"); 
										
										$insert_settings = mysql_query("INSERT settings (title,description,keywords,sitename,url,email,phone,changer_refid,earnings) VALUES ('$title','$description','$keywords','$sitename','$url','$semail','n/a','$changer_refid','0')");
										$passwd = md5($password);
										$insert_admin = mysql_query("INSERT users (password,email,username,status,name,earnings) VALUES ('$passwd','$email','$username','666','Admin','0')");
										$install_success=1;
									} else {
										echo error("Error! MySQL database not exists.");
									}
								} else {
									echo error("Error! Failed to connect to MySQL server.");
								}
							}
						}
						
						if($install_success !== 1) {
						?>
							<form action="" method="POST" role="form">
								<h3>MySQL Connection</h3>
								  <div class="form-group">
									<label>MySQL Host</label>
									<input type="text" class="form-control" name="mysql_host" value="<?php if(isset($_POST['mysql_host'])) { echo $_POST['mysql_host']; } ?>">
								  </div>
								  <div class="form-group">
									<label>MySQL Username</label>
									<input type="text" class="form-control" name="mysql_user" value="<?php if(isset($_POST['mysql_user'])) { echo $_POST['mysql_user']; } ?>">
								  </div>
								  <div class="form-group">
									<label>MySQL Password</label>
									<input type="password" class="form-control" name="mysql_pass" value="<?php if(isset($_POST['mysql_pass'])) { echo $_POST['mysql_pass']; } ?>">
								  </div>
								  <div class="form-group">
									<label>MySQL Database</label>
									<input type="text" class="form-control" name="mysql_base" value="<?php if(isset($_POST['mysql_base'])) { echo $_POST['mysql_base']; } ?>">
								  </div>
								<br>
								<h3>Web Settings</h3>
								  <div class="form-group">
									<label>Title</label>
									<input type="text" class="form-control" name="title" value="<?php if(isset($_POST['title'])) { echo $_POST['title']; } ?>">
								  </div>
								  <div class="form-group">
									<label>Description</label>
									<textarea class="form-control" name="description" rows="3"><?php if(isset($_POST['description'])) { echo $_POST['description']; } ?></textarea>
								  </div>
								  <div class="form-group">
									<label>Keywords</label>
									<textarea class="form-control" name="keywords" rows="3"><?php if(isset($_POST['keywords'])) { echo $_POST['keywords']; } ?></textarea>
								  </div>
								  <div class="form-group">
									<label>Site name</label>
									<input type="text" class="form-control" name="sitename" value="<?php if(isset($_POST['sitename'])) { echo $_POST['sitename']; } ?>">
								  </div>
								  <div class="form-group">
									<label>Site url</label>
									<input type="text" class="form-control" name="url" value="<?php if(isset($_POST['url'])) { echo $_POST['url']; } ?>" placeholder="Example: http://filecloud.com/">
								  </div>
								  <div class="form-group">
									<label>Site email</label>
									<input type="text" class="form-control" name="semail" value="<?php if(isset($_POST['semail'])) { echo $_POST['semail']; } ?>">
								  </div>
								  <div class="form-group">
									<label>Changer Referral ID (Can get it from <a href="https://www.changer.com/referrals">https://www.changer.com/referrals</a>)</label>
									<input type="text" class="form-control" name="changer_refid" value="<?php if(isset($_POST['changer_refid'])) { echo $_POST['changer_refid']; } ?>">
								  </div>
								 <br>
								<h3>Create Admin Account</h3>
								  <div class="form-group">
									<label>Username</label>
									<input type="text" class="form-control" name="username" value="<?php if(isset($_POST['username'])) { echo $_POST['username']; } ?>">
								  </div>
								  <div class="form-group">
									<label>Email address</label>
									<input type="text" class="form-control" name="email" value="<?php if(isset($_POST['email'])) { echo $_POST['email']; } ?>">
								  </div>
								  <div class="form-group">
									<label>Password</label>
									<input type="password" class="form-control" name="password">
								  </div>
								
								<button type="submit" class="btn btn-primary btn-block" name="fc_install"><i class="fa fa-check-circle"></i> Install</button>
							</form>
						<?php 
						} else {
						?>
						<h3>Installation was successfully!</h3>
						<p>Your Money Exchange address: <a href="<?php echo $url; ?>"><?php echo $url; ?></a></p><br/>
						<p>Your Money Exchange admin panel address: <a href="<?php echo $url; ?>admin"><?php echo $url; ?>admin</a></p><br/>
						<p>Admin account: <?php echo $username; ?> / <?php echo protect($_POST['password']); ?></p><br/>
						<p>Note that not all system settings, please after login with admin account finish them from the admin menu</p>
						<?php
						}
						?>
						</div>
			</div>
		</div>
	</div>
	</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
	<script type="text/javascript" src="assets/js/jquery.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
	<script type="text/javascript" src="assets/js/source.js"></script>
    <script language="javascript" type="text/javascript" src="assets/uploader/js/arfaly-min.js" ></script>
	<script language="javascript" type="text/javascript" src="assets/uploader/js/custom.js" ></script>
  </body>
</html>
					
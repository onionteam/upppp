<?php
// English language
// for PandaChanger
// by me4onkof
$lang = array();

$lang['menu_home'] = 'Home'; 
$lang['menu_my_account'] = 'My Account';
$lang['menu_login'] = 'Login';
$lang['menu_register'] = 'Register';
$lang['menu_testimonials'] = 'Testimonials';
$lang['menu_about'] = 'About';
$lang['menu_contact'] = 'Contact';
$lang['menu_faq'] = 'FAQ';

// errors
$lang['error_1'] = 'Enter your name to send message.';
$lang['error_2'] = 'Enter your email address to send message.';
$lang['error_3'] = 'Enter valid email address. Example: john@gmail.com';
$lang['error_4'] = 'Enter your message to send message.';
$lang['error_5'] = 'Error sending email. Please try again later.';
$lang['error_6'] = 'Enter your username to login.';
$lang['error_7'] = 'Enter your password to login.';
$lang['error_8'] = 'Wrong username or password.';
$lang['error_9'] = 'Your account is blocked. Please contact with administrator.';
$lang['error_10'] = 'All fields are required.';
$lang['error_11'] = 'Enter valid username. Use latin characters, numbers and symbols _ and -';
$lang['error_12'] = 'This username is already used. Please choose another.';
$lang['error_13'] = 'This email address is already used. Please choose another.';
$lang['error_14'] = 'Password does not match with password for confirmation.';
$lang['error_15'] = 'Please leave your feedback to continue.';
$lang['error_16'] = 'We havent received a payment yet.';
$lang['error_17'] = 'Your exchange has been denied and refunded to your payer account/address.';
$lang['error_18'] = 'Unknown problem with exchange. Please contact with administrator. Exchange id:';
$lang['error_19'] = '<h3>Sorry!</h3>You can`t exchange money from Perfect Money to OKPAY.';
$lang['error_20'] = '<h3>Sorry!</h3>You can`t exchange money from OKPAY to Perfect Money.';
$lang['error_21'] = 'Current password does not match.';
$lang['error_22'] = 'Please enter some new password.';
$lang['error_23'] = 'New password does not match with password for confirmation.';
$lang['error_24'] = 'Please enter your email address.';
$lang['error_25'] = 'No such user with this email address.';
$lang['error_26'] = 'Please enter your transaction id to confirm payment.';
$lang['error_27'] = 'Please enter a valid PerfectMoney Account (Eg: Uxxxxxx)';
$lang['error_28'] = 'Please enter a valid OKPAY Account (Eg: OKxxxxxx or email example@gmail.com)';
$lang['error_29'] = 'Please enter a valid Payeer Account (Eg: P1000000)';
$lang['error_30'] = 'Please enter a valid AdvCash Account (Eg: example@gmail.com)';
$lang['error_31'] = 'Please enter a valid Bitcoin Address (Eg: 1XXXXxxXXx1XXx2xxX3XX456xXx)';
$lang['error_32'] = 'Please enter valid your email address.';
$lang['error_33'] = 'Please enter valid exchange amounts!';

// successes
$lang['success_1'] = 'Your message was sent successfully. Soon you will receive a reply.';
$lang['success_2'] = 'Your account was created.';
$lang['success_2_1'] = 'Click here';
$lang['success_2_2'] = 'to login';
$lang['success_3'] = 'Your feedback was submitted successfully.';
$lang['success_4'] = 'Your exchange has been succesfully processed.';
$lang['success_5'] = 'Your password was changes successfully.';
$lang['success_6'] = 'Link for password reset was sent on your email.';

// infos
$lang['info_1'] = 'Your exchange is in our processing queue.';
$lang['info_payment_1'] = 'You need to confirm payment with the transaction id (PAYMENT_BATCH_NUM of your payment)';
$lang['info_payment_2'] = 'You need to confirm payment with the transaction id (ID of your payment TxnInfo)';
$lang['info_payment_3'] = 'You need to confirm payment with the transaction id (historyId of your payment)';
$lang['info_payment_4'] = 'You need to confirm payment with the transaction id (return of your payment sendMoneyResponse)';
$lang['info_payment_5'] = 'In order to complete your exchange order, you have to create a USD reedemable code from your BTC-e Account. Please enter it below:';
$lang['info_payment_6'] = 'When we receive your payment will be process exchange.';

// btns 
$lang['btn_1'] = 'Send';
$lang['btn_2'] = 'Login';
$lang['btn_3'] = 'Register';
$lang['btn_4'] = 'Submit';
$lang['btn_5'] = 'BECOME EXCHANGE';
$lang['btn_6'] = 'Make Exchange';
$lang['btn_7'] = 'Save Changes';
$lang['btn_8'] = 'Reset';
$lang['btn_9'] = 'Change Password';
$lang['btn_10'] = 'Confirm & Continue';

$lang['status_refresh'] = 'Status will be refreshed every 5 seconds.';
$lang['name'] = 'Name';
$lang['email'] = 'Email address';
$lang['message'] = 'Message';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['no_have_account'] = 'No have account?';
$lang['create_account'] = 'Create from here';
$lang['forgot_password'] = 'Forgot your password?';
$lang['password_reset'] = 'Reset it from here';
$lang['welcome'] = 'Welcome';
$lang['change_password'] = 'Change password';
$lang['logout'] = 'Logout';
$lang['table_send'] = 'Send';
$lang['table_receive'] = 'Receive';
$lang['table_amount'] = 'Amount';
$lang['table_status'] = 'Status';
$lang['table_details'] = 'Details';
$lang['view'] = 'View';
$lang['overall_statistics'] = 'Overall statistics';
$lang['pending_requests'] = 'pending requests';
$lang['requests_in_process'] = 'requests in process';
$lang['processed_requests'] = 'processed requests';
$lang['denied_requests'] = 'denied requests';
$lang['language'] = 'Language';
$lang['your_name'] = 'Your name';
$lang['confirm_password'] = 'Confirm password';
$lang['have_account'] = 'Already have account?';
$lang['login_from'] = 'Login from here';
$lang['submit_testimonial'] = 'Submit testimonial'; 
$lang['your_feedback'] = 'Your feedback';
$lang['welcome_text_1'] = 'Easy exchange money or coins from';
$lang['welcome_text_2'] = 'one company to another only one click.';
$lang['select'] = 'SELECT';
$lang['send'] = 'send';
$lang['receive'] = 'receive';
$lang['exchange_rate'] = 'Exchange rate';
$lang['current_password'] = 'Current password';
$lang['new_password'] = 'New password';
$lang['reset_password'] = 'Reset password';
$lang['enter_your_email'] = 'Enter your email here';
$lang['recovery_password'] = 'Password Recovery';
$lang['now_send'] = 'Now send';
$lang['to'] = 'to';
$lang['account'] = 'account';
$lang['address'] = 'address';
$lang['transaction_id'] = 'Transaction ID';
$lang['redm_code'] = 'Redeem code';
$lang['payee'] = 'Payee';
$lang['r_amount'] = 'Received amount';
$lang['expiration'] = 'Expiration';
$lang['withdrawals'] = 'Withdrawals';
$lang['referral_link'] = 'Referral link';
$lang['referral_earnings'] = 'Referral earnings';
$lang['total_earned'] = 'Total earned';
$lang['withdrawal'] = 'Withdrawal';
$lang['company'] = 'Company';
$lang['account'] = 'Account';
$lang['submit'] = 'Submit';
$lang['status'] = 'Status';
$lang['requested_on'] = 'Requested on';
$lang['processed_on'] = 'Processed on';
$lang['in_process'] = 'In process';
$lang['completed'] = 'Completed';
$lang['denied'] = 'Denied';
$lang['faq'] = 'Friendly Asked Questions';
?>